.\objects\pid.o: ..\BLDC\pid.c
.\objects\pid.o: ..\BLDC\pid.h
.\objects\pid.o: C:\Users\Administrator\AppData\Local\Keil_v5\ARM\AC5\Bin\..\include\stdint.h
