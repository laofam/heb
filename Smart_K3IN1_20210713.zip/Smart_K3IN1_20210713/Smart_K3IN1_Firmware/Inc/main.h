/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2019 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under Ultimate Liberty license
  * SLA0044, the "License"; You may not use this file except in compliance with
  * the License. You may obtain a copy of the License at:
  *                             www.st.com/SLA0044
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f3xx_hal.h"

/* Private includes ----------------------------------------------------------*/
//#define FORMER_PCB
/* USER CODE BEGIN Includes */
/* Base address of the Flash pages */
#define ADDR_FLASH_PAGE_0     ((uint32_t)0x08000000) /* Base address of Page 0, 2 Kbytes */
#define ADDR_FLASH_PAGE_1     ((uint32_t)0x08000800) /* Base address of Page 1, 2 Kbytes */
#define ADDR_FLASH_PAGE_2     ((uint32_t)0x08001000) /* Base address of Page 2, 2 Kbytes */
#define ADDR_FLASH_PAGE_3     ((uint32_t)0x08001800) /* Base address of Page 3, 2 Kbytes */
#define ADDR_FLASH_PAGE_4     ((uint32_t)0x08002000) /* Base address of Page 4, 2 Kbytes */
#define ADDR_FLASH_PAGE_5     ((uint32_t)0x08002800) /* Base address of Page 5, 2 Kbytes */
#define ADDR_FLASH_PAGE_6     ((uint32_t)0x08003000) /* Base address of Page 6, 2 Kbytes */
#define ADDR_FLASH_PAGE_7     ((uint32_t)0x08003800) /* Base address of Page 7, 2 Kbytes */
#define ADDR_FLASH_PAGE_8     ((uint32_t)0x08004000) /* Base address of Page 8, 2 Kbytes */
#define ADDR_FLASH_PAGE_9     ((uint32_t)0x08004800) /* Base address of Page 9, 2 Kbytes */
#define ADDR_FLASH_PAGE_10    ((uint32_t)0x08005000) /* Base address of Page 10, 2 Kbytes */
#define ADDR_FLASH_PAGE_11    ((uint32_t)0x08005800) /* Base address of Page 11, 2 Kbytes */
#define ADDR_FLASH_PAGE_12    ((uint32_t)0x08006000) /* Base address of Page 12, 2 Kbytes */
#define ADDR_FLASH_PAGE_13    ((uint32_t)0x08006800) /* Base address of Page 13, 2 Kbytes */
#define ADDR_FLASH_PAGE_14    ((uint32_t)0x08007000) /* Base address of Page 14, 2 Kbytes */
#define ADDR_FLASH_PAGE_15    ((uint32_t)0x08007800) /* Base address of Page 15, 2 Kbytes */
#define ADDR_FLASH_PAGE_16    ((uint32_t)0x08008000) /* Base address of Page 16, 2 Kbytes */
#define ADDR_FLASH_PAGE_17    ((uint32_t)0x08008800) /* Base address of Page 17, 2 Kbytes */
#define ADDR_FLASH_PAGE_18    ((uint32_t)0x08009000) /* Base address of Page 18, 2 Kbytes */
#define ADDR_FLASH_PAGE_19    ((uint32_t)0x08009800) /* Base address of Page 19, 2 Kbytes */
#define ADDR_FLASH_PAGE_20    ((uint32_t)0x0800A000) /* Base address of Page 20, 2 Kbytes */
#define ADDR_FLASH_PAGE_21    ((uint32_t)0x0800A800) /* Base address of Page 21, 2 Kbytes */
#define ADDR_FLASH_PAGE_22    ((uint32_t)0x0800B000) /* Base address of Page 22, 2 Kbytes */
#define ADDR_FLASH_PAGE_23    ((uint32_t)0x0800B800) /* Base address of Page 23, 2 Kbytes */
#define ADDR_FLASH_PAGE_24    ((uint32_t)0x0800C000) /* Base address of Page 24, 2 Kbytes */
#define ADDR_FLASH_PAGE_25    ((uint32_t)0x0800C800) /* Base address of Page 25, 2 Kbytes */
#define ADDR_FLASH_PAGE_26    ((uint32_t)0x0800D000) /* Base address of Page 26, 2 Kbytes */
#define ADDR_FLASH_PAGE_27    ((uint32_t)0x0800D800) /* Base address of Page 27, 2 Kbytes */
#define ADDR_FLASH_PAGE_28    ((uint32_t)0x0800E000) /* Base address of Page 28, 2 Kbytes */
#define ADDR_FLASH_PAGE_29    ((uint32_t)0x0800E800) /* Base address of Page 29, 2 Kbytes */
#define ADDR_FLASH_PAGE_30    ((uint32_t)0x0800F000) /* Base address of Page 30, 2 Kbytes */
#define ADDR_FLASH_PAGE_31    ((uint32_t)0x0800F800) /* Base address of Page 31, 2 Kbytes */
/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define M1_CURR_AMPL_U_Pin GPIO_PIN_0
#define M1_CURR_AMPL_U_GPIO_Port GPIOA
#define M1_CURR_AMPL_V_Pin GPIO_PIN_1
#define M1_CURR_AMPL_V_GPIO_Port GPIOA
#define M1_CURR_AMPL_W_Pin GPIO_PIN_2
#define M1_CURR_AMPL_W_GPIO_Port GPIOA
#define M1_BUS_VOLTAGE_Pin GPIO_PIN_3
#define M1_BUS_VOLTAGE_GPIO_Port GPIOA
#define DCM_CURRENT_Pin GPIO_PIN_4
#define DCM_CURRENT_GPIO_Port GPIOA
#define DCM_PWM_Pin GPIO_PIN_5
#define DCM_PWM_GPIO_Port GPIOA
#define DCM_SPEED_Pin GPIO_PIN_6
#define DCM_SPEED_GPIO_Port GPIOA
#define M1_PWM_UL_Pin GPIO_PIN_7
#define M1_PWM_UL_GPIO_Port GPIOA
#define M1_PWM_VL_Pin GPIO_PIN_0
#define M1_PWM_VL_GPIO_Port GPIOB
#define M1_PWM_WL_Pin GPIO_PIN_1
#define M1_PWM_WL_GPIO_Port GPIOB
#define Status_Pin GPIO_PIN_2
#define Status_GPIO_Port GPIOB


//#define SW_V_Pin GPIO_PIN_10
//#define SW_V_GPIO_Port GPIOB
//#define SW_H_Pin GPIO_PIN_11
//#define SW_H_GPIO_Port GPIOB

#define SW_V_Pin GPIO_PIN_6
#define SW_V_GPIO_Port GPIOA
#define SW_H_Pin GPIO_PIN_9
#define SW_H_GPIO_Port GPIOB

#define OC_INPUT_Pin GPIO_PIN_12
#define OC_INPUT_GPIO_Port GPIOB
#define OC_OUTPUT_Pin GPIO_PIN_13
#define OC_OUTPUT_GPIO_Port GPIOB
#define M1_PWM_UH_Pin GPIO_PIN_8
#define M1_PWM_UH_GPIO_Port GPIOA
#define M1_PWM_VH_Pin GPIO_PIN_9
#define M1_PWM_VH_GPIO_Port GPIOA
#define M1_PWM_WH_Pin GPIO_PIN_10
#define M1_PWM_WH_GPIO_Port GPIOA
#define M1_OCP_Pin GPIO_PIN_11
#define M1_OCP_GPIO_Port GPIOA
#define HALL_SW_Pin GPIO_PIN_12
#define HALL_SW_GPIO_Port GPIOA
#define HALL_SW_EXTI_IRQn EXTI15_10_IRQn
#define TMS_Pin GPIO_PIN_13
#define TMS_GPIO_Port GPIOA
#define TCK_Pin GPIO_PIN_14
#define TCK_GPIO_Port GPIOA
#define STEP_D_Pin GPIO_PIN_15
#define STEP_D_GPIO_Port GPIOA
//#define STEP_C_Pin GPIO_PIN_3
//#define STEP_C_GPIO_Port GPIOB
#define STEP_C_Pin GPIO_PIN_13
#define STEP_C_GPIO_Port GPIOC
#define STEP_B_Pin GPIO_PIN_4
#define STEP_B_GPIO_Port GPIOB
#define STEP_A_Pin GPIO_PIN_5
#define STEP_A_GPIO_Port GPIOB

//#define HALL_SW2_C_Pin GPIO_PIN_10
//#define HALL_SW2_C_GPIO_Port GPIOB

#define HALL_SW2_C_Pin GPIO_PIN_14
#define HALL_SW2_C_GPIO_Port GPIOC
#define HALL_SW2_D_Pin GPIO_PIN_8
#define HALL_SW2_D_GPIO_Port GPIOB

//#define HALL_SW2_D_Pin GPIO_PIN_14
//#define HALL_SW2_D_GPIO_Port GPIOC
//#define HALL_SW2_C_Pin GPIO_PIN_8
//#define HALL_SW2_C_GPIO_Port GPIOB

#define Content_Gauge_In_Pin GPIO_PIN_15
#define Content_Gauge_In_GPIO_Port GPIOC

//#define DCM10_F_Pin GPIO_PIN_13
//#define DCM10_F_GPIO_Port GPIOC
//#define DCM10_B_Pin GPIO_PIN_14
//#define DCM10_B_GPIO_Port GPIOC

#define DCM10_F_Pin GPIO_PIN_3
#define DCM10_F_GPIO_Port GPIOB
#define DCM10_B_Pin GPIO_PIN_10
#define DCM10_B_GPIO_Port GPIOB

#define HALL_A_Pin GPIO_PIN_6
#define HALL_A_GPIO_Port GPIOB
#define HALL_B_Pin GPIO_PIN_7
#define HALL_B_GPIO_Port GPIOB

#define DCM_CURRENT2_Pin GPIO_PIN_11
#define DCM_CURRENT2_GPIO_Port GPIOB
/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
