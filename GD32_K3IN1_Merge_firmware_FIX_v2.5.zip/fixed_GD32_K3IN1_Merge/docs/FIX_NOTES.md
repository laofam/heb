# K3IN1 × gd303 合并固件 —— 移植问题修复说明（修复版 v2.5）

> 审查基准：`Smart_K3IN1_Firmware -servo-V1.3-20210713`（STM32F302 原厂固件，以下简称 K3IN1）
> + `gd303_HALL_FOC_v2.2`（已验证风机 FOC，**零改动**）。
> 本修复版只改业务层文件（User/ 与 User/app/，v2.3 增含 material_s4.c），FOC/BLDC/库文件/启动文件/工程文件均未触碰。
> v2.1：新增 F10（重映射顺序导致 SWD 调试口可能被库函数副作用关闭）。
> v2.2：新增 F11（飞控失联保护：P1/P2 正脉宽 <1150us 一律不响应——飞控未连接时
> S1=1000us/S2=1100us 的默认输出命中 P2_ON 开机窗与档位表 [1075,1125)us 档，系统自启动）
> 与 F12（窗口/档位表单位注释口径 2 倍错，纯注释零行为变更）。
> v2.3：新增 F13（用户反馈：风机启动后步进限位 PA12/PA11 无人监管——补齐 K3IN1
> "实时检测导管位置"闭环：漂移自动重压+到位压紧，打开/关闭/故障全状态生效）、F14（L1
> 去抖状态机结构对齐 K3IN1——无料报警回环在抖动场景的误锁/漏锁）、F15（停止后无法
> 二次开机 + P2-OFF 持续到达反复重走停止链）、F16（无料恢复 L1 无条件释放）。
> v2.4：新增 F17（用户实测：拨料占空比恒 100%——测速 PPR 沿用 K3IN1 双通道合计 20，
> 新板单通道下降沿实际 5 → 斜坡恒 4× 超前；并确认测速下降沿配置本就正确）、F18（启动
> 电流给定 100mA 对齐）、F19（TELEMETRY_SELECT=2 拨料遥测通道，供 PPR 现场标定）。
> v2.5：新增 F20（用户实测：无料 PA15 毫无作用——v2.3/v2.4 把停机权押在 L1 电气回声
> 环上，回环断链即静默失败；改为报警直接置 No_Mat 故障进停止链，非锁存、补料自清）、
> F21（用户实测："STEP_M_ON 触发一下风机就一直吹"——K3IN1 对限位丢失只重压不停机；
> 新增 3s 持续丢失看门狗 → Step_Lost 锁存全停，重压自愈不误伤）、F22（L1/PA15 悬空
> 不确定性 → 内部上拉；LED 双闪吞无料快闪；重压上限被入口块清零）。

---

## 一、修复总览

| 编号 | 等级 | 问题 | 修复文件 |
|------|------|------|----------|
| F1 | 致命 | `stepper_100us_tick()` 从未被调用 → 步进完全不动 → P2 开机流程死锁 | app_init.c |
| F2 | 致命 | `dosing_500us_tick()` 斜坡推进条件写反 → `cur_set_deg` 恒 0 → 拨料电机永不转 | dosing_motor.c |
| F3 | 致命 | P2 全停窗口误用 [900,1000]（P1 的 OFF 窗）→ 主机全停命令（960~1115us）收不到 | p1p2_capture.c / app_config.h |
| F4 | 严重 | L1 去抖 / 拨料两级过流 / 步进过流三个 10ms 计时挂在 1ms 分支 → 全部快 10 倍 | app_init.c |
| F5 | 严重 | 收起延时计数 10ms 自增却比较 10000（原为 100us 单位）→ 1s 变 100s | motor_ctrl.c / app_config.h |
| F6 | 严重 | `Blower_OC` 位从未被置位 → 风机运行故障不停机、无告警 | motor_ctrl.c / main.c |
| F7 | 严重 | 步进拍速常数互换 + 单位错 → 收起快 20×、打开快 5×、压紧快 50× | stepper.c / app_config.h |
| F8 | 中等 | 速度环 PI 限幅 1100(mA) 直接作用于 ADC 码值反馈 → 量纲错位 1.61× | dosing_motor.c / app_config.h |
| F9 | 中等 | 电流采样占用 ADC0 规则组（与 FOC 注入组同 ADC）→ 采样抖动；任务书要求用另外的 ADC | app_init.c/.h / dosing_motor.c |
| F10 | 严重（条件性） | 普通重映射分支把 SWJ_CFG 硬写 111；若手册表 8-3"禁用"为真则每次上电关闭 SWD 调试口 | app_init.c |
| F11 | 致命（用户实测） | 飞控失联输出 S1=1000/S2=1100us 被误响应：S2 命中 P2_ON 开机窗与档位表 [1075,1125)us 档（250rpm）→ 未连接即自启动 | p1p2_capture.c / app_config.h |
| F12 | 轻微（纯注释） | 窗口/档位表注释把 us 宏值误按 0.5us tick 换算成一半数值；代码行为从未错 | app_config.h / p1p2_capture.c/.h / motor_ctrl.c |
| F13 | 致命（用户实测反馈） | 风机启动后/收起完成后 PA12/PA11 无人读取——K3IN1"实时检测导管位置"（打开侧 HALL_SWV 块+关闭侧+故障分支）未移植：管子漂移无重压、无压紧补偿 | motor_ctrl.c / stepper.c/.h / app_config.h |
| F14 | 严重 | `s4_fault_proc` 去抖到期检查嵌在边沿判断内（K3IN1 在外）→ 线抖动回旧电平时计数 stale、下次边沿瞬时锁存 → 无料报警回环/外部故障误锁或漏锁 | material_s4.c |
| F15 | 致命 | 停止链收起完成后 `step_open` 永不清零 → 一次启停循环后 P2-ON 无法重新开机；P2-OFF 持续到达时停止链每 ~1.5s 重走 | motor_ctrl.c |
| F16 | 轻微 | 无料恢复 L1 释放带 `g_no_particles==1` 门槛（K3IN1 无条件 RESET） | material_s4.c |
| F17 | 致命（用户实测反馈） | 拨料测速 PPR 沿用 K3IN1 双通道合计 20（新板单通道下降沿实际 5）→ 位置斜坡恒 4× 超前 → 速度环误差常满 → 占空比恒 100%（霍尔 266Hz 电机在转） | app_config.h（PPR=5） |
| F18 | 轻微 | DOSE_STARTUP 初始电流给定 0（K3IN1 为 100mA） | dosing_motor.c |
| F19 | 工具 | 调试遥测无拨料通道——PPR 现场标定无观测手段 | main.c / dosing_motor.c/.h / motor_config.h（注释） |
| F20 | 致命（用户实测反馈） | 无料停机权押在 L1 电气回声环（PA15→PC13→Q9→PB2 读回→Ext_OC），回环断链即静默失败——PA15 触发后程序毫无反应 | material_s4.c / app_config.h / p1p2_capture.c / led_status.c |
| F21 | 致命（用户实测反馈） | "STEP_M_ON 触发一下风机就一直吹，不管后续"——K3IN1 对限位丢失只重压、30 次失败后静默放弃，风机/拨料照转（用户不接受） | motor_ctrl.c / app_config.h |
| F22 | 严重 | L1(PB2)/PA15 悬空读数不确定（上电随机锁 Ext_OC / 无传感器误报无料）；LED 双闪条件 byte≠0 会吞 No_Mat 快闪；停止链入口每 10ms 清重压计数使 30 次上限失效 | app_init.c / led_status.c / material_s4.c / motor_ctrl.c |
| 附带 | 轻微 | 打开到位后缺少 K3IN1 的 CCW 压紧 100 步；打开失败无 3 次重试 | motor_ctrl.c |
| 附带 | 轻微 | 调试宏按任务书命名 `NO_S1_HAVE_UART`（原 `APP_DEBUG_UART_EN` 保留为别名） | app_config.h |
| 附带 | 轻微 | `L1P_RCU` 笔误（GPIOB 写成 L1 前缀）更名 `L1_RCU`（原本就未被引用，无行为差异） | app_config.h |

---

## 二、逐项修复说明（含 K3IN1 证据与修复实现）

### F1（致命）步进 100us 拍驱动从未被调用

- **现象**：`stepper.c` 的 `stepper_100us_tick()` 是非阻塞八拍驱动的唯一推进入口，但
  `app_tick_100us_isr()`（TIMER5 100us 心跳）只调用了 `dosing_100us_isr()` 和 `dosing_500us_tick()`，
  从未调用步进驱动。结果：`g_tick.step_100us` 空转累加，四相输出永不切换，步进电机纹丝不动。
- **后果链**：P2 开机 → `stepper_run_ccw()` 置位 → 永远到不了 STEP_OVER → 风机永不启动 →
  整个开机流程死锁；停止链的收起阶段同样卡死。
- **修复**（`app_init.c`）：
  ```c
  void app_tick_100us_isr(void)
  {
      app_adc1_poll_100us();      /* F9 */
      dosing_100us_isr();
      stepper_100us_tick();       /* F1：补上漏调的步进拍驱动 */
      ...
  }
  ```
- **K3IN1 证据**：TIM16 100us 中断里 `TimeFlag_Step100us++`（main.c:1616-1620），`StepMotor_Control_xxx_Loop`
  在主循环用该时标走拍——心跳与拍驱动同源，缺一不可。

### F2（致命）拨料位置斜坡推进条件写反

- **K3IN1 原式**（`daMc_state.c` DCMMotor_Tick，每 500us）：
  ```c
  if((abs(CurrentSetDegrees) - abs(20*DegreesStepScal)) <= abs(Current_Angle - Start_Angle))
  {   /* 实际位置已跟上给定（误差 ≤ 20 步长）→ 给定推进一步 */
      if (abs(Target_Angle - Current_Angle) >= (5*DCM_Tick))
          CurrentSetDegrees += DegreesStepScal;
      else
          CurrentSetDegrees = Target_Angle - Start_Angle;
  }
  ```
  语义是**软起动斜坡**：给定位置只在电机"追上"后才前进。
- **初版错误**：写成 `(cur_set_deg - start_angle) > 20*dose_tick`——启动时 `cur_set_deg=0`，
  条件恒假，`cur_set_deg` 永远为 0；速度环误差 = (0 − 位置)/128 ≤ 0 → `target_curr=0` → 电机不出力。
- **修复**（`dosing_motor.c dosing_500us_tick()`）：按 K3IN1 原式移植（K3IN1 变量均为非负
  累计位置，取绝对值防御性保留）：
  ```c
  if ((set_pos - 20 * dose_tick) <= angle_pos) {
      if ((target_angle - cur_angle) >= (5 * dose_tick)) cur_set_deg += deg_step_scal;
      else cur_set_deg = target_angle - start_angle;
  }
  ```

### F3（致命）P2 全停窗口移植错误

- **K3IN1 生产值**（`user_data.h`）：`S2_OFF_TIME_LO=1920 / S2_OFF_TIME_HI=2230`
  （单位 us，即全停窗 1920~2230us），`S2_ON=960/1940`（开机窗 960~1940us）。
  （v2.1 笔记曾按 0.5us tick 口径换算成 960~1115us/480~970us——系口径误读，见 F12。）
  main.c 捕获回调里 S2 的停机判定用的就是 S2_OFF 窗（main.c:1769），紧邻的
  `S1_OFF` 注释行（main.c:1770）是被注释掉的备选分支。
- **初版错误**：`decode_channel()` 的 P2 分支复用了 P1 的 `[900,1000]` OFF 窗——
  恰好是那行被注释掉的分支。主机发出的全停命令（1920~2230us）落在初版窗口之外，
  永远不产生 `p2_cmd=2`，**系统无法被正常停机**（只能靠 5s 信号丢失兜底）。
- **修复**（`app_config.h` + `p1p2_capture.c`）：新增 `P2_OFF_LO=1920 / P2_OFF_HI=2230`，
  P2 解码改用该窗口；P1 分支保持 `[900,1000]` 不变。

### F4（严重）三个 10ms 计时函数挂在 1ms 分支

- **K3IN1 证据**（TIM16 100us 中断，main.c:1636-1652）：`time_temp>=100`（=10ms）分支内才递增
  `OC_Input_Timer_Count`（L1 去抖）、`DCM_Current_Timer_Count1/2`（拨料两级过流）。
- **初版错误**：`app_tick_100us_isr()` 把 `s4_debounce_10ms() / dosing_overcurrent_10ms() /
  stepper_overcurrent_10ms()` 放在 `s_1ms>=10`（=1ms）分支 → L1 去抖 300ms 变 30ms（易误报
  外部故障）、拨料过流 5s/1.5s 变 0.5s/150ms（易误报堵转）、步进 1s 变 100ms。
- **修复**：移入 10ms 分支（与 `flag_10ms` 同拍）。

### F5（严重）收起延时 1s 变 100s

- **K3IN1 证据**：`STEP_DELAY_CLOSE_TIME=10000`，注释"单位 100us"（=1s），且 K3IN1 用
  `T16.TimerFlag_100uS`（TIM16 100us 中断递增）与之比较——量纲自洽。
- **初版错误**：`motor_ctrl_proc()` 在 **10ms** 主循环节拍里 `s_close_delay++`，却仍与
  10000 比较 → 10000×10ms = 100 秒才收起播料管。
- **修复**：新宏 `STEP_DELAY_CLOSE_10MS=100`（100×10ms=1s），计数处量纲对齐；宏名带单位
  防再犯。

### F6（严重）Blower_OC 位从未被置位

- **初版问题**：`sys_fault.bit.Blower_OC` 只有清零路径（`blower_hw_stop()`），没有任何置位
  路径——风机运行中堵转/过流时 FOC 自身会封锁输出，但业务层不知情：拨料轮继续转、
  红灯不报故障码、L1 不通知主机。
- **K3IN1 语义**（main.c:276-288）：100ms 节拍 `MC_GetSTMStateMotor1()==RUN` 时读相电流
  幅值与 `BLDC_OC_LEVEL` 比较置/清 `BLDC_OC`。
- **修复**（`motor_ctrl.c blower_fault_poll_100ms()` + `main.c` 100ms 节拍调用）：
  本工程 FOC 自带更细粒度保护（16k/28.5k 控制中断内锁存故障码），故做"故障码→系统故障位"
  映射：风机运行确认（`blower=2`，对应 K3IN1 的 RUN 态判据）后，
  `FOC_FAULT_OCP / OVERSPEED / FW_LOST / ISUM → Blower_OC=1` → 触发停止链 + 红灯双闪 +
  L1 拉低。`EXT_STOP`（正常停机同步）与探测段故障不映射（后者由启动重试→`Blower_Fail` 路径处理），
  `blower_hw_stop()` 保留清零（K3IN1 的 BLDC_OC 本就是非锁存位）。

### F7（严重）步进拍速常数互换 + 单位错

- **K3IN1 证据**（生产代码为 `_Loop` 非阻塞版本）：
  - `StepMotor_Control_CW_Loop`（收起）：`TimeFlag_Step100us < STEP_SPEED*10` → **4×10 tick = 4ms/拍**
  - `StepMotor_Control_CCW_Loop`（打开）：`STEP_SPEED_OPPE*10` → **2×10 tick = 2ms/拍**
  - `StepMotor_Control_xx_OnFlag`（压紧）：`STEP_SPEED_ONFLAG_TIME=100` → **100 tick = 10ms/拍**
  - TIM16 100us 中断（72MHz/72/100）证实 TimeFlag_Step100us 每 100us +1；阻塞版
    `HAL_Delay(STEP_SPEED)=4ms` 同样佐证（**HAL_Delay 是毫秒单位，头文件"×100us"注释是坑**）。
- **初版错误**：宏注释把"打开=STEP_SPEED、收起=STEP_SPEED_OPPE"（**方向对调**），且数值按
  ×100us 使用：收起 2×100us=0.2ms（快 20 倍）、打开 4×100us=0.4ms（快 5 倍）、
  压紧 0.2ms（快 50 倍）。高速冲击会导致丢步、到位判定失效、压紧失效。
- **修复**（`app_config.h` + `stepper.c`）：`STEP_SPEED_CW_TICKS=40`（4ms）、
  `STEP_SPEED_CCW_TICKS=20`（2ms）、`STEP_ONFLAG_TICKS=100`（10ms），方向对应 K3IN1；
  到位去抖同时从 2ms 改为 **20ms 连续低电平**（K3IN1 _Loop 版"读到低→HAL_Delay(20)→复查"
  的等价实现），去抖期间冻结拍推进（K3IN1 同构）。`start_run()` 复位拍时钟保证首拍周期完整。

### F8（中等）速度环 PI 限幅量纲错位

- **K3IN1**：电流反馈 `Get_ADCDCM12_Current()` 已换算为 **mA**，`SpeedPID.Maximum=MA_MAX=1100`（mA）。
- **初版**：反馈 `g_dose_current_avg` 是 **ADC 码值**（1mA≈0.62 码），限幅却仍是 1100
  → 实际限到 1100 码 ≈ 1773mA（超出设计 61%），过流保护动作点与限幅点脱节。
- **修复**：`DOSE_SPEEDPI_MAX_ADC = DOSE_MA_TO_ADC(1100) = 682` 码，给定量与反馈量同量纲；
  电流环、两级过流阈值本就为码值，全链路量纲现已一致。

### F9（中等）电流采样让出 ADC0（任务书硬约束）

- **任务书**："FOC 的 ADC 按原样执行，另外用另外两个 ADC 测量播料 PWM 电机电流和步进电机电流。"
- **初版**：ADC0 规则组（DMA0_CH0 + TIMER2 TRGO 38kHz 触发）与 FOC 的 ADC0 注入组共用同一
  ADC——规则组转换期间（约 10us@20MHz）注入触发到达会被推迟 0~3.4us，电流采样点相对
  PWM 中点抖动，FOC 电流噪声增大。
- **硬件事实**（GD32F30x UM Rev3.4 表 10-3/10-4 + GD32F303xB 数据手册引脚表，已逐一核实）：
  - ADC0 → DMA0_CH0；ADC2 → DMA1_CH4；**ADC1 没有任何 DMA 请求映射**；
  - PA3=ADC012_IN3，但 **PB0/PB1 只接 ADC0/ADC1**（ADC2 看不到步进/拨料电流脚）；
  - → "另外两个 ADC + DMA"在 GD32F30x 上**不可同时满足**，取任务书意图（FOC 独占 ADC0、
    电流采样换 ADC、不加中断打扰 FOC）的最优可行解。
- **修复方案**（`app_init.c`）：电流三通道搬到 **ADC1**，**单通道软件触发 + 100us 心跳轮询**
  （读上一拍结果 → 轮转通道 → 启动下一拍，三通道 300us 一圈）：
  - 零新增中断（复用 TIMER5 心跳，符合"尽量不加奇怪的中断打扰 FOC"）；
  - 零 DMA、零与 ADC0 的交互——ADC0 完全归 FOC（含时钟分频不再改动：`rcu_adc_clock_config`
    已由 motor_hardware.c 配 DIV4=30MHz，ADCPSC 全局共享，本修复不再触碰）；
  - 转换 8.4us(239.5+12.5 周期@30MHz) << 100us 轮询周期，无重叠；
  - ADC1 时钟 30MHz（<40MHz 上限）、上电校准照做；
  - 对 100us 电流环（配 4 样本滑动平均）、10ms 过流计时、1s 步进监测，300us 通道刷新率
    绰绰有余（K3IN1 的等效环路更慢）。

### F10（严重·条件性）重映射顺序导致 SWD 调试口可能被关闭（v2.1 新增）

- **库函数隐藏副作用**（本项目自带库 `gd32f30x_gpio.c` 375 行起，已逐行核实）：
  `gpio_pin_remap_config()` 的**普通重映射分支**（TIMER1/TIMER2 等走 397/400 行）在
  "读-改-写" AFIO_PCF0 时都会执行 `temp_reg |= ~PCF_SWJCFG_MASK`——`PCF_SWJCFG_MASK=0xF8FFFFFF`，
  取反恰为 `0x07000000`=SWJ_CFG[26:24] 三位，即**每次普通重映射都把 SWJ_CFG 硬写成 111**。
  库本意：SWJ_CFG 只写（读回不定值），RMW 必须先清垃圾再写回，填 111 是想利用
  "无效值保持现状"的语义。SWJ 分支（391-393 行）则只清/写 bit26:24 三位，其余位保留。
- **调用时序**（初版与 v2 均为：SWJ → TIMER1 → TIMER2）：SWJ 先写 010，随后两次普通
  重映射各把 SWJ_CFG 打成 111，且全工程（含 FOC/BLDC/BSP/uart.c，已全局搜索）此后再无
  AFIO_PCF0 写入点 → 最终态停在 111。
- **手册自相矛盾（关键，影响定性）**：
  - 表 8-3（调试端口映射，UM page 172）：`Other → 禁用`（两 DP 均禁用）；
  - AFIO_PCF0 寄存器位描述（同一本 UM，page~187/190 **两处**，覆盖全部子系列）：
    `其他组合：无作用`。
  - 若"无作用"为真：111 不改变调试口状态，SWD 保持 010 活着——**无 bug**（库的设计意图
    也支持此解释，否则官方库每一次 TIM2 部分重映射都会杀调试口）；若"禁用"为真：**每次
    上电 SWD 必被关闭**，J-Link/GD-Link 再连不上，需 connect under reset / 按住 NRST 连接
    后整片擦除救砖——烧录时无感是因为 Download 在复位窗口内完成，芯片跑起来后才断连。
  - 两处表述无法离线裁决，按防御性工程处理：**修**。
- **修复**（`app_init.c app_gpio_afio_init()`，零成本换位）：
  ```c
  gpio_pin_remap_config(GPIO_TIMER1_PARTIAL_REMAP1, ENABLE);  /* ① 先做普通重映射 */
  gpio_pin_remap_config(GPIO_TIMER2_PARTIAL_REMAP, ENABLE);
  gpio_pin_remap_config(GPIO_SWJ_SWDPENABLE_REMAP, ENABLE);   /* ② SWJ 必须放最后一次 */
  ```
  SWJ 分支只动 bit26:24、TIMER1/TIMER2 重映射位原样保留，最终态稳定落在 010
  （JTAG 关、SWD 活）——**两种手册解释下都严格不劣**。
- **守则**：今后新增任何重映射（如 USART 重映射），一律插在 SWJ 调用之前，或事后补一次
  SWJ 调用。`User/BSP/led.c` 的 `led_init()` 含同样的 SWJ 调用，为死代码（全工程无调用），
  且其自身语义无害，保留不动。
- **被锁后的救砖**：Keil → Debug Settings → Connect 选 *under Reset*（或手按住 NRST 点连接），
  halt 后读 `0x40010004` 的 bit[26:24] 验证，整片擦除后烧本修复版；或 BOOT0 拉高进内置
  bootloader 擦除。

### F11（致命·用户实测反馈，v2.2 新增）飞控失联时 1000/1100us 默认输出被误响应

- **现象（用户实测）**：飞控未连接时输出 S1=1000us、S2=1100us，且飞控侧默认值无法修改。
  按 K3IN1 同构窗口（us 口径）：S1=1000us 恰落 P1_OFF 窗 `[900,1000]` 上边界（含端点，
  每帧发"停排种"）；S2=1100us 落 P2_ON 开机窗 `[960,1940]` 内且命中档位表 `[1075,1125)`
  档（250rpm / Y_g=10000）——**飞控未连接，系统即被误开机、拨料 250rpm 自转**。
- **修复**（`app_config.h` 新增 `P1P2_MIN_RESP_US=1150` + `p1p2_capture.c`）：
  `decode_channel()` 换算出正脉宽后立即判定 `hi < 1150us` 则直接 return——不更新任何
  捕获字段、不置 `valid`、不清 `capture_timeout`、不产生任何命令，等效于该路信号不存在：
  - 飞控未连接（1000/1100us）→ 系统完全静默不自启动；
  - 运行中失联落到 <1150us → 沿用既有 5s 信号丢失超时自动全停，与断线行为一致；
  - 1150 = 1100（飞控失联典型值）+ 50us 裕量。
- **有意牺牲**：P1_OFF 停排种窗 `[900,1000]`、一键排种档 960~1025、0KG 两档
  1025~1125、10KG 档前半 1125~1150 均不再可达（`g_autosow_en` 恒 0，Ext_OC 解除
  联动随之固定走停机链，安全方向）；全停窗 `[1920,2230]`、1150us 以上全部档位与
  P1 随速不受影响。若现场必须使用 <1150us 指令，调小 `P1P2_MIN_RESP_US` 即可恢复
  （同时恢复失联误响应风险，需自行权衡）。
- **依赖关系**：所有 `pwm_hi_time` 使用点均有 `valid` 前置守卫（`dose_speed_update()`
  开头 `if (!g_p1.valid) return;`、`g_autosow_en` 判定含 `g_p2.valid`），过滤不更新
  字段不产生任何悬挂引用。

### F12（轻微·纯注释，v2.2 新增）P1/P2 窗口单位注释口径 2 倍错

- **问题**：v2.1 起所有窗口注释把宏值按 0.5us tick 口径换算（"P2 全停 960~1115us"、
  "P1 ON 525~1115us"、"档位表 480~970us"等）。实际代码（与 K3IN1 完全同构）是
  0.5us/tick 捕获后 **/2 换算成 us** 再与宏值比较——**宏值本身就是 us**，生效窗口即
  `[900,1000] / [1050,2230] / [1920,2230] / [960,1940] us`。数值与运行行为从未错，
  全部注释与 v2.1 笔记描述错。
- **K3IN1 侧证据**：`S1_2_PERIOD_HI=20400` 注释 "20400us,49Hz"——若按 tick 口径则成
  10.2ms/98Hz，与注释矛盾；TIM15 预分频 35（72MHz/36=2MHz，0.5us/tick）、
  `PWM_HiTime = (捕获差)/2`（"实际的时间要 *0.5us"）均已核实。
- **修复**：`app_config.h` / `p1p2_capture.c/.h` / `motor_ctrl.c` 全部窗口、档位表、
  随速公式注释统一改为 us 口径；本文件 F3 节旧换算描述同步更正。零代码行为变更。

### F13（致命·用户实测反馈，v2.3 新增）风机启动后步进限位 PA12/PA11 无人监管——K3IN1"实时检测导管位置"未移植

- **现象（用户实测反馈）**：风机转起来之后，程序就"不管 STEP_M_OFF / STEP_M_ON 了"。
- **K3IN1 原代码（全程运行，与风机状态无关）**：`System_Motor_Control()`（main.c 477-955 行）
  里有一组**持续运行的导管位置闭环**块：
  - 打开侧（`#ifdef HALL_SWV` 块，main.c 856-943 行；daMc_state.h:39 定义了 HALL_SWV，
    生产启用）：命令为开（`Command.Step_Motor==1`，由 S2-ON 窗 50Hz 持续刷新）且管子处于
    开位（`State.Step_Motor==1`）时，若 SW_V（打开限位）释放——管子受重力/振动漂离开
    限位——`StepMotor_Control_CCW_Loop()` 重压回限位，到位后 `step_ccw_temp_flag` 分支
    `StepMotor_Control_CCW_OnFlag(STEPM_UP_CCWCNT=100)` 压紧 100 步（10ms/拍）；连续
    `STEP_ERROR_CNT=30` 次找不到限位则停止尝试（vsteperror_cnt，到位即清零）。
  - 关闭侧（main.c 821-855 行 + 故障分支 558-596 行）：命令为关/故障态且管子在关位时，
    SW_H（关闭限位）释放 → `CW_Loop()` 重压 → `CW_OnFlag(STEPM_UP_CWCNT=50)` 压紧 50 步。
  - 初始打开完成时另有一轮 `step_oppe_temp_flag` → `CCW_OnFlag(100)` 压紧（main.c 679-684 行）。
- **v2.2 缺陷**：`motor_ctrl.c` 步进结果处理块被 `(0U == g_sys_state.blower)` 门控——风机
  一启动该块永久失效，PA12/PA11 从此**无任何代码读取**（`stepper.c limit_reached()` 仅在
  运动进行中被调用），停止链压紧走完后同样失管。管子漂移/被外力拨动无人纠正；步进断电
  后挡板可被重力自行拉开（出料口失控）。v2.2 注释"启动后由 monitor/fault 路径接管"不实——
  monitor/fault 两路径不含任何步进逻辑。
- **修复**（motor_ctrl.c 新增 `stepper_hold_proc()`，10ms 节拍，全状态运行）：
  - 命令方向锁存 `s_hold_dir`（K3IN1 `Command.Step_Motor` 等价）：P2-ON 接受 → 保持打开；
    P2-OFF / 信号丢失 5s / 任何停机路径 → 保持关闭；
  - 保持打开期间 PA12 释放 → `stepper_run_ccw(1140)` 重压 → 到位后压紧 100 步；
  - 保持关闭期间（含故障停机后）PA11 释放 → `stepper_run_cw(1140)` 重压 → 压紧 50 步；
  - 失败上限 `STEP_HOLD_ERR_CNT=30`（= K3IN1 `STEP_ERROR_CNT`），重压成功即清零；
  - 打开序列（风机启动前）与停止链收起期间自动让位（K3IN1 同样由各命令块自管运动）；
  - `stepper.c/.h` 新增 `stepper_is_busy() / stepper_on_limit() / stepper_off_limit()`。
- **有意保留的设计差异**：P1 排种启动仍要求风机确认（blower=2）。K3IN1 原条件是"管子已
  打开即可启动排种"，不等待风机 4s 确认；本工程保守加严，避免风机启动失败期间落料。
- **LED 说明**：无料快闪在 K3IN1 里实际被同函数后段的常亮写覆盖（main.c 326-336 行三个
  独立 if 顺序执行，快闪 Toggle 后紧跟常亮 Write）——本工程按注释意图实现为可见快闪，
  属对 K3IN1 疑似笔误的修正，如需逐位复刻请告知。

### F14（严重·用户反馈 #2 关联，v2.3 新增）L1 外部故障去抖状态机结构与 K3IN1 不符

- **用户反馈**：无料信号 PA15"也没管了"。逐环复查无料链路（`material_proc_10ms()` →
  PA15 延时 → PC13 拉低 L1 → 300ms 回声 → Ext_OC → 停止链全停），与 K3IN1
  `Content_Gauge_Signal()/OC_OUTPUT/OC_INPUT` 回环同构、链路本身存在；但去抖状态机
  有一处结构移植走样，抖动场景会让整条链路误锁/漏锁：
- **K3IN1 原结构**（`System_Fault_Signal_Proc()`，main.c 416-449 行）：边沿判断只负责
  "武装"去抖计时器；**到期检查在边沿判断之外**——每次调用都查，到期时按当时电平
  锁存/解除，随后停表并保存新稳态。
- **v2.2 缺陷**（material_s4.c `s4_fault_proc()`）：到期检查嵌在 `if (now != s_l1_last)`
  里面——线上电平抖动回旧稳态时，计时器武装后永不清零（stale）；下一次真实边沿直接
  用旧计数**瞬时锁存**（没有新的 300ms 去抖）。无料报警回环、主机故障报告在电平抖动
  场景下会误锁（无料却不停机 / 有料却报故障）或漏锁。
- **修复**：重构为 K3IN1 原结构（武装 / 到期检查分离，到期按当时电平判定后更新稳态）。

### F15（致命·本次复查新发现，v2.3）停止后无法再次开机 + P2-OFF 持续到达反复重走停止链

- **缺陷 1**：停止链收起完成（含强停路径）不清 `g_sys_state.step_open`——一次完整的
  开机→全停循环后，P2-ON 再也进不了开机块（条件要求 `step_open==0`），**必须断电重启
  才能再开机**。K3IN1 收起完成时 `System_Motor_State.Step_Motor = 0`（main.c 771-772、
  783-784 行）。
- **缺陷 2**：主机持续发 P2-OFF（协议定义 OFF 窗脉宽 50Hz 每帧刷新），v2.2 停止链每
  ~1.5s 重走一遍：重新停风机 → 1s 延时 → 重新收起已关闭压实的管子 → 再压紧 0.5s，循环
  往复，还反复打断位置监管的压紧。K3IN1 收起命令块要求 `State.Step_Motor==1`（管子
  确实开着）才动作。
- **修复**：收起完成 / 强停路径清零 `step_open`；停止链仅在"确有运转部件"（风机在转 /
  管子开着 / 拨料在转）时进入，已停稳后 P2-OFF 只维持"保持关闭"方向锁存，由 F13 监管
  接管（即 K3IN1 关闭侧实时检测语义）。

### F16（轻微，v2.3）无料恢复时 L1 释放条件与 K3IN1 不符

- K3IN1 `Content_Gauge_Signal()`（main.c 1122-1127 行）：有料持续到延时后**无条件**
  `OC_OUTPUT=RESET`（内故障拉低由 TIM16 100us 中断每次重写维持）。
- v2.2：释放带 `g_no_particles==1` 门槛。功能近似等价（内故障分支 10ms 重拉），但结构
  不一致，且 `g_no_particles==2`（内故障）时补料恢复路径的释放语义与 K3IN1 有细微差别。
- **修复**：无条件释放，内故障态由同函数 10ms 重拉维持（时标 100us→10ms 差异无影响，
  L1 线上均为秒级事件）。

### F17（致命·用户实测反馈，v2.4 新增）拨料测速每转脉冲数沿用 K3IN1 双通道合计值 → 位置斜坡恒 4× 超前 → 占空比恒 100%

- **现象（用户实测）**：拨料电机（PB5 38kHz PWM）驱动一直 100% 占空比；示波器量 PB3 霍尔
  为 266Hz 方波（电机在转、传感器在工作，但系统从不回退占空比）。
- **K3IN1 原代码证据**：
  - 测速计数器 `Speed_IT_Cnt` 由 **PB6(SpeedA) + PB7(SpeedB) 两路 EXTI 回调共同递增**
    （main.c 2555-2583 行）——K3IN1 的拨料测速是 **A/B 双通道霍尔**；
  - `RPM_CNT=20`（daMc_state.h:70）注释原文"**一圈的AB霍尔上下沿数**"——20 是
    **双通道 × 上下沿**的合计：2 通道 × 2 沿 × 5 周期/转 = 20。
- **新板硬件事实**：U7 拨料装置只引出**一路 HALL**（U7.5→PB3，2.0mm-5P）；且该线
  **下降沿**是传感器侧 NPN 主动拉低的陡峭沿，**上升沿**经电阻上拉 + C61 为 RC 平缓沿
  （用户确认"上升沿是电阻上拉比较平缓"）——故必须且已经使用下降沿计数。
- **v2.3 缺陷**：`DOSE_HALL_PULSE_PER_REV` 直接沿用 K3IN1 的 20（双通道合计），而本工程
  只在 PB3 上单通道下降沿计数——每转实际脉冲 = 20/4 = **5**。后果链：
  位置斜坡给定（dose_tick = 目标转速×114×PPR×128/120000）恒 **4×** 快于反馈可达 →
  "跟上才推进"门恒关闭、给定恒领先 20×dose_tick → 速度环误差恒饱和 → 目标电流恒为
  上限 1100mA → 空载/轻载电流误差落入 Kp×误差 ≥ 2×限幅的钉死区 → **占空比恒 100%**。
- **修复**：`DOSE_HALL_PULSE_PER_REV 20 → 5`（app_config.h，含完整推导注释）。速度环
  斜坡（dose_tick）与测速换算（DOSE_RPM_TEMP）均引用该宏——一处改、全链路自洽。
- **边沿确认**：EXTI3 本工程一直为**下降沿**（app_init.c `exti_init(EXTI_3, EXTI_INTERRUPT,
  EXTI_TRIG_FALLING)`），与用户要求一致，本版仅补注释说明物理依据，无行为变更。
- **现场标定**（如实际传感器每转脉冲 ≠ 5）：满占空比空载下示波器量 PB3 频率 F(Hz)，
  电机空载转速 N(rpm，电机轴) → 实际 PPR = F×60/N，改 `DOSE_HALL_PULSE_PER_REV` 一个宏。
  调试模式 `TELEMETRY_SELECT=2`（F19）可用 VOFA+ 直接看 实测转速/目标转速/占空比。
- **K3IN1 既有行为说明**：该级联（位置斜坡→速度 PI→电流 PI）本身较粗糙——电流误差
  ≥ ~450mA 时 K3IN1 同样占空比顶满（CurrPID.Maximum=4500、Kp=20：比例项 2× 于限幅，
  抗饱和积分只能抵消 1× 限幅）；空载台架占空比偏高/小幅锯齿属 K3IN1 原设计行为，非缺陷。

### F18（轻微，v2.4）DOSE_STARTUP 初始电流给定与 K3IN1 不一致

- K3IN1 `DCMotor_STARTUP`：`DCMotor.Target_Current = 100`（mA，main.c:1165，DCM_SPEED_LOOP
  编译分支）；v2.3 为 0。已对齐为 100mA 等效码值（DOSE_MA_TO_ADC(100)=62）——仅影响启动
  后首个 10ms 内的出力，速度环接管后无差别。

### F19（配套工具，v2.4）调试遥测新增拨料通道（TELEMETRY_SELECT=2）

- PPR 需现场标定、速度环需现场验证：motor_config.h `TELEMETRY_SELECT` 改为 2 →
  VOFA+ JustFloat 三通道 = ch1 实测转速(rpm) / ch2 目标转速(rpm) / ch3 PWM 占空比(%)。
- dosing_motor.c 新增 `g_dose_duty` 全局（dose_pwm_set 处实时更新，0~DOSE_PWM_MAX）。
- 默认仍为 1（FOC 遥测）；正式模式（NO_S1_HAVE_UART=0）整体不编译，无任何影响。

### F20（致命·用户实测反馈，v2.5 新增）无料信号 PA15 毫无作用——停机权押在 L1 电气回声环上，回环断链即静默失败

**用户实测**："无料信号 PA15 则是彻底没用，根本不影响程序运行"（v2.3 仍复现）。

**原因**：v2.3/v2.4 的无料停机链是 K3IN1 的"回声环"结构：
`PA15 低 1~2s → 报警（PC13 高 → Q9 拉低 L1 线 + 红灯快闪）→ L1 线电平回读 PB2
→ 300ms 去抖 → Ext_OC=1 → 停止链`。整条链的停机权在 **PB2 能否读到本机 Q9 的
拉低**——这要求 L1 线拓扑（U19.6 一根双向开漏线：主机拉低/本机 Q9 拉低/PB2 感知）
实际连通且有确定的高态。任一环节断链（主机未接 S4 线、线上无上拉、Q9 焊接/驱动
问题）时，报警虽然置位（PC13 高、g_no_particles=1），但 Ext_OC 永远不置位 →
**不闪灯之外的任何停机动作都不会发生**。K3IN1 原板 OC_INPUT(PB12)/OC_OUTPUT(PB13)
是两个独立 MCU 脚，环同样依赖外部接线——移植时把"回环成立"当成了隐含前提。

**修复**（不再把停机权押在电气回环上）：
1. `sys_fault_t` 新增 **No_Mat** 位（非锁存）：`material_proc_10ms()` 报警触发时
   直接置 1，恢复（补料同长延时）时清 0。停止链入口条件 `fault≠0` 天然收录 →
   拨料/风机立即停、1s 后收起导管、L1 持续拉低通知主机、红灯快闪——**无料必停机**。
2. 无料期间 No_Mat≠0 → P2-ON 拒绝开机（K3IN1 External_OC 同语义：无料不允许启动）；
   补料后延时到自动清除 → P2-ON 恢复可用，无需重新上电。
3. K3IN1 原行为全保留：PC13 拉低 L1 通知主机、红灯快闪（NoParticles 语义）、
   L1 主机拉低 → Ext_OC 外部故障路径（本机拉低期间因 No_Mat 已置 fault≠0，
   `s4_fault_proc` 按"自身回声"识别不误报 Ext_OC，K3IN1 426-429 行同款判定）。
4. 无料有效电平宏 **MAT_EMPTY_IS_LOW**（默认 1=低电平无料，K3IN1 极性）：现场
   传感器若相反，改 0 一处生效。
5. `mat_delay` 上电默认 0 → **1s**（`MAT_DELAY_BOOT_10MS`）：报警现在有直接停机权，
   上电瞬间误报的代价从"闪灯"升级为"拒绝开机"，1s 缺省更稳妥（K3IN1 上电为 0 但
   其报警只闪灯）。

### F21（致命·用户实测反馈，v2.5 新增）"STEP_M_ON 触发一下风机就一直吹"——K3IN1 对限位丢失只重压不停机

**用户实测**："只需要 STEP_M_ON 触发一下风机就一直吹，不管后续"、"STEP_M_ON 丢失后
步进会转试图重新到达 STEP_M_ON，但是风机不停，PWM 有刷电机也不停"（v2.3 仍复现）。

**原因**：这是 **K3IN1 原码的既行为**（非移植丢失）：打开侧 HALL_SWV 块（main.c
856-943）对 SW_V 释放只做 CCW_Loop 重压，`vsteperror_cnt` 到 30 次后**静默放弃，
风机照转**；"管子不在开位仍持续吹风/落料"对本机是安全问题，用户不接受。v2.3 的
F13 补齐了重压闭环（用户已实测确认步进会重压），本版补上停机权。

**修复**（stepper_hold_proc 新增看门狗，`STEP_HOLD_LOST_FAULT_10MS=300`）：
- 保持打开（s_hold_dir=1）且开机序列已结束时，PA12 连续不在"开启到位"累计 3s
  （**置于 busy 检查之前**：重压运动 2.28s 期间同样计时——若放在其后，每段重压都
  冻结计数，实际门槛被拉长到分钟级）→ **Step_Lost 锁存故障**（重新上电解除）→
  停止链：风机/拨料立即停、1s 后收起导管到 STEP_M_OFF、红灯双闪故障码。
- **3s 内重压成功（正常重力漂移自愈，通常 <0.5s）计数清零、风机不停**——保留 K3IN1
  的重压自愈行为，不会因正常漂移闪停风机；只有管子真被拔走/机构脱落才停机。
- 门限 3s > 单次完整重压行程 2.28s + 20ms 去抖：一次重压失败即判定，两次都来不及。
  现场要快/要慢改 `STEP_HOLD_LOST_FAULT_10MS` 一个值。
- 计数复位点：限位回位 / 停止链入口（一次性）/ P2-ON 打开序列发起 / 初始化；
  打开序列期间（blower=0）与停止链期间不计时（各有专属流程管辖）。
- 关闭侧（STEP_M_OFF）不加看门狗：管子未开风机本就不转，收起链 + 关闭侧监管已覆盖。

**有意行为说明**：打开序列 3 次满行程未到位仍"按已打开处理"并启动风机（K3IN1
oppesteperror_cnt>3 原语义，防限位开关损坏瘫痪整机）——但风机启动后看门狗立即
接管：若 PA12 始终不在位，3s 后 Step_Lost 锁存全停（P2-ON 被拒直至重新上电）。
即：限位开关坏 → 仍有 3 次开机尝试 + 3s 观察窗；管子真不在 → 必停。

### F22（严重·本次复查新发现，v2.5）L1/PA15 输入悬空不确定性 + LED 双闪吞掉无料快闪 + 重压上限被入口块清零

1. **L1(PB2) 改内部上拉**：L1 线为双向开漏（主机/本机 Q9 都只能拉低，板上无任何
   上拉源）——主机未接 S4 或未驱动时 PB2 悬空，电平不确定：上电可随机锁 Ext_OC
   拒绝 P2-ON；本机拉低后"回高"不可靠（v2.3/v2.4 回声环静默失效的疑点之一）。
   内部 ~40k 上拉给总线确定高态（空闲=无故障），任何主动拉低都能压过；C33(10nF)
   ×40k≈0.4ms，对 300ms 去抖无影响。
2. **PA15 改内部上拉**：传感器开集输出 + 板上 CN2.6 1k 上拉 5V；现场若 6-3 上拉
   未接/传感器未插，PA15 悬空读数不确定——上拉给出"无传感器=有料"缺省（不误报
   无料锁 P2-ON）；传感器拉低（无料）时 40k（~82uA）不影响其电平。
3. **LED 双闪条件改 `SYS_FAULT_LATCHED_MASK`**（Dose_OC|Blower_OC|Blower_Fail|
   Step_OC|Step_Reset|Step_Lost）：F20 后 No_Mat 置位若仍用 `byte≠0` 判双闪，会
   把无料快闪吞进双闪分支；No_Mat 属状态型报警走快闪（K3IN1 NoParticles 语义）。
4. **停止链入口的重压计数清零移入一次性门内**（F20 附带）：No_Mat 长期置位期间
   入口块每 10ms 执行，旧写法 `s_hold_err_open/close=0` 每 10ms 清零 → 关闭侧
   30 次重压失败上限失效（无限重压）；K3IN1 只在收起启动（759-760 行）清一次。

### 附带修复（对齐 K3IN1 语义）

1. **打开到位后 CCW 压紧**：K3IN1 打开 STEP_OVER → `step_oppe_temp_flag=1` →
   `CCW_OnFlag(STEPM_UP_CCWCNT=100)`。初版缺失 → 新增 `stepper_run_ccw_onflag()`
   （压紧与风机启动并行，不阻塞开机链）。
2. **打开失败重试**：K3IN1 `oppesteperror_cnt>3` 后按已打开处理继续流程；初版直接回待机。
   现重试 3 次后按 K3IN1 继续启动风机。
3. **无料报警延时档条件**：K3IN1 为 `(w≥S2_ON_LO && w<1425) ? 1s : 2s`，初版漏了下界。
4. **调试宏命名**：任务书要求 `NO_S1_HAVE_UART` 放 MAIN.C 可见处——已按任务书命名，
   原 `APP_DEBUG_UART_EN` 作为内部别名保留（行为不变，默认 0）。

---

## 三、修改文件清单（v2.5：12 个，均在 User/ 业务层）

```
User/main.c                     100ms 节拍接入 blower_fault_poll_100ms()（F6）、注释更新
User/app/app_config.h           F3/F5/F7/F8 宏 + NO_S1_HAVE_UART + L1_RCU 更名
User/app/app_init.c             F1/F4/F9/F10：心跳分发 + ADC1 软件轮询 + 撤销 DMA/TRGO + 重映射顺序
User/app/app_init.h             g_adc1_val[3] / app_adc1_poll_100us() 接口
User/app/dosing_motor.c         F2（斜坡条件）+ F8（限幅）+ F9（读取源）
User/app/dosing_motor.h         单位/来源注释更新
User/app/stepper.c              F7：拍速/去抖/压紧重构 + CCW 压紧 API
User/app/stepper.h              注释更新
User/app/p1p2_capture.c         F3：P2 停止窗口 + 无料延时档条件
User/app/motor_ctrl.c           F5/F6 + 打开压紧/重试语义对齐
User/app/motor_ctrl.h           blower_fault_poll_100ms() 声明
```

**未触碰**（保证 FOC 已验证行为不变）：FOC/、BLDC/、Libraries/ 全部、
User/motor_hardware.c / motor_config.h / gd32f30x_it.c、User/BSP/、
MDK-ARM 工程文件（文件集合未增删，无需改工程）。

---

## 四、验证情况

- 全部修改文件已通过 `gcc -fsyntax-only -Wall -Wextra`（真实 GD32 库头文件 +
  `GD32F30X_HD` 宏）语法与告警检查；
- 逐项与 K3IN1 原码对照确认常数/公式/时序（文中已注明出处行号）；
- GD32F30x DMA/ADC 通道映射与引脚复用已查 UM Rev3.4 与 GD32F303xB 数据手册核实；
- F10 库副作用与分支追踪已从本项目自带库源码逐行验证（gd32f30x_gpio.c:391-414，
  宏编码 TIMER1=0x00180200/TIMER2=0x001A0800 均带 PCF_LOCATION2_MASK → 走毒化分支）。

## 五、上机建议（按序）

0. **SWD 连通性（v2.1 新增）**：烧录复位后直接 attach（不按复位）验证 J-Link/GD-Link
   能正常连接——此时 SWJ_CFG 终态为 010（JTAG 关、SWD 活）；若手头芯片已被旧版固件
   锁死，用 connect under reset 连接后整片擦除再烧本版；
1. 空载烧录后先看：P2 发 1150~1940us 开机命令 → 播料管 2ms/拍打开（约 2.8s 走满行程）→
   到位停 + 压紧 1s（100 拍×10ms）→ 风机启动 4s 确认 → 绿灯 500ms 心跳；
2. P2 发 1920~2230us 全停命令 → 拨料停、风机停、**1s 后**收起（4ms/拍，约 4.6s）→ 压紧 0.5s；
3. 拨料闭环：`NO_S1_HAVE_UART=1` 时用 VOFA+ 看 `g_dose_current_avg`（码值）与
   `current_speed`（RPM）建压情况；
4. 人为堵转风机验证 F6：FOC 应报 OCP（遥测 ch1=3）→ 红灯双闪、L1 拉低、拨料联动停止。
5. **F11 失联保护验证（v2.2 新增）**：飞控不接（或运行中拔掉）→ S1=1000us/S2=1100us
   期间系统应完全静默（无任何电机动作、只有绿灯心跳）；运行中拔掉飞控 → 5s 信号丢失
   超时后应自动全停；P2 发 1149us 应无任何响应、发 1200us 应正常开机进档（若需验证
   边界，1149/1150 ±1us 抖动属正常现象）；
6. **F13 位置监管验证（v2.3 新增）**：风机运行中（或待机开位/关位）轻拨播料管使其
   离开限位（或用磁钢靠近/离开霍尔）→ 步进应在 10ms 内自动重压回位，到位后补一轮
   压紧（打开侧 100 拍×10ms=1s、关闭侧 50 拍×10ms=0.5s，可听到缓慢"哒哒"声）；
7. **F15 重启验证（v2.3 新增）**：完整走一遍 开机→风机确认→全停（收起+压紧完成）→
   再发 P2-ON：播料管应能重新打开、风机重启；全停命令持续期间不应再出现每 ~1.5s
   一次的重复收起动作；
8. **F20 无料直接停机验证（v2.5 改直连，不再依赖回声环）**：风机+拨料运行中短接
   PA15 到 GND → 1~2s（档位延时）后：红灯**快闪**、L1 线拉低（主机侧可见）→
   **拨料停 + 风机停 + 1s 后收起导管**（注意：不再有 300ms 回声等待）；无料期间
   P2-ON 应拒绝开机；松开 PA15 → 1~2s 后报警解除（快闪停、红灯回常亮），P2-ON
   可正常开机。**若快闪都不出现**：说明 PA15 没读到低——先量 PA15 电平（传感器
   极性若相反改 app_config.h 的 MAT_EMPTY_IS_LOW 为 0）；**若快闪但不停机**：
   查 motor_ctrl.c 停止链入口（fault≠0 分支）是否被执行（调试器看 s_stop_phase）。
   无料期间主机拉低 L1 仍走 Ext_OC 外部故障路径（300ms 去抖），两者语义并存。
9. **F17 拨料速度环验证（v2.4 新增）**：P2 开机 + P1 启动排种后，PB5 占空比不应再
   恒为 100%（空载台架上可能偏高甚至小幅锯齿——K3IN1 级联原设计行为，见 F17 节
   "既有行为说明"）；精确验证/标定：motor_config.h 的 TELEMETRY_SELECT 改 2，
   VOFA+ 看 ch1 实测转速应向 ch2 目标转速（档位值）收敛；若按"满占空比空载频率
   F×60÷电机空载转速 N"换算的 PPR ≠ 5，改 app_config.h 的 DOSE_HALL_PULSE_PER_REV。
10. **F21 限位丢失停机验证（v2.5 新增）**：开机（风机确认后）手动拨播料管离开
   STEP_M_ON 并保持不放 → 步进重压（K3IN1 自愈）期间风机继续转 → **持续 ~3s 后**
   风机/拨料立即全停 + 1s 后收起到 STEP_M_OFF + 红灯双闪（Step_Lost 锁存）→
   P2-ON 拒绝开机（重新上电解除）。**短拨 <3s**（模拟重力漂移）→ 重压回位后
   风机不停（不应误停）。要调整灵敏度改 app_config.h STEP_HOLD_LOST_FAULT_10MS；
   上电默认无料延时 1s（MAT_DELAY_BOOT_10MS），无料状态开机被拒属预期行为。

## 六、遗留建议（非本次修复范围）

- ~~随速公式等处 us/tick 注释混写~~ → 已于 v2.2（F12）统一为 **us** 口径：数值一直
  正确（宏值即 us），纯注释修正，无行为变更；
- 38kHz 载波目前常开（PB4）。任务书倾向"读料前开启"以省功耗；K3IN1 无此功能，
  如需改，在 `material_proc_10ms()` 前后开关 `TIMER_CHCTL2` 的 CH0EN 即可；
- ADC1 轮询值若需用于更高速率控制，可评估 TIMER2 TRGO 直触发 ADC1（无 DMA，EOC 中断
  读取）方案——但会引入 38kHz 中断，与"不打扰 FOC"相悖，故未采用。
