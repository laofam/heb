/*******************************************************************************
 * 版权所有 (C)2015, LINKO SEMICONDUCTOR Co.ltd
 *
 * 文件名称： pwm_highlevel_capture.c
 * 文件标识：
 * 内容摘要： 基于 TIMER0/TIMER1(八分频) 的 PWM 计时模块（三路高电平硬件捕获 + P1.0 频率测量）
 * 其它说明： 无
 * 当前版本： V 1.5
 * 作    者： AutoGen
 * 完成日期： 2026年7月20日
 *
 * 修改日期      版本号          修改人            修改内容
 -----------------------------------------------------------------------------
 2026/7/20      V1.0           AutoGen           创建
 2026/7/20      V1.1           AutoGen           改为 P2.3/2.4/2.5 硬件捕获 + P1.0 轮询
 * 2026/7/20      V1.2           AutoGen           TIMER0 改为满 16 位自由计数，P1.0 仅在
 *                                                TIMER0 溢出(~5.46ms)顺带轮询，彻底不干扰三路捕获
 * 2026/7/20      V1.3           AutoGen           P1.0 轮询改为由 TIMER3 38K 过零中断驱动
 *                                                （38K 任务函数 PWM_HighLevel_38K_Exec），TIMER0 专用于 P2.3 捕获
 * 2026/7/20      V1.4           AutoGen           P1.0 由“高电平测量”改为“频率测量”：
 *                                                相邻上升沿周期换算频率，每 10 次求平均，
 *                                                新增 PWM_HighLevel_GetP10Freq() 接口
 * 2026/7/20      V1.5           AutoGen           修复 P1.0 频率测量时间戳并发 BUG：
 *                                                TIMER0 中断可抢占 38K 任务并使 g_ovf0++，
 *                                                读 g_ovf0/CNT 非原子会造成 ±一个 TH(5.46ms)
 *                                                跳变；改用 seqlock 双读 + g_ovf0 volatile
 *******************************************************************************/
#include "hardware_config.h"
#include "pwm_highlevel_capture.h"
#include "adc_sample.h"   /* 新增：两路 ADC 采样（OPA0 差分 + P0.3/CH7），38K 交替采样 */

/* ============================ 内部状态 ============================ */
/* 16 位定时器溢出后的扩展高位计数（每个定时器独立） */
/* g_ovf0 会被 TIMER3(38K) 中断跨中断读取（P1.0 频率测量），且 TIMER0 中断可抢占
   TIMER3，故声明为 volatile，配合 38K 里的 seqlock 双读，避免读到中途值。 */
static volatile u32 g_ovf0 = 0;   /* TIMER0 溢出次数 */
static u32          g_ovf1 = 0;   /* TIMER1 溢出次数（仅在 TIMER1 中断内使用，无需 volatile） */

/* 各通道测量状态 */
static u8       g_rise_ok[PWM_CH_NUM] = {0};     /* 是否已捕获上升沿（等待下降沿） */
static u8       g_have_rise[PWM_CH_NUM] = {0};   /* 是否已记录过至少一次上升沿（用于算周期） */
static unsigned long long g_rise_abs[PWM_CH_NUM] = {0}; /* 上升沿时刻的 64 位时间戳(tick) */
static u32      g_last_us[PWM_CH_NUM]  = {0};     /* 最近一次测得的高电平宽度(us) */
static u32      g_last_period_us[PWM_CH_NUM] = {0}; /* 最近一次测得的周期(us) = 相邻上升沿间隔 */
static u8       g_period_valid[PWM_CH_NUM] = {0};/* 周期是否有效（已测得至少一个完整周期） */
static u8       g_updated[PWM_CH_NUM]  = {0};     /* 是否有新的有效测量 */
static u8       g_edge_level[PWM_CH_NUM] = {0xFF,0xFF,0xFF,0xFF}; /* 上次记录的引脚电平(0/1)，0xFF=未知，用于去重同向沿 */
static volatile u32 g_last_edge_38k[PWM_CH_NUM] = {0}; /* 最近一次有效沿时的 38K 时标，用于信号丢失清零 */

static u8       g_p10_last = 0;                   /* P1.0 上一采样时刻电平 0/1 */
static u32      g_t38k_cnt = 0;                   /* 38K 任务自启动以来累计执行次数(每 38K 周期 +1) */

/* ---- P1.0 频率测量状态（相邻上升沿周期 -> 频率，每 N 次求平均） ---- */
static u8                 g_p10_rise_ok   = 0;    /* 是否已记录到“上一个上升沿”时间戳 */
static unsigned long long g_p10_last_rise = 0;    /* 上一个上升沿的 64 位时间戳(tick) */
static unsigned long long g_p10_period_sum = 0;   /* 已累计的周期 tick 之和 */
static u32                g_p10_period_cnt = 0;    /* 已累计的周期个数(0..PWM_P10_AVG_COUNT) */
static u32                g_p10_freq_hz   = 0;     /* 最近一次算出的平均频率(Hz) */
static u8                 g_p10_freq_new  = 0;     /* 是否有新的平均频率(读 GetP10Freq 后清零) */

/*******************************************************************************
 函数名称：    unsigned long long pwm_extend(u16 cap, u32 ovf, u8 zero_pending, u32 th)
 功能描述：    将一次捕获的 16 位 CNT 值扩展为 64 位绝对 tick
 说明：        cap=捕获到的 CNT；ovf=已处理本次 ZERO 后的溢出次数；
              zero_pending=本次 ISR 是否同时有 ZERO(溢出)标志；th=该定时器计数模值。
              当“溢出”与“捕获”标志同时出现时，用 cap 与 th/2 比较可无歧义地判定
              该捕获发生在本次溢出之前还是之后（捕获发生在溢出前 -> 减一个 th）。
 *******************************************************************************/
static unsigned long long pwm_extend(u16 cap, u32 ovf, u8 zero_pending, u32 th)
{
    unsigned long long base = (unsigned long long)ovf * (unsigned long long)th;
    if (zero_pending && ((u32)cap > (th >> 1)))
        base -= (unsigned long long)th;   /* 捕获发生在本次溢出之前 */
    return base + (unsigned long long)cap;
}

/*******************************************************************************
 函数名称：    void PWM_HighLevel_InvokeCallback(u8 ch, u32 high_us)
 功能描述：    根据通道号分派到对应的空白回调函数
 *******************************************************************************/
static void PWM_HighLevel_InvokeCallback(u8 ch, u32 high_us)
{
    switch (ch)
    {
        case PWM_CH_P10: PWM_HighLevel_P10_Callback(high_us); break;
        case PWM_CH_P23: PWM_HighLevel_P23_Callback(high_us); break;
        case PWM_CH_P24: PWM_HighLevel_P24_Callback(high_us); break;
        case PWM_CH_P25: PWM_HighLevel_P25_Callback(high_us); break;
        default: break;
    }
}

/*******************************************************************************
 函数名称：    void PWM_ProcessEdge(u8 ch, unsigned long long abs_tick, u8 level_high)
 功能描述：    处理一次边沿；level_high=1 表示刚发生上升沿，=0 表示刚发生下降沿。
              检测到完整的“上升沿->下降沿”组合后，计算高电平宽度并调用回调。
 *******************************************************************************/
static void PWM_ProcessEdge(u8 ch, unsigned long long abs_tick, u8 level_high)
{
    /* 去重/去抖：仅在电平确实发生翻转(与上次记录不同)时才处理。
       消除边沿振铃或 GPIO 回读竞争导致的“同向重复沿”——否则一次多余的
       上升沿会覆盖真正的起始时间戳，把高电平误算成很短的值(典型如 34us)。
       单次回读错误只会漏掉一次测量，下个真实翻转即自动重新同步。 */
    if (g_edge_level[ch] == level_high)
        return;
    g_edge_level[ch] = level_high;

    /* 记录本次有效沿的 38K 时标，供 38K 任务判定“信号丢失”后清零读数 */
    g_last_edge_38k[ch] = g_t38k_cnt;

    if (level_high)
    {
        /* 上升沿：若已有“上一上升沿”，二者之差即一个完整周期(us) */
        if (g_have_rise[ch])
        {
            unsigned long long period = abs_tick - g_rise_abs[ch];
            if (period <= (unsigned long long)PWM_CAPTURE_MAX_HIGH_TICKS)
            {
                g_last_period_us[ch] = (u32)(period / (unsigned long long)PWM_TICKS_PER_US);
                g_period_valid[ch]   = 1;
            }
        }
        g_rise_abs[ch]   = abs_tick;   /* 更新为本次上升沿时间戳（供下降沿算高电平 & 下次算周期） */
        g_have_rise[ch]  = 1;
        g_rise_ok[ch]    = 1;
    }
    else
    {
        if (g_rise_ok[ch])
        {
            unsigned long long high = abs_tick - g_rise_abs[ch];
            g_rise_ok[ch] = 0;

            /* 仅在量程内（<=100ms）才认为有效，避免异常长低电平误报 */
            if (high <= (unsigned long long)PWM_CAPTURE_MAX_HIGH_TICKS)
            {
                u32 us = (u32)(high / (unsigned long long)PWM_TICKS_PER_US); /* 12 ticks = 1us */
                g_last_us[ch] = us;
                g_updated[ch] = 1;
                PWM_HighLevel_InvokeCallback(ch, us);
            }
        }
    }
}

/*******************************************************************************
 函数名称：    void PWM_HighLevel_Init(void)
 功能描述：    初始化 TIMER0/TIMER1（八分频）与 4 路被测引脚
 *******************************************************************************/
void PWM_HighLevel_Init(void)
{
    GPIO_InitTypeDef     GPIO_InitStruct;
    TIM_TimerInitTypeDef TIM_InitStruct;
    u8 i;

    /* ---- 1. P2.3/P2.4/P2.5 配置为 TIMER0/1 捕获输入（复用 TIMER0/1） ---- */
    /* 注意：必须显式指定 GPIO_Pin，否则 GPIO_StructInit 默认 GPIO_Pin_NONE 会使
       GPIO_Init 不配置任何引脚（GPIO 方向保持复位态，捕获可能收不到信号）。 */
    GPIO_StructInit(&GPIO_InitStruct);
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN;
    GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_NOPULL;
    GPIO_InitStruct.GPIO_Pin  = GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5;
    GPIO_Init(GPIO2, &GPIO_InitStruct);                     /* P2.3/4/5 设为输入（捕获） */
    GPIO_PinAFConfig(GPIO2, GPIO_PinSource_3, AF7_TIMER01); /* P2.3 -> TIM0_CH1 */
    GPIO_PinAFConfig(GPIO2, GPIO_PinSource_4, AF7_TIMER01); /* P2.4 -> TIM1_CH0 */
    GPIO_PinAFConfig(GPIO2, GPIO_PinSource_5, AF7_TIMER01); /* P2.5 -> TIM1_CH1（捕获，已恢复） */

    /* ---- 1b. P0.7 复用为 UART1_TXD（UART 从 P2.5 迁至 P0.7；弃用 RTT，改串口输出调试数据）----
       调试数据经 UART1(P0.7 TXD, 115200-8-N-1) 阻塞发送，发送期间不关中断，对换相零干扰。
       P2.5 已恢复为 TIM1_CH1 捕获（见上），UART 不再占用 P2.5。 */
    GPIO_StructInit(&GPIO_InitStruct);
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;             /* UART TX 为输出 */
    GPIO_InitStruct.GPIO_Pin  = GPIO_Pin_7;
    GPIO_Init(GPIO0, &GPIO_InitStruct);
    GPIO_PinAFConfig(GPIO0, GPIO_PinSource_7, AF4_UART);   /* P0.7 -> UART1_TXD */

    /* ---- 2. P1.0 配置为普通输入（轮询方式测量，无 TIMER 复用） ---- */
    GPIO_StructInit(&GPIO_InitStruct);
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN;
    GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_NOPULL;
    GPIO_InitStruct.GPIO_Pin  = GPIO_Pin_0;
    GPIO_Init(GPIO1, &GPIO_InitStruct);                     /* P1.0 输入（无复用） */

    /* ---- 3. TIMER0: 八分频, 满 16 位自由计数(TH=0xFFFF), CH1 双沿捕获(P2.3),
                       ZERO 中断仅作 64 位时间戳扩展（P1.0 轮询已移至 TIMER3 38K 任务） ---- */
    TIM_TimerStrutInit(&TIM_InitStruct);
    TIM_InitStruct.EN                 = ENABLE;
    TIM_InitStruct.Timer_CH0_WorkMode = TIMER_OPMode_CMP;    /* CH0 未用 */
    TIM_InitStruct.Timer_CH0_CapMode  = TIMER_CapMode_None;
    TIM_InitStruct.Timer_CH1_WorkMode = TIMER_OPMode_CAP;    /* CH1 捕获模式 */
    TIM_InitStruct.Timer_CH1_CapMode  = TIMER_CapMode_RiseFall; /* 双沿捕获 */
    TIM_InitStruct.Timer_TH           = PWM_T0_TH;
    TIM_InitStruct.Timer_ClockDiv     = PWM_CAPTURE_TIMER_DIV; /* 96M/8 = 12MHz */
    TIM_InitStruct.Timer_Filter0      = PWM_CAPTURE_FILTER;    /* CH0 数字滤波（未用，一并配置） */
    TIM_InitStruct.Timer_Filter1      = PWM_CAPTURE_FILTER;    /* CH1(P2.3) 数字滤波，抗边沿振铃 */
    TIM_InitStruct.Timer_IRQEna       = Timer_IRQEna_CH1 | Timer_IRQEna_Zero;
    TIM_TimerInit(TIMER0, &TIM_InitStruct);
    TIM_TimerCmd(TIMER0, ENABLE);

    /* ---- 4. TIMER1: 八分频, 16 位满程, CH0 双沿捕获(P2.4), CH1 双沿捕获(P2.5), ZERO 中断作溢出计数 ---- */
    TIM_TimerStrutInit(&TIM_InitStruct);
    TIM_InitStruct.EN                 = ENABLE;
    TIM_InitStruct.Timer_CH0_WorkMode = TIMER_OPMode_CAP;
    TIM_InitStruct.Timer_CH0_CapMode  = TIMER_CapMode_RiseFall;
    TIM_InitStruct.Timer_CH1_WorkMode = TIMER_OPMode_CAP;
    TIM_InitStruct.Timer_CH1_CapMode  = TIMER_CapMode_RiseFall;
    TIM_InitStruct.Timer_TH           = PWM_T1_TH;
    TIM_InitStruct.Timer_ClockDiv     = PWM_CAPTURE_TIMER_DIV;
    TIM_InitStruct.Timer_Filter0      = PWM_CAPTURE_FILTER;    /* CH0(P2.4) 数字滤波，抗边沿振铃（关键） */
    TIM_InitStruct.Timer_Filter1      = PWM_CAPTURE_FILTER;    /* CH1(P2.5) 数字滤波，抗边沿振铃 */
    TIM_InitStruct.Timer_IRQEna       = Timer_IRQEna_All;
    TIM_TimerInit(TIMER1, &TIM_InitStruct);
    TIM_TimerCmd(TIMER1, ENABLE);

    /* ---- 5. 状态初始化 ---- */
    g_ovf0 = 0;
    g_ovf1 = 0;
    for (i = 0; i < PWM_CH_NUM; i++)
    {
        g_rise_ok[i]      = 0;
        g_have_rise[i]    = 0;
        g_rise_abs[i]     = 0;
        g_last_us[i]      = 0;
        g_last_period_us[i] = 0;
        g_period_valid[i] = 0;
        g_updated[i]      = 0;
        g_edge_level[i]   = 0xFF;   /* 电平未知，等待首个真实翻转 */
        g_last_edge_38k[i] = 0;
    }
    /* P1.0 以当前电平为初值，避免上电瞬间误判边沿（等待下一个上升沿） */
    g_p10_last = (GPIO_ReadInputDataBit(GPIO1, GPIO_Pin_0) == Bit_SET) ? 1u : 0u;

    /* P1.0 频率测量状态复位 */
    g_p10_rise_ok    = 0;
    g_p10_last_rise  = 0;
    g_p10_period_sum = 0;
    g_p10_period_cnt = 0;
    g_p10_freq_hz    = 0;
    g_p10_freq_new   = 0;
}

/*******************************************************************************
 函数名称：    void PWM_HighLevel_Timer0IRQ(void)
 功能描述：    由 UTIMER0_IRQHandler 调用：
               处理 ZERO(溢出计数，供 P2.3 时间戳扩展) 与 CH1(P2.3 硬件捕获)
 *******************************************************************************/
void PWM_HighLevel_Timer0IRQ(void)
{
    u32 cnt = TIM_Timer_GetCount(TIMER0);
    u8  zero_pending = (TIM_GetIRQFlag(TIMER0, TIMER_IF_ZERO) != 0) ? 1u : 0u;

    /* 过零(16 位溢出)：递增扩展高位，作为 P2.3 捕获的 64 位时间戳“高位” */
    if (zero_pending)
    {
        g_ovf0++;
        TIM_ClearIRQFlag(TIMER0, TIMER_IF_ZERO);
    }

    /* ---- P2.3 (TIMER0 CH1) 硬件捕获（高精度，1 tick ≈ 83ns） ---- */
    if (TIM_GetIRQFlag(TIMER0, TIMER_IF_CH1))
    {
        u16 cap = (u16)TIM_Timer_GetCMPT1(TIMER0);
        unsigned long long abs = pwm_extend(cap, g_ovf0, zero_pending, PWM_T0_TH);
        u8  lvl = (GPIO_ReadInputDataBit(GPIO2, GPIO_Pin_3) == Bit_SET) ? 1u : 0u;
        TIM_ClearIRQFlag(TIMER0, TIMER_IF_CH1);
        PWM_ProcessEdge(PWM_CH_P23, abs, lvl);
    }
}

/*******************************************************************************
 函数名称：    void PWM_HighLevel_38K_Exec(void)
 功能描述：    38K 周期任务（由 UTIMER3_IRQHandler 调用，约每 26.3us 一次）：
               当前实现 P1.0 频率测量（相邻上升沿周期 -> 频率，每 N 次求平均）；
               后续可在此继续添加其它需要在 38K 节拍上执行的任务。
 说明：        每 38K 节拍采样一次 P1.0 电平，检测到“上升沿”(0->1)时用 TIMER0 的
               12MHz 64 位时基打时间戳；相邻两个上升沿之差即为一个周期(tick)。
               连续累计 PWM_P10_AVG_COUNT 个周期后取平均，换算为平均频率(Hz)。
               采样率 38K -> 可测最高频率约 19kHz(奈奎斯特)；本函数运行在独立的
               TIMER3 中断(优先级最低)，不影响 P2.3/2.4/2.5 三路捕获。
 *******************************************************************************/
void PWM_HighLevel_38K_Exec(void)
{
    g_t38k_cnt++;            /* 每进入一次 38K 任务 +1，可用于后续周期任务的节拍计数 */

    /* ---- 三路捕获“信号丢失”检测：超时未收到新沿则清零读数 ----
       避免被测信号停止后仍显示上一次的旧值（用户反馈“无信号仍保持输出”）。 */
    {
        u8 c;
        for (c = PWM_CH_P23; c <= PWM_CH_P25; c++)
        {
            if ((u32)(g_t38k_cnt - g_last_edge_38k[c]) > PWM_SIGNAL_TIMEOUT_38K)
            {
                g_last_us[c]        = 0;
                g_last_period_us[c] = 0;
                g_period_valid[c]   = 0;
                g_rise_ok[c]        = 0;
                g_have_rise[c]      = 0;
                g_edge_level[c]     = 0xFF;   /* 复位电平状态，信号恢复后重新同步 */
            }
        }
    }

    /* ---- P1.0 频率测量：38K 节拍采样电平，检测上升沿并累计周期求平均频率 ---- */
    {
        u8 lvl = (GPIO_ReadInputDataBit(GPIO1, GPIO_Pin_0) == Bit_SET) ? 1u : 0u;

        /* 仅在“上升沿”(上一次为低、本次为高)时刻处理 */
        if (lvl && !g_p10_last)
        {
            /* seqlock 双读：TIMER0 中断(优先级更高)可抢占本 38K 任务并使 g_ovf0++，
               若读 cnt 前后 g_ovf0 不一致说明期间发生了溢出，重读以保证 ovf 与 cnt
               属于同一溢出周期，避免时间戳出现 ±一个 TH(≈5.46ms) 的错位。 */
            u32 ovf, cnt, ovf2;
            do {
                ovf  = g_ovf0;
                cnt  = TIM_Timer_GetCount(TIMER0);
                ovf2 = g_ovf0;
            } while (ovf != ovf2);
            unsigned long long abs = (unsigned long long)ovf * (unsigned long long)PWM_T0_TH
                                   + (unsigned long long)cnt;

            if (g_p10_rise_ok)
            {
                unsigned long long period = abs - g_p10_last_rise; /* 一个完整周期(tick) */

                /* 有效性过滤：周期须 >0 且不超过量程(对应频率不低于 ~10Hz)，
                   避免异常长间隔(如无信号)污染平均值 */
                if (period > 0 && period <= (unsigned long long)PWM_CAPTURE_MAX_HIGH_TICKS)
                {
                    g_p10_period_sum += period;
                    g_p10_period_cnt++;

                    if (g_p10_period_cnt >= PWM_P10_AVG_COUNT)
                    {
                        /* 平均频率 = N 个周期的总时间对应的频率：
                           freq = N * Ftimer / sum(period)  （用 64 位除法防溢出） */
                        unsigned long long num = (unsigned long long)PWM_CAPTURE_TIMER_FREQ_HZ
                                               * (unsigned long long)PWM_P10_AVG_COUNT;
                        g_p10_freq_hz  = (u32)(num / g_p10_period_sum);
                        g_p10_freq_new = 1;
                        PWM_HighLevel_P10_Callback(g_p10_freq_hz); /* 频率作为参数回调 */

                        g_p10_period_sum = 0;
                        g_p10_period_cnt = 0;
                    }
                }
                else
                {
                    /* 周期异常(超量程)：重新开始累计，避免误差累积 */
                    g_p10_period_sum = 0;
                    g_p10_period_cnt = 0;
                }
            }

            g_p10_last_rise = abs;
            g_p10_rise_ok   = 1;
        }

        g_p10_last = lvl;   /* 更新上一次采样电平，供下次沿判定 */
    }

    /* ---- P1.0 频率测量之外的 38K 任务：两路 ADC 交替采样（读回上一触发 + 触发另一路） ---- */
    PWM_ADC_38KStep();

    /* 注意：35BYJ46 步进走步已不再由本 38K ISR 驱动（TIMER3 过零中断已按旧版“会转”工程关闭），
       改由 DebugPWM_OutputFunction() 主循环轮询 TIMER3 CNT 按 STEPPER_DIV 节拍驱动，避免 38K ISR 干扰无刷换相。 */

    /* TODO: 后续可在此添加其它 38K 周期任务（如其它引脚轮询、软件定时等） */
}

/*******************************************************************************
 函数名称：    void PWM_HighLevel_Timer1IRQ(void)
 功能描述：    由 UTIMER1_IRQHandler 调用：
               处理 ZERO(溢出计数) 与 CH0(P2.4)/CH1(P2.5) 硬件捕获
 *******************************************************************************/
void PWM_HighLevel_Timer1IRQ(void)
{
    u8 zero_pending = (TIM_GetIRQFlag(TIMER1, TIMER_IF_ZERO) != 0) ? 1u : 0u;

    if (zero_pending)
    {
        g_ovf1++;
        TIM_ClearIRQFlag(TIMER1, TIMER_IF_ZERO);
    }

    /* ---- P2.4 (TIMER1 CH0) 硬件捕获 ---- */
    if (TIM_GetIRQFlag(TIMER1, TIMER_IF_CH0))
    {
        u16 cap = (u16)TIM_Timer_GetCMPT0(TIMER1);
        unsigned long long abs = pwm_extend(cap, g_ovf1, zero_pending, PWM_T1_TH);
        u8  lvl = (GPIO_ReadInputDataBit(GPIO2, GPIO_Pin_4) == Bit_SET) ? 1u : 0u;
        TIM_ClearIRQFlag(TIMER1, TIMER_IF_CH0);
        PWM_ProcessEdge(PWM_CH_P24, abs, lvl);
    }

    /* ---- P2.5 (TIMER1 CH1) 硬件捕获：已恢复（UART1 改走 P0.7，P2.5 不再被 UART 占用）---- */
    if (TIM_GetIRQFlag(TIMER1, TIMER_IF_CH1))
    {
        u16 cap = (u16)TIM_Timer_GetCMPT1(TIMER1);
        unsigned long long abs = pwm_extend(cap, g_ovf1, zero_pending, PWM_T1_TH);
        u8  lvl = (GPIO_ReadInputDataBit(GPIO2, GPIO_Pin_5) == Bit_SET) ? 1u : 0u;
        TIM_ClearIRQFlag(TIMER1, TIMER_IF_CH1);
        PWM_ProcessEdge(PWM_CH_P25, abs, lvl);
    }
}

/*******************************************************************************
 函数名称：    u32 PWM_HighLevel_GetUs(u8 ch)
 功能描述：    读取最近一次测得的高电平宽度（微秒）
 *******************************************************************************/
u32 PWM_HighLevel_GetUs(u8 ch)
{
    if (ch >= PWM_CH_NUM) return 0;
    return g_last_us[ch];
}

/*******************************************************************************
 函数名称：    u32 PWM_HighLevel_GetPeriodUs(u8 ch)
 功能描述：    读取最近一次测得的周期（微秒）= 相邻两个上升沿的时间差。
 *******************************************************************************/
u32 PWM_HighLevel_GetPeriodUs(u8 ch)
{
    if (ch >= PWM_CH_NUM) return 0;
    return g_last_period_us[ch];
}

/*******************************************************************************
 函数名称：    u8 PWM_HighLevel_IsUpdated(u8 ch)
 功能描述：    查询指定通道是否有新的有效测量（读取后清除标志）
 *******************************************************************************/
u8 PWM_HighLevel_IsUpdated(u8 ch)
{
    u8 ret = 0;
    if (ch < PWM_CH_NUM)
    {
        ret = g_updated[ch];
        g_updated[ch] = 0;
    }
    return ret;
}

/*******************************************************************************
 函数名称：    u32 PWM_HighLevel_Get38KTick(void)
 功能描述：    读取 38K 任务累计执行次数（每 38K 周期 +1），供后续扩展任务计时
 *******************************************************************************/
u32 PWM_HighLevel_Get38KTick(void)
{
    return g_t38k_cnt;
}

/*******************************************************************************
 函数名称：    u8 PWM_HighLevel_GetP10Freq(u32 *p_freq_hz)
 功能描述：    读取 P1.0 最近一次的平均频率（每 PWM_P10_AVG_COUNT 个周期更新一次），
               频率(Hz)通过参数 p_freq_hz 带出。
 返回值：      1=自上次调用以来有新的平均频率；0=暂无新值（仍返回最近保存值）。
 *******************************************************************************/
u8 PWM_HighLevel_GetP10Freq(u32 *p_freq_hz)
{
    u8 is_new = g_p10_freq_new;
    if (p_freq_hz != 0)
    {
        *p_freq_hz = g_p10_freq_hz;   /* 无有效测量时为 0 */
    }
    g_p10_freq_new = 0;               /* 读取后清除“新值”标志 */
    return is_new;
}

/* ===================== 各通道空白回调（留待以后实现） ===================== */
void PWM_HighLevel_P10_Callback(u32 freq_hz)
{
    (void)freq_hz;   /* 此处留待后续实现：P1.0 每算出一次平均频率(Hz)后的业务逻辑 */
}
void PWM_HighLevel_P23_Callback(u32 high_us)
{
    (void)high_us;   /* 此处留待后续实现：P2.3 高电平计时完成后的业务逻辑 */
}
void PWM_HighLevel_P24_Callback(u32 high_us)
{
    (void)high_us;   /* 此处留待后续实现：P2.4 高电平计时完成后的业务逻辑 */
}
void PWM_HighLevel_P25_Callback(u32 high_us)
{
    (void)high_us;   /* 此处留待后续实现：P2.5 高电平计时完成后的业务逻辑 */
}

/************************ (C) COPYRIGHT LINKO SEMICONDUCTOR *****END OF FILE****/
