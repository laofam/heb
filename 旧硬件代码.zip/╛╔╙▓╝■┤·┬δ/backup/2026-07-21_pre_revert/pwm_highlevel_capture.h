/*******************************************************************************
 * 版权所有 (C)2015, LINKO SEMICONDUCTOR Co.ltd
 *
 * 文件名称： pwm_highlevel_capture.h
 * 文件标识：
 * 内容摘要： 基于 TIMER0/TIMER1(八分频) 的 PWM 高电平计时模块头文件（三路硬件捕获 + P1.0 低精度轮询）
 * 其它说明： 无
 * 当前版本： V 1.2
 * 作    者： AutoGen
 * 完成日期： 2026年7月20日
 *
 * 设计要点（详见 程序说明.md）：
 *   引脚分配：P1.0 轮询 / P2.3 = TIMER0_CH1 / P2.4 = TIMER1_CH0 / P2.5 = TIMER1_CH1。
 *   - P2.3/2.4/2.5 使用 TIMER 硬件“双沿捕获”（TIMER0_CH1、TIMER1_CH0/CH1），
 *     捕获值锁存到 CMPTx，分辨率 1 tick（12MHz 下约 83ns）。
 *   - P1.0 无 TIMER 捕获复用，故在 TIMER3 的 38K 过零中断里轮询其电平边沿（38K 任务函数
 *     PWM_HighLevel_38K_Exec）：轮询周期 = TIMER3 溢出 ≈ 26.3us（38K）。
 *     该中断与 TIMER0/1 捕获完全独立且优先级更低，不影响 P2.3/2.4/2.5 三个硬件捕获。
 *   - P1.0 测量方式为“频率测量”：检测相邻两个上升沿之间的时间差得到一个周期，
 *     进而换算频率；连续测得 PWM_P10_AVG_COUNT(=10) 个周期后取平均，得到平均频率(Hz)，
 *     通过 PWM_HighLevel_GetP10Freq() 读取。边沿时间戳复用 TIMER0 的 12MHz 64 位时基。
 *   定时器分频：TIMER0/TIMER1 均 96MHz/8 = 12MHz（满足“TIMER0 八分频”要求）。
 *   量程：TIMER0/1 为 16 位计数器，故用“溢出计数 + 16 位 CNT”拼成 64 位时间戳，
 *         最大可测高电平 100ms（1.2M tick ≪ 2^64），且对 16 位溢出做了无歧义处理。
 *
 * 修改日期      版本号          修改人            修改内容
 -----------------------------------------------------------------------------
 2026/7/20      V1.0           AutoGen           创建（TIMER0 计时基准 + 轮询方案）
 2026/7/20      V1.1           AutoGen           改为 P2.3/2.4/2.5 硬件捕获 + P1.0 轮询
 * 2026/7/20      V1.2           AutoGen           TIMER0 改为满 16 位自由计数，P1.0 仅在
 *                                                TIMER0 溢出(~5.46ms)顺带轮询，彻底不干扰三路捕获
 * 2026/7/20      V1.3           AutoGen           P1.0 轮询改为由 TIMER3 38K 过零中断驱动
 *                                                （38K 任务函数 PWM_HighLevel_38K_Exec），TIMER0 专用于 P2.3 捕获
 * 2026/7/20      V1.4           AutoGen           P1.0 由“高电平测量”改为“频率测量”：
 *                                                相邻上升沿周期换算频率，每 10 次求平均，
 *                                                新增 PWM_HighLevel_GetP10Freq() 接口
 *******************************************************************************/
#ifndef __PWM_HIGHLEVEL_CAPTURE_H
#define __PWM_HIGHLEVEL_CAPTURE_H

#include "lks32mc05x_tim.h"
#include "lks32mc05x_gpio.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ============================ 配置宏 ============================ */
/* TIMER0 / TIMER1 均采用 96MHz/8 = 12MHz（八分频）计时基准 */
#define PWM_CAPTURE_TIMER_DIV       TIM_Clk_Div8
#define PWM_CAPTURE_TIMER_FREQ_HZ   (96000000uL / 8uL)                /* 12 MHz */
#define PWM_TICKS_PER_US            (PWM_CAPTURE_TIMER_FREQ_HZ / 1000000uL) /* 12 ticks/us */

/* TIMER0 计数模值：与 TIMER1 一致，采用满 16 位自由计数(0xFFFF)。
   目的：TIMER0 专用于 P2.3 高精度硬件捕获，溢出仅用于 64 位时间戳扩展；
   P1.0 的轮询已移至 TIMER3 的 38K 中断(见 PWM_HighLevel_38K_Exec)，此处不再承担 P1.0，
   从而 TIMER0 中断仅服务于 P2.3 捕获，不影响三路捕获。 */
#define PWM_T0_TH                   ((u32)0xFFFFu)
/* TIMER1 用满 16 位自由计数（0xFFFF），捕获量程最远，靠溢出计数扩展时间 */
#define PWM_T1_TH                   ((u32)0xFFFFu)

/* 最大可测量高电平：100ms -> 1.2M ticks（远小于 2^64） */
#define PWM_CAPTURE_MAX_HIGH_MS     ((u32)100u)
#define PWM_CAPTURE_MAX_HIGH_TICKS  ((unsigned long long)(PWM_CAPTURE_TIMER_FREQ_HZ / 1000uL) * \
                                     (unsigned long long)PWM_CAPTURE_MAX_HIGH_MS)

/* P1.0 频率测量：连续测得多少个上升沿周期后取平均（每 N 次得到一个平均频率） */
#define PWM_P10_AVG_COUNT           ((u32)10u)

/* 三路捕获输入数字滤波值(0~15)：滤波宽度 = 值×8 个系统时钟(96MHz)。
   取 15 => 15×8/96MHz ≈ 1.25us，远小于待测 ms 级脉宽（对上升/下降沿延时相同、
   高电平测量不受影响），可最大限度抑制被测引脚(尤其 P2.4)的边沿振铃/毛刺——
   否则毛刺产生的假沿会把高电平误算成很短的值（例如 P2.4 恒为 34us）。 */
#define PWM_CAPTURE_FILTER          ((u8)15u)

/* 三路捕获“信号丢失”判定：连续多少个 38K 节拍(≈26.3us)未收到新的有效沿
   即认为信号已消失，将该路读数清零（避免无信号时仍显示上一次旧值）。
   约 300ms：300ms / 26.3us ≈ 11400 */
#define PWM_SIGNAL_TIMEOUT_38K      ((u32)11400u)

/* 通道索引（与引脚一一对应） */
#define PWM_CH_P10   0   /* P1.0  - 轮询实现（频率测量，TIMER0 时基） */
#define PWM_CH_P23   1   /* P2.3  - TIMER0 CH1 硬件捕获 */
#define PWM_CH_P24   2   /* P2.4  - TIMER1 CH0 硬件捕获 */
#define PWM_CH_P25   3   /* P2.5  - TIMER1 CH1 硬件捕获 */
#define PWM_CH_NUM   4

/* ============================ 对外接口 ============================ */
/* 初始化 TIMER0/TIMER1 与 4 路引脚；NVIC 使能在 Hardware_init() 中统一开启 */
void PWM_HighLevel_Init(void);
/* 由 UTIMER0_IRQHandler 调用：处理 ZERO(溢出计数，供 P2.3 时间戳扩展) 与 CH1(P2.3 捕获) */
void PWM_HighLevel_Timer0IRQ(void);
/* 由 UTIMER1_IRQHandler 调用：处理 ZERO(溢出计数) 与 CH0(P2.4)/CH1(P2.5) 捕获 */
void PWM_HighLevel_Timer1IRQ(void);
/* 由 UTIMER3_IRQHandler 调用：38K 周期任务（当前含 P1.0 轮询，后续可添加其它周期任务） */
void PWM_HighLevel_38K_Exec(void);
/* 读取 38K 任务自启动以来的累计执行次数（每 38K 周期 +1），供后续扩展任务计时 */
u32  PWM_HighLevel_Get38KTick(void);

/* 读取最近一次测得的高电平宽度（单位：微秒）；无有效测量时返回 0
   注意：P1.0(PWM_CH_P10) 已改为频率测量，请改用 PWM_HighLevel_GetP10Freq() */
u32  PWM_HighLevel_GetUs(u8 ch);
/* 读取最近一次测得的周期（微秒）= 相邻两上升沿间隔；无有效测量时返回 0 */
u32  PWM_HighLevel_GetPeriodUs(u8 ch);
/* 读取指定通道是否有新的有效测量（调用后自动清除标志） */
u8   PWM_HighLevel_IsUpdated(u8 ch);

/* 读取 P1.0 最近一次的平均频率（每 PWM_P10_AVG_COUNT 个上升沿周期更新一次）。
   频率通过参数 p_freq_hz 带出（单位：Hz）；
   返回值：1=自上次调用以来有新的平均频率（并已写入 *p_freq_hz），0=暂无新值
           （*p_freq_hz 仍会写入当前保存的最近一次平均频率，无有效值时为 0）。 */
u8   PWM_HighLevel_GetP10Freq(u32 *p_freq_hz);

/* ===================== 各通道空白回调（留待以后实现） ===================== */
/* P2.3/2.4/2.5：每捕获到一个完整“上升沿->下降沿”组合后调用，参数为该次高电平微秒数。
   P1.0：每算出一次平均频率后调用，参数为平均频率(Hz)（非微秒）。
   请在此处填充具体业务逻辑；如需在其它文件实现，可删除本文件中的空函数体。 */
void PWM_HighLevel_P10_Callback(u32 freq_hz);  /* P1.0（频率测量，参数=Hz） */
void PWM_HighLevel_P23_Callback(u32 high_us);  /* P2.3（TIMER0_CH1，参数=us） */
void PWM_HighLevel_P24_Callback(u32 high_us);  /* P2.4（TIMER1_CH0，参数=us） */
void PWM_HighLevel_P25_Callback(u32 high_us);  /* P2.5（TIMER1_CH1，参数=us） */

#ifdef __cplusplus
}
#endif

#endif /* __PWM_HIGHLEVEL_CAPTURE_H */

/************************ (C) COPYRIGHT LINKO SEMICONDUCTOR *****END OF FILE****/
