
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'LK_StdPeriph' 
 * Target:  'Linko 05x Project' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "lks32mc05x.h"



#endif /* RTE_COMPONENTS_H */
