/*******************************************************************************
 * 版权所有 (C)2015, LINKO SEMICONDUCTOR Co.ltd
 *
 * 文件名称： hardware_config.h
 * 文件标识：
 * 内容摘要： 硬件相关文件
 * 其它说明： 无
 * 当前版本： V 1.0
 * 作    者： Howlet
 * 完成日期： 2020年8月20日
 *
 * 修改记录1：
 * 修改日期： 2020年8月20日
 * 版 本 号： V 2.0
 * 修 改 人： Howlet
 * 修改内容： 创建
 *
 *******************************************************************************/

/*------------------------------prevent recursive inclusion -------------------*/
#ifndef __HARDWARE_CONFIG_H_
#define __HARDWARE_CONFIG_H_

#include "lks32mc05x.h"
#include "lks32mc05x_MCPWM.h"
#include "lks32mc05x_sys.h"
#include "lks32mc05x_adc.h"
#include "lks32mc05x_MCPWM.h"
#include "lks32mc05x_flash.h"
#include "lks32mc05x_Gpio.h"
#include "lks32mc05x_cmp.h"
#include "lks32mc05x_uart.h"
#include "lks32mc05x_hall.h"
#include "lks32mc05x_tim.h"
#include "hardware_init.h"
#include "lks32mc05x_NVR.h"

/* GPIO 复用功能宏（SDK 头中并非所有 AF 宏都统一定义，此处用守卫补齐，保证编译自包含；
   若 SDK 已定义则 #ifndef 自动跳过，不冲突）：
   AF0_GPIO = 0(GPIO 模式/默认)  AF4_UART = 4(UART 功能)。
   数据手册引脚复用：P0.7->UART1_TXD(AF4_UART)、P0.14->GPIO 输入(AF0_GPIO)。 */
#ifndef AF0_GPIO
#define AF0_GPIO    0   /* GPIO 复用 = GPIO 模式(复位默认) */
#endif
#ifndef AF4_UART
#define AF4_UART    4   /* GPIO 复用 = UART 功能 */
#endif

/* ===================== 调试输出开关 ===================== */
/* UART 串口遥测开关：=0 关闭 -> UART1 外设与 P0.7(TXD) 引脚均不初始化、主循环不做 UART 发送；
   =1 打开 -> 经 UART1(P0.7 TXD, 115200-8-N-1) 发送调试数据，对电机控制零干扰。
   供 hardware_init.c 使用（UART 相关初始化由此宏闸控；P0.7->UART1_TXD 复用见 GPIO_init）。 */
#define UART_TELEMETRY_ENABLE  1

#define  CHIP_PART_NUMBER              LKS32MC054D         /* 芯片型号选择，选择不正确将影响芯片模块的初始化 */

#if ((CHIP_PART_NUMBER == LKS32MC057D)||(CHIP_PART_NUMBER == LKS32MC054D)||(CHIP_PART_NUMBER == LKS32MC051D)\
     ||(CHIP_PART_NUMBER == LKS32MC057D_V0)) 
#define  MCPWM_SWAP_FUNCTION           1
#define  PRE_DRIVER_POLARITY           P_HIGH__N_HIGH     /* 预驱预动极性设置 上管高电平有效，下管高电平有效 */
#else
#define  PRE_DRIVER_POLARITY           P_HIGH__N_LOW      /* 预驱预动极性设置 上管高电平有效，下管低电平有效 */
#endif

/* ----------------------PWM 频率及死区定义----------------------------------- */
#ifndef MCU_MCLK   /* lks32mc05x_uart.h 已定义同值(96000000)，此处用守卫避免重定义 warning */
#define MCU_MCLK                       96000000uL       /* PWM模块运行主频 */
#endif
#define PWM_MCLK                       ((u32)MCU_MCLK)    /* PWM模块运行主频 */
#define PWM_PRSC                       ((u8)0)            /* PWM模块运行预分频器 */
#define PWM_FREQ                       ((u16)30000)       /* PWM斩波频率 */


/* 电机控制PWM 周期计数器值 */
#define PWM_PERIOD                     ((u16) (PWM_MCLK / (u32)(2 * PWM_FREQ *(PWM_PRSC+1))))
/* PFC控制PWM 周期计数器值 */
#define PFC_PERIOD                     ((u16) (PWM_MCLK / (u32)(2 * PFC_FREQ *(PWM_PRSC+1))))

#define DEADTIME_NS                    ((u16)2000)       /* 死区时间，原来1200 */
#define DEADTIME                       (u16)(((u32)PWM_MCLK / 1000uL) * (u32)DEADTIME_NS / 1000000uL)
  
#define DEADTIMECOMPVOLTAGE            (u16)((DEADTIME_NS * PWM_FREQ / 1000000uL) * MAX_MODULE_VALUE / 1000uL) 



#endif  /* __HARDWARE_CONFIG_H_ */

 
/************************ (C) COPYRIGHT LINKO SEMICONDUCTOR **********************/
/* ------------------------------END OF FILE------------------------------------ */
 
