/**
 * @file
 * @copyright (C)2015, LINKO SEMICONDUCTOR Co.ltd
 * @brief �ļ����ƣ� lks32mc05x_dsp.h\n
 * �ļ���ʶ�� �� \n
 * ����ժҪ�� DSP����ͷ�ļ� \n
 * ����˵���� �� \n
 *@par �޸���־:
 * <table>
 * <tr><th>Date	        <th>Version  <th>Author  <th>Description
 * <tr><td>2018��07��25�� <td>1.0     <td>Howlet      <td>����
 * </table>
 */
#ifndef __LKS32MC05x_DSP_H
#define __LKS32MC05x_DSP_H

/* Includes ------------------------------------------------------------------*/
#include "lks32mc05x_lib.h"

/**
 *@brief ���Ǻ�������ṹ����
 */
typedef struct
{
    s16 Theta;       /**< �Ƕ�-32768~32767��Ӧ-pi~pi    */
    s16 SinValue;    /**< ����õ�sinֵ                 */
    s16 CosValue;    /**< ����õ�cosֵ                 */
    s16 ArctanX;     /**< Arctan�����ӦXֵ arctan =Y/X */
    s16 ArctanY;     /**< Arctan�����ӦYֵ arctan =Y/X */
    s16 ArctanValue; /**< ����õ�arctanֵ              */
} stru_CordicComponents;

typedef enum
{
    ARCTAN = 0, /**< 0����arctan*/
    SINCOS = 1  /**< 1����sin cos*/
} Arc_or_SinCFuction;

void DSP_Cmd(FuncState state);                                                 /* DSPʹ�ܺ͹ر� */
void DSP_CalcCordic(stru_CordicComponents *Cordic, Arc_or_SinCFuction choise); /* DSP���Ǻ����������� */
uint32_t DSP_GetSqrt(uint32_t Data);                                           /*DSPȡ�ÿ����� sprt(Data)*/
s16 DSP_CalcSprt(s16 X, s16 Y);                                                /*DSP���㿪���� sprt(X^2+Y^2)*/

void DSP_Init(void);
s16 DSP_arctan(s16 x, s16 y);
s16 DSP_sin(u16 angle);
s16 DSP_cos(u16 angle);
u16 DSP_sqrt(u32 val);

#define DSP_CALC_SIN(sin, angle)       \
    {                                  \
        int32_t flg = __get_PRIMASK(); \
        __disable_irq();               \
        DSP_SC    = BIT2;              \
        DSP_THETA = (u16)angle;        \
        sin       = DSP_SIN;           \
        __set_PRIMASK(flg);            \
    }
#define DSP_CALC_COS(cos, angle)       \
    {                                  \
        int32_t flg = __get_PRIMASK(); \
        __disable_irq();               \
        DSP_SC    = BIT2;              \
        DSP_THETA = (u16)angle;        \
        cos       = DSP_COS;           \
        __set_PRIMASK(flg);            \
    }
#define DSP_CALC_SQRT(sqrt, val)       \
    {                                  \
        int32_t flg = __get_PRIMASK(); \
        __disable_irq();               \
        DSP_RAD = val;                 \
        sqrt    = DSP_SQRT;            \
        __set_PRIMASK(flg);            \
    }
#define DSP_CALC_ARCTAN(arctan, x, y)                      \
    {                                                      \
        int32_t flg = __get_PRIMASK();                     \
        __disable_irq();                                   \
        DSP_SC        = 0;                                 \
        DSP_CORDIC_XY = ((uint32_t)x << 16) | (uint32_t)y; \
        arctan        = DSP_ARCTAN;                        \
        __set_PRIMASK(flg);                                \
    }

#endif
/************************ (C) COPYRIGHT LINKO SEMICONDUCTOR *****END OF FILE****/
