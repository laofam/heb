/**
 * @file
 * @copyright (C)2015, LINKO SEMICONDUCTOR Co.ltd
 * @brief �ļ����ƣ� LKS32MC05x_lib.h\n
 * �ļ���ʶ�� �� \n
 * ����ժҪ�� LIB�⺯��ͷ�ļ� \n
 * ����˵���� �� \n
 *@par �޸���־:
 * <table>
 * <tr><th>Date	        <th>Version  <th>Author  <th>Description
 * <tr><td>2021��11��11�� <td>1.0     <td>YangZJ    <td>����
 * </table>
 */
#ifndef __lks32mc05x_LIB_H
#define __lks32mc05x_LIB_H

#include "lks32mc05x.h"
#include "basic.h"

#include "lks32mc05x_user_manual.h"
#include "lks32mc05x_adc.h"
#include "lks32mc05x_cmp.h"
#include "lks32mc05x_dac.h"
#include "lks32mc05x_dsp.h"
#include "lks32mc05x_exti.h"
#include "lks32mc05x_flash.h"
#include "lks32mc05x_gpio.h"
#include "lks32mc05x_hall.h"
#include "lks32mc05x_i2c.h"
#include "lks32mc05x_iwdg.h"
#include "lks32mc05x_mcpwm.h"
#include "lks32mc05x_nvr.h"
#include "lks32mc05x_opa.h"
#include "lks32mc05x_spi.h"
#include "lks32mc05x_sys.h"
#include "lks32mc05x_tim.h"
#include "lks32mc05x_uart.h"
#include "lks32mc05x_spi.h"
#include "lks32mc05x_tmp.h"

#endif /*__lks32mc05x_LIB_H */

/************************ (C) COPYRIGHT LINKO SEMICONDUCTOR *****END OF FILE****/
