#include "basic.h"
#include "stdint.h"
#include "lks32mc05x.h"

#ifndef __HAL_LKS32MC05X_H__
#define __HAL_LKS32MC05X_H__
/**
 * @brief ͳһ�жϺ����ӿ�
 * @ref
 * ������ʽ��
 * HAL_ģ������_IRQHandler_ģ������ж���š�
 * ����MCPWMģ����������CNT,����������жϡ�
 * ����ֱ��ӦMCPWM0_IRQHandler��MCPWM1_IRQHandler��
 * Ϊ����ʹ��,ĩβ��_00����ʡ�ԡ�
 */
#define HAL_TIMER_IRQHandler_00 UTIMER0_IRQHandler
#define HAL_TIMER_IRQHandler_10 UTIMER1_IRQHandler
#define HAL_TIMER_IRQHandler_20 UTIMER2_IRQHandler
#define HAL_TIMER_IRQHandler_30 UTIMER3_IRQHandler
#define HAL_MCPWM_IRQHandler_00 MCPWM_IRQHandler
#define HAL_I2C_IRQHandler_00   I2C0_IRQHandler
#define HAL_SPI_IRQHandler_00   SPI0_IRQHandler
#define HAL_GPIO_IRQHandler_00  GPIO_IRQHandler
#define HAL_HALL_IRQHandler_00  HALL_IRQHandler
#define HAL_UART_IRQHandler_00  UART0_IRQHandler
#define HAL_UART_IRQHandler_10  UART1_IRQHandler
#define HAL_CMP_IRQHandler_00   CMP_IRQHandler
#define HAL_ADC_IRQHandler_00   ADC0_IRQHandler
#define HAL_WAKE_IRQHandler_00  WAKE_IRQHandler
#define HAL_INIT_IRQHandler_00  HAL_PWRDN_IRQHandler

#define HAL_TIMER_IRQHandler    HAL_TIMER_IRQHandler_00
#define HAL_MCPWM_IRQHandler    HAL_MCPWM_IRQHandler_00
#define HAL_I2C_IRQHandler      HAL_I2C_IRQHandler_00
#define HAL_SPI_IRQHandler      HAL_SPI_IRQHandler_00
#define HAL_GPIO_IRQHandler     HAL_GPIO_IRQHandler_00
#define HAL_HALL_IRQHandler     HAL_HALL_IRQHandler_00
#define HAL_UART_IRQHandler     HAL_UART_IRQHandler_00
#define HAL_CMP_IRQHandler      HAL_CMP_IRQHandler_00
#define HAL_ADC_IRQHandler      HAL_ADC_IRQHandler_00
#define HAL_DMA_IRQHandler      HAL_DMA_IRQHandler_00
#define HAL_WAKE_IRQHandler     HAL_WAKE_IRQHandler_00
#define HAL_INIT_IRQHandler     HAL_INIT_IRQHandler_00

// ��ǰоƬ��֧�ֵ��жϺ���
#define HAL_MCPWM_IRQHandler_01 HAL_MCPWM_IRQHandler_01_Null
#define HAL_DMA_IRQHandler_00   HAL_DMA_IRQHandler_00_Null
#define HAL_ADC_IRQHandler_10   HAL_ADC_IRQHandler_10_Null
#define HAL_QEP_IRQHandler_00   HAL_QEP_IRQHandler_00_Null
#define HAL_QEP_IRQHandler_10   HAL_QEP_IRQHandler_10_Null
#define HAL_DSP_IRQHandler_00   HAL_DSP_IRQHandler_00_Null
#define HAL_CAN_IRQHandler_00   HAL_CAN_IRQHandler_00_Null
#define HAL_SIF_IRQHandler_00   HAL_SIF_IRQHandler_00_Null
#define HAL_SW_IRQHandler_00    HAL_SW_IRQHandler_00_Null
#define HAL_PWRDN_IRQHandler_00 HAL_PWRDN_IRQHandler_00_Null
#define HAL_CL_IRQHandler_00    HAL_CL_IRQHandler_00_Null
#define HAL_I2C_IRQHandler_10   HAL_I2C_IRQHandler_10_Null
#define HAL_HALL_IRQHandler_10  HAL_HALL_IRQHandler_10_Null
#define HAL_CMP_IRQHandler_20   HAL_CMP_IRQHandler_20_Null
#define HAL_CMP_IRQHandler_30   HAL_CMP_IRQHandler_30_Null
#define HAL_CMP_IRQHandler_40   HAL_CMP_IRQHandler_40_Null
#define HAL_CMP_IRQHandler_50   HAL_CMP_IRQHandler_50_Null
#define HAL_MCPWM_IRQHandler_10 HAL_MCPWM_IRQHandler_10_Null
#define HAL_MCPWM_IRQHandler_11 HAL_MCPWM_IRQHandler_11_Null
#define HAL_TIMER_IRQHandler_40 HAL_TIMER_IRQHandler_40_Null
#define HAL_QEP_IRQHandler_20   HAL_QEP_IRQHandler_20_Null
#define HAL_QEP_IRQHandler_30   HAL_QEP_IRQHandler_30_Null
#define HAL_ADC_IRQHandler_20   HAL_ADC_IRQHandler_20_Null
#define HAL_SPI_IRQHandler_10   HAL_SPI_IRQHandler_10_Null
#define HAL_WWDG_IRQHandler_00  HAL_WWDG_IRQHandler_00_Null
#define HAL_FMAC_IRQHandler_00  HAL_FMAC_IRQHandler_00_Null
#define HAL_QEP_IRQHandler      HAL_QEP_IRQHandler_Null
#define HAL_DSP_IRQHandler      HAL_DSP_IRQHandler_Null
#define HAL_CAN_IRQHandler      HAL_CAN_IRQHandler_Null
#define HAL_SIF_IRQHandler      HAL_SIF_IRQHandler_Null
#define HAL_SW_IRQHandler       HAL_SW_IRQHandler_Null
#define HAL_PWRDN_IRQHandler    HAL_PWRDN_IRQHandler_Null
#define HAL_CL_IRQHandler       HAL_CL_IRQHandler_Null
#define HAL_UART_IRQHandler_20  HAL_UART_IRQHandler_20_Null
#define HAL_CMP_IRQHandler_10   HAL_CMP_IRQHandler_10_Null
/**
 * @brief оƬ��Ĭ��ʱ��Ƶ��
 */
#define HAL_INIT_DEFAULE_MCLK    96000000
#define HAL_INIT_DEFAULE_MCLK_US 96    // �ϵ���Ĭ��ʱ��1uS��Ƶϵ��
#define HAL_INIT_DEFAULE_MCLK_MS 96000 // �ϵ���Ĭ��ʱ��1mS��Ƶϵ��

#include "include/hal_lksmcu_adc.h"
#include "include/hal_lksmcu_can.h"
#include "include/hal_lksmcu_clk.h"
#include "include/hal_lksmcu_cmp.h"
#include "include/hal_lksmcu_crc.h"
#include "include/hal_lksmcu_dac.h"
#include "include/hal_lksmcu_dma.h"
#include "include/hal_lksmcu_dsp.h"
#include "include/hal_lksmcu_flash.h"
#include "include/hal_lksmcu_gpio.h"
#include "include/hal_lksmcu_hall.h"
#include "include/hal_lksmcu_i2c.h"
#include "include/hal_lksmcu_init.h"
#include "include/hal_lksmcu_iwdg.h"
#include "include/hal_lksmcu_irq.h"
#include "include/hal_lksmcu_mcpwm.h"
#include "include/hal_lksmcu_opa.h"
#include "include/hal_lksmcu_qep.h"
#include "include/hal_lksmcu_reg.h"
#include "include/hal_lksmcu_reset.h"
#include "include/hal_lksmcu_spi.h"
#include "include/hal_lksmcu_timer.h"
#include "include/hal_lksmcu_tmp.h"
#include "include/hal_lksmcu_trim.h"
#include "include/hal_lksmcu_uart.h"
#include "include/hal_lksmcu_wake.h"
#include "include/hal_lksmcu_irqfun.h"
#endif
