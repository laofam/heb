#ifndef __HAL_LKSMCU_DAC_H__
#define __HAL_LKSMCU_DAC_H__
#include "stdint.h"
#include "hal_lksmcu_gpio.h"

typedef enum
{
    HAL_DAC_0, ///< DACģ��0
    HAL_DAC_1, ///< DACģ��1
    HAL_DAC_2, ///< DACģ��2
    HAL_DAC_3, ///< DACģ��3
} HAL_DAC_x;
void HAL_DAC_Reset(HAL_DAC_x);   // ģ�鸴λ
void HAL_DAC_Enable(HAL_DAC_x);  // ģ���
void HAL_DAC_Disable(HAL_DAC_x); // ģ��ر�

void HAL_DAC_SetOutVal(HAL_DAC_x, uint16_t val);
void HAL_DAC_SetOutVoltagemV(HAL_DAC_x, uint16_t vol_mV);
void HAL_DAC_Out2GpioEnable(HAL_DAC_x);
void HAL_DAC_Out2GpioDisable(HAL_DAC_x);
void HAL_DAC_SetGpioOut(HAL_DAC_x, HAL_GPIO_Px);
#endif
