#ifndef __HAL_LKSMCU_OPA_H__
#define __HAL_LKSMCU_OPA_H__
#include "stdint.h"
#include "hal_lksmcu_adc.h"
typedef enum
{
    HAL_OPA_0,  ///< ADCģ��0
    HAL_OPA_1,  ///< ADCģ��1
    HAL_OPA_2,  ///< ADCģ��2
    HAL_OPA_3,  ///< ADCģ��3
    HAL_OPA_4,  ///< ADCģ��4
    HAL_OPA_5,  ///< ADCģ��5
    HAL_OPA_0B, ///< ADCģ��0B
} HAL_OPA_x;

typedef enum
{
    // 05
    HAL_OPA_GAIN_200_10_6 = 0,
    HAL_OPA_GAIN_190_20_6 = 1,
    HAL_OPA_GAIN_180_30_6 = 2,
    HAL_OPA_GAIN_170_40_6 = 3,

    HAL_OPA_GAIN_HIGH   = HAL_OPA_GAIN_200_10_6, ///< ������
    HAL_OPA_GAIN_MEDIUM = HAL_OPA_GAIN_190_20_6, ///< �е�����
    HAL_OPA_GAIN_LOW    = HAL_OPA_GAIN_180_30_6, ///< ������

    // 03
    HAL_OPA_GAIN_200_10,
    HAL_OPA_GAIN_190_20,
    HAL_OPA_GAIN_180_30,
    HAL_OPA_GAIN_170_40,

    // 08
    HAL_OPA_GAIN_200_10_4,
    HAL_OPA_GAIN_190_20_4,
    HAL_OPA_GAIN_180_30_4,
    HAL_OPA_GAIN_170_40_4,

    // 09
    HAL_OPA_GAIN_660_20,
    HAL_OPA_GAIN_640_40,
    HAL_OPA_GAIN_320_40,
    HAL_OPA_GAIN_160_40,

    // 45
    HAL_OPA_GAIN_20_10,
    HAL_OPA_GAIN_40_10,
    HAL_OPA_GAIN_80_10,
    HAL_OPA_GAIN_160_10,
    HAL_OPA_GAIN_320_10,
    HAL_OPA_GAIN_320_5,

} HAL_OPA_GAIN_x;

// ��ʼ��
void HAL_OPA_Reset(HAL_OPA_x);   // ģ�鸴λ
void HAL_OPA_Enable(HAL_OPA_x);  // ģ���
void HAL_OPA_Disable(HAL_OPA_x); // ģ��ر�

void HAL_OPA_SetGain(HAL_OPA_x, HAL_OPA_GAIN_x); // ��������
void HAL_OPA_Out2GpioEnable(HAL_OPA_x);
void HAL_OPA_Out2GpioDisable(HAL_OPA_x);
void HAL_OPA_SetGpioIn(HAL_OPA_x, HAL_GPIO_Px);
void HAL_OPA_SetGpioOut(HAL_OPA_x, HAL_GPIO_Px);

#define HAL_OPA_OPAX_2_ADCCHN(OPAX) ((OPAX) == HAL_OPA_0B ? HAL_ADC_PORT_0 : (HAL_ADC_PORT_x)(OPAX))
/**
 * @brief оƬ���˷ŷŴ���
 */
#define HAL_OPA_READ_GAIN(GAIN_x, res) (GAIN_x == HAL_OPA_GAIN_HIGH ? (200.0f / (10.6f + (float)res)) : (GAIN_x == HAL_OPA_GAIN_MEDIUM) ? (190.0f / (20.6f + (float)res)) \
                                                                                                                                        : (180.0f / (30.6f + (float)res)))

#endif
