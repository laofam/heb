#include "hal_lks32mc05x.h"
