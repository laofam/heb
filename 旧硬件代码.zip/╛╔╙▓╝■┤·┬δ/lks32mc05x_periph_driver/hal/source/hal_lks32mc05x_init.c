#include "../include/hal_lksmcu_init.h"
#include "../hal_lks32mc05x.h"
#include "lks32mc05x_user_manual.h"
#include "../include/hal_lksmcu_reg.h"
#include "../include/hal_lks32mc05x_reg.h"
void HAL_INIT_SysInit(void)
{
    SYS_WR_PROTECT = 0x7a83;     /* ���ϵͳ�Ĵ���д���� */
    SYS_AFE_REG5   = BIT15;      /* BIT15:PLLPDN ��PLL */
    SYS_CLK_CFG    = 0x000001ff; /* BIT8:0: CLK_HS,1:PLL  | BIT[7:0]CLK_DIV  | 1ff��Ӧ96Mʱ�� */
}

void HAL_INIT_PowerReady(HAL_INIT_POWER_x powerx)
{
    (void)powerx;
    // ��֧��
}
