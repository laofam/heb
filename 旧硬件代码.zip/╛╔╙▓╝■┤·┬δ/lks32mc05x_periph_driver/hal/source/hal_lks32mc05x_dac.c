#include "../include/hal_lksmcu_dac.h"
#include "../include/hal_lksmcu_trim.h"
#include "../hal_lks32mc05x.h"
#include "lks32mc05x_user_manual.h"
#include "../include/hal_lksmcu_reg.h"
#include "../include/hal_lks32mc05x_reg.h"
// ģ�鸴λ
void HAL_DAC_Reset(HAL_DAC_x dac_x)
{
    HAL_DAC_Disable(dac_x);
}
// ģ���
void HAL_DAC_Enable(HAL_DAC_x dac_x)
{
    (void)dac_x;
    // ϵͳ�Ĵ�������
    HAL_REG_SYS_UNLOCK();
    HAL_REG_SET(SYS_AFE_REG5, BIT12);
    // ϵͳ�Ĵ�������
    HAL_REG_SYS_LOCK();
}
// ģ��ر�
void HAL_DAC_Disable(HAL_DAC_x dac_x)
{
    (void)dac_x;
    // ϵͳ�Ĵ�������
    HAL_REG_SYS_UNLOCK();
    HAL_REG_RESET(SYS_AFE_REG5, BIT12);
    // ϵͳ�Ĵ�������
    HAL_REG_SYS_LOCK();
}

void HAL_DAC_SetOutVal(HAL_DAC_x dac_x, uint16_t val)
{
    (void)dac_x;
    HAL_REG_WRITE(SYS_AFE_DAC, val);
}
void HAL_DAC_SetOutVoltagemV(HAL_DAC_x dac_x, uint16_t vol_mV)
{
    (void)dac_x;
    // ϵͳ�Ĵ�������
    int32_t tmp = vol_mV;
    HAL_REG_SYS_UNLOCK();
    if (tmp < 1000)
    {
        tmp = (tmp * 27853) >> 13;
        if (tmp > 4095)
        {
            tmp = 4095;
        }
        if (tmp < 0)
        {
            tmp = 0;
        }

        SYS_AFE_DAC_DC  = HAL_TRIM_Read(0x00000340);
        SYS_AFE_DAC_AMC = HAL_TRIM_Read(0x00000330);
        // uint8_t offset = HAL_TRIM_Read(0x00000348);
        // tmp -= (512 * offset / SYS_AFE_DAC_AMC);
        HAL_REG_RESET(SYS_AFE_REG3, BIT15);
        HAL_REG_WRITE(SYS_AFE_DAC, tmp);
    }
    else
    {
        tmp = (tmp * 27853) >> 15;
        if (tmp > 4095)
        {
            tmp = 4095;
        }
        if (tmp < 0)
        {
            tmp = 0;
        }
        SYS_AFE_DAC_DC  = HAL_TRIM_Read(0x00000344);
        SYS_AFE_DAC_AMC = HAL_TRIM_Read(0x00000334);
        // uint8_t offset = HAL_TRIM_Read(0x0000034C);
        // tmp -= (512 * offset / SYS_AFE_DAC_AMC);
        HAL_REG_SET(SYS_AFE_REG3, BIT15);
        HAL_REG_WRITE(SYS_AFE_DAC, tmp);
    }
    // ϵͳ�Ĵ�������
    HAL_REG_SYS_LOCK();
}

void HAL_DAC_Out2GpioEnable(HAL_DAC_x dac_x)
{
    // ϵͳ�Ĵ�������
    HAL_REG_SYS_UNLOCK();
    switch (dac_x)
    {
        case HAL_DAC_0:
            HAL_REG_SET(SYS_AFE_REG3, BIT11);
            break;
        default:
            break;
    }
    // ϵͳ�Ĵ�������
    HAL_REG_SYS_LOCK();
}
void HAL_DAC_Out2GpioDisable(HAL_DAC_x dac_x)
{
    // ϵͳ�Ĵ�������
    HAL_REG_SYS_UNLOCK();
    switch (dac_x)
    {
        case HAL_DAC_0:
            HAL_REG_RESET(SYS_AFE_REG3, BIT11);
            break;
        default:
            break;
    }
    // ϵͳ�Ĵ�������
    HAL_REG_SYS_LOCK();
}
/**
 * @brief ����DAC�����GPIO
 * @param dac_x DACģ��
 * @param px GPIO
 */
void HAL_DAC_SetGpioOut(HAL_DAC_x dac_x, HAL_GPIO_Px px)
{
    (void)dac_x;

    HAL_GPIO_SetAf(px, HAL_GPIO_AF_DAC);
    HAL_GPIO_SetMode(px, HAL_GPIO_MODE_AFE);
}
