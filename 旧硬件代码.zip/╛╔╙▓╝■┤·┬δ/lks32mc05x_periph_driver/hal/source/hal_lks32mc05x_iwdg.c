#include "../include/hal_lksmcu_iwdg.h"
#include "../include/hal_lksmcu_reg.h"
#include "../include/hal_lks32mc05x_reg.h"
#include "../hal_lks32mc05x.h"
#include "lks32mc05x_user_manual.h"
#include "../include/hal_lksmcu_reg.h"
#include "../include/hal_lks32mc05x_reg.h"
/**
 * @brief ģ�鸴λ
 * @param iwdg ���Ź�ģ��
 */
void HAL_IWDG_Reset(HAL_IWDG_x iwdg)
{
    HAL_IWDG_Disable(iwdg);
}

/**
 * @brief ģ���
 * @param iwdg ���Ź�ģ��
 */
void HAL_IWDG_Enable(HAL_IWDG_x iwdg)
{
    (void)iwdg;
    HAL_REG_SYS_UNLOCK();
    HAL_REG_SET(HAL_SYS[0]->RST_CFG, SYS_RST_CFG_WDT_EN_BIT);
    HAL_REG_SYS_LOCK();
}

/**
 * @brief ģ��ر�
 * @param iwdg ���Ź�ģ��
 */
void HAL_IWDG_Disable(HAL_IWDG_x iwdg)
{
    (void)iwdg;
    HAL_REG_SYS_UNLOCK();
    HAL_REG_RESET(HAL_SYS[0]->RST_CFG, SYS_RST_CFG_WDT_EN_BIT);
    HAL_REG_SYS_LOCK();
}

/**
 * @brief ���ÿ��Ź���ʱ��λʱ��
 * @param iwdg ���Ź�ģ��
 * @param ms ��ʱ��λʱ��,��λmS
 */
void HAL_IWDG_SetResetTimemS(HAL_IWDG_x iwdg, int32_t ms)
{
    (void)iwdg;
    uint32_t th;
    th = ((uint32_t)(64 * ms + 0x800) & 0x1ff000);
    HAL_REG_WRITE(HAL_IWDG[0]->PSW, 0xA6B4);
    HAL_REG_WRITE(HAL_IWDG[0]->TH, th);
}
/**
 * @brief ι��
 * @param iwdg ���Ź�ģ��
 */
void HAL_IWDG_Feed(HAL_IWDG_x iwdg)
{
    (void)iwdg;
    HAL_REG_WRITE(HAL_IWDG[0]->PSW, 0xA6B4);
    HAL_REG_WRITE(HAL_IWDG[0]->CLR, 0x798D);
}
