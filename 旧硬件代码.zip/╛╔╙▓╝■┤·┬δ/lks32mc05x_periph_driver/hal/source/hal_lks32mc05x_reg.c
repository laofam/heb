#include "lks32mc05x.h"
#include "../include/hal_lksmcu_reg.h"
#include "../include/hal_lks32mc05x_reg.h"
#include "lks32mc05x_user_manual.h"
#include "../include/hal_lksmcu_reg.h"
#include "../include/hal_lks32mc05x_reg.h"

HAL_SYS_TypeDef *const HAL_SYS[]     = {(HAL_SYS_TypeDef *)MISC_BASE};
HAL_FLASH_TypeDef *const HAL_FLASH[] = {(HAL_FLASH_TypeDef *)FLS_CR_BASE};
HAL_SPI_TypeDef *const HAL_SPI[]     = {(HAL_SPI_TypeDef *)SPI_BASE};
HAL_I2C_TypeDef *const HAL_I2C[]     = {(HAL_I2C_TypeDef *)I2C_BASE};
HAL_CMP_TypeDef *const HAL_CMP[]     = {(HAL_CMP_TypeDef *)CMP_BASE};
HAL_HALL_TypeDef *const HAL_HALL[]   = {(HAL_HALL_TypeDef *)HALL_BASE};
HAL_ADC_TypeDef *const HAL_ADC[]     = {(HAL_ADC_TypeDef *)ADC0_BASE};
HAL_TIMER_TypeDef *const HAL_TIMER[] = {(HAL_TIMER_TypeDef *)UTIMER_BASE, (HAL_TIMER_TypeDef *)(UTIMER_BASE + 0x20), (HAL_TIMER_TypeDef *)(UTIMER_BASE + 0x40), (HAL_TIMER_TypeDef *)(UTIMER_BASE + 0x60)};
HAL_MCPWM_TypeDef *const HAL_MCPWM[] = {(HAL_MCPWM_TypeDef *)MCPWM_BASE};
HAL_GPIO_TypeDef *const HAL_GPIO[]   = {(HAL_GPIO_TypeDef *)GPIO0_BASE, (HAL_GPIO_TypeDef *)GPIO1_BASE, (HAL_GPIO_TypeDef *)GPIO2_BASE};
HAL_CRC_TypeDef *const HAL_CRC[]     = {(HAL_CRC_TypeDef *)CRC_BASE};
HAL_UART_TypeDef *const HAL_UART[]   = {(HAL_UART_TypeDef *)UART0_BASE, (HAL_UART_TypeDef *)UART1_BASE};
HAL_DSP_TypeDef *const HAL_DSP[]     = {(HAL_DSP_TypeDef *)DSP_BASE};
HAL_IWDG_TypeDef *const HAL_IWDG[]   = {(HAL_IWDG_TypeDef *)MISC_BASE};
