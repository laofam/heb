
#include "../include/hal_lksmcu_timer.h"
#include "../include/hal_lksmcu_reg.h"
#include "../include/hal_lksmcu_gpio.h"
#include "../include/hal_lks32mc05x_reg.h"
#include "../hal_lks32mc05x.h"
#include "lks32mc05x_user_manual.h"
#include "../include/hal_lksmcu_reg.h"
#include "../include/hal_lks32mc05x_reg.h"

static uint8_t hal_timer_ena = 0;
// ģ�鸴λ
void HAL_TIMER_Reset(HAL_TIMER_x timer_x)
{
    (void)timer_x;
}
// ģ���
void HAL_TIMER_Enable(HAL_TIMER_x timer_x)
{
    HAL_REG_SET(hal_timer_ena, 1 << timer_x);
    // ϵͳ�Ĵ�������
    HAL_REG_SYS_UNLOCK();
    HAL_REG_SET(SYS_CLK_FEN, SYS_CLK_FEN_UTIMER_CLK_EN_BIT);
    // ϵͳ�Ĵ�������
    HAL_REG_SYS_LOCK();
}
// ģ��ر�
void HAL_TIMER_Disable(HAL_TIMER_x timer_x)
{
    HAL_REG_RESET(hal_timer_ena, 1 << timer_x);
    if (hal_timer_ena == 0)
    {
        // ϵͳ�Ĵ�������
        HAL_REG_SYS_UNLOCK();
        HAL_REG_RESET(SYS_CLK_FEN, SYS_CLK_FEN_UTIMER_CLK_EN_BIT);
        // ϵͳ�Ĵ�������
        HAL_REG_SYS_LOCK();
    }
}
/**
 * @brief ���ö�ʱ������
 * @param timer_x ��ʱ�����
 * @param count ��ʱ������
 */
void HAL_TIMER_SetPeriodCount(HAL_TIMER_x timer_x, uint32_t count)
{
    if (count > 0)
    {
        count = count - 1;
    }
    if ((timer_x == HAL_TIMER_0) || (timer_x == HAL_TIMER_1))
    {

        uint32_t div = 0;
        for (; count > UTIMER_UNT0_TH_UNT0_TH_MAX;)
        {
            count >>= 1;
            div++;
        }
        if (div > UTIMER_UNT0_CFG_CLK_DIV_MAX)
        {
            div   = UTIMER_UNT0_CFG_CLK_DIV_MAX;
            count = UTIMER_UNT0_TH_UNT0_TH_MAX;
        }
        HAL_REG_WRITE_BIT_MASK_POS(HAL_TIMER[timer_x]->CFG, UTIMER_UNT0_CFG_CLK_DIV, div);
        HAL_REG_WRITE_BIT_MASK_POS(HAL_TIMER[timer_x]->TH, UTIMER_UNT0_TH_UNT0_TH, count);
    }
    else
    {
        uint32_t div = 0;
        for (; count > UTIMER_UNT2_TH_UNT2_TH_MAX;)
        {
            count >>= 1;
            div++;
        }
        if (div > UTIMER_UNT2_CFG_CLK_DIV_MAX)
        {
            div   = UTIMER_UNT2_CFG_CLK_DIV_MAX;
            count = UTIMER_UNT2_TH_UNT2_TH_MAX;
        }
        HAL_REG_WRITE_BIT_MASK_POS(HAL_TIMER[timer_x]->CFG, UTIMER_UNT2_CFG_CLK_DIV, div);
        HAL_REG_WRITE_BIT_MASK_POS(HAL_TIMER[timer_x]->TH, UTIMER_UNT2_TH_UNT2_TH, count);
    }
}
/**
 * @brief ���ö�ʱ��Ƶ��
 * @param timer_x ��ʱ�����
 * @param freq ��ʱ��Ƶ��
 */
void HAL_TIMER_SetFreq(HAL_TIMER_x timer_x, uint32_t freq)
{
    uint32_t mclk = HAL_CLK_GetMcuFreq();
    uint32_t th   = (mclk / freq);
    HAL_TIMER_SetPeriodCount(timer_x, th);
}

/**
 * @brief ���ö�ʱ������(ms)
 * @param timer_x ��ʱ�����
 * @param ms ��ʱ������(ms)
 */
void HAL_TIMER_SetPeriodmS(HAL_TIMER_x timer_x, uint32_t ms)
{
    uint32_t mclk = HAL_CLK_GetMcuFreq();
    uint32_t th   = (mclk / 1000) * ms;
    HAL_TIMER_SetPeriodCount(timer_x, th);
}
/**
 * @brief ���ö�ʱ������(us)
 * @param timer_x ��ʱ�����
 * @param us ��ʱ������(us)
 */
void HAL_TIMER_SetPerioduS(HAL_TIMER_x timer_x, uint32_t us)
{
    uint32_t mclk = HAL_CLK_GetMcuFreq();
    uint32_t th   = (mclk / 1000000) * us;
    HAL_TIMER_SetPeriodCount(timer_x, th);
}
// ��ȡ��ǰ��pwmƵ��
uint32_t HAL_TIMER_GetFreq(HAL_TIMER_x timer_x)
{
    uint32_t mclk = HAL_CLK_GetMcuFreq();
    uint32_t freq = (mclk / HAL_TIMER[timer_x]->TH);
    return freq;
}
// ��ȡ���������ֵ
uint32_t HAL_TIMER_GetThCnt(HAL_TIMER_x timer_x)
{
    return HAL_TIMER[timer_x]->TH;
}
// ��ʼ����
void HAL_TIMER_StartCounting(HAL_TIMER_x timer_x)
{
    switch (timer_x)
    {
        case HAL_TIMER_0: ///< TIMERģ��0
            HAL_REG_SET(UTIMER_CFG, BIT4);
            break;
        case HAL_TIMER_1: ///< TIMERģ��1
            HAL_REG_SET(UTIMER_CFG, BIT5);
            break;
        case HAL_TIMER_2: ///< TIMERģ��2
            HAL_REG_SET(UTIMER_CFG, BIT6);
            break;
        case HAL_TIMER_3: ///< TIMERģ��3
            HAL_REG_SET(UTIMER_CFG, BIT7);
            break;
        default:
            break;
    }
}
// ֹͣ����(ͬʱ�������ص�0)
void HAL_TIMER_StopCounting(HAL_TIMER_x timer_x)
{
    switch (timer_x)
    {
        case HAL_TIMER_0: ///< TIMERģ��0
            HAL_REG_RESET(UTIMER_CFG, BIT4);
            break;
        case HAL_TIMER_1: ///< TIMERģ��1
            HAL_REG_RESET(UTIMER_CFG, BIT5);
            break;
        case HAL_TIMER_2: ///< TIMERģ��2
            HAL_REG_RESET(UTIMER_CFG, BIT6);
            break;
        case HAL_TIMER_3: ///< TIMERģ��3
            HAL_REG_RESET(UTIMER_CFG, BIT7);
            break;
        default:
            break;
    }
    HAL_TIMER[timer_x]->CNT = 0;
}
// ����pwm���� ��PWMģʽ����Ч
void HAL_TIMER_SetPwm(HAL_TIMER_x timer_x, int32_t t0, int32_t t1)
{
    HAL_REG_WRITE(HAL_TIMER[timer_x]->CMP0, t0);
    HAL_REG_WRITE(HAL_TIMER[timer_x]->CMP1, t1);
}
// ����pwm����q15��ʽ���� ��PWMģʽ����Ч
void HAL_TIMER_SetPwmQ15(HAL_TIMER_x timer_x, int16_t t0, int16_t t1)
{
    uint32_t th = HAL_TIMER_GetThCnt(timer_x);
    t0          = t0 * th >> 15;
    t1          = t1 * th >> 15;
    HAL_REG_WRITE(HAL_TIMER[timer_x]->CMP0, t0);
    HAL_REG_WRITE(HAL_TIMER[timer_x]->CMP1, t1);
}
// ���ù���ģʽ
void HAL_TIMER_SetWorkMode(HAL_TIMER_x timer_x, HAL_TIMER_MODE_x mode_x)
{
    switch (mode_x)
    {
        case HAL_TIMER_MODE_COUNT: ///< ����ģʽ
            HAL_REG_WRITE_BIT(HAL_TIMER[timer_x]->CFG, 0xff, 0);
            break;
        case HAL_TIMER_MODE_PWMOUT: ///< PWM���ģʽ
            HAL_REG_WRITE_BIT(HAL_TIMER[timer_x]->CFG, 0xff, BIT7 | BIT3);
            break;
        case HAL_TIMER_MODE_PWMIN: ///< PWM����ģʽ
            HAL_REG_WRITE_BIT(HAL_TIMER[timer_x]->CFG, 0xff, BIT6 | BIT5 | BIT2 | BIT0);
            break;
        default:
            break;
    }
}

uint8_t HAL_TIMER_IrqOverflow(HAL_TIMER_x timer_x)
{
    uint16_t val = 0;
    uint32_t val1;
    val1 = UTIMER_IE & UTIMER_IF;
    switch (timer_x)
    {
        case HAL_TIMER_0: ///< TIMERģ��0
            val = val1 & BIT0;
            break;
        case HAL_TIMER_1: ///< TIMERģ��1
            val = val1 & BIT3;
            break;
        case HAL_TIMER_2: ///< TIMERģ��2
            val = val1 & BIT6;
            break;
        case HAL_TIMER_3: ///< TIMERģ��3
            val = val1 & BIT9;
            break;
        default:
            break;
    }
    if (val)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
void HAL_TIMER_IrqOverflowEnable(HAL_TIMER_x timer_x)
{
    switch (timer_x)
    {
        case HAL_TIMER_0: ///< TIMERģ��0
            HAL_REG_SET(UTIMER_IE, BIT0);
            break;
        case HAL_TIMER_1: ///< TIMERģ��1
            HAL_REG_SET(UTIMER_IE, BIT3);
            break;
        case HAL_TIMER_2: ///< TIMERģ��2
            HAL_REG_SET(UTIMER_IE, BIT6);
            break;
        case HAL_TIMER_3: ///< TIMERģ��3
            HAL_REG_SET(UTIMER_IE, BIT9);
            break;
        default:
            break;
    }
}
void HAL_TIMER_IrqOverflowDisable(HAL_TIMER_x timer_x)
{
    switch (timer_x)
    {
        case HAL_TIMER_0: ///< TIMERģ��0
            HAL_REG_RESET(UTIMER_IE, BIT0);
            break;
        case HAL_TIMER_1: ///< TIMERģ��1
            HAL_REG_RESET(UTIMER_IE, BIT3);
            break;
        case HAL_TIMER_2: ///< TIMERģ��2
            HAL_REG_RESET(UTIMER_IE, BIT6);
            break;
        case HAL_TIMER_3: ///< TIMERģ��3
            HAL_REG_RESET(UTIMER_IE, BIT9);
            break;
        default:
            break;
    }
}
void HAL_TIMER_IrqOverflowClear(HAL_TIMER_x timer_x)
{
    switch (timer_x)
    {
        case HAL_TIMER_0: ///< TIMERģ��0
            HAL_REG_WRITE(UTIMER_IF, BIT0);
            break;
        case HAL_TIMER_1: ///< TIMERģ��1
            HAL_REG_WRITE(UTIMER_IF, BIT3);
            break;
        case HAL_TIMER_2: ///< TIMERģ��2
            HAL_REG_WRITE(UTIMER_IF, BIT6);
            break;
        case HAL_TIMER_3: ///< TIMERģ��3
            HAL_REG_WRITE(UTIMER_IF, BIT9);
            break;
        default:
            break;
    }
}

uint8_t HAL_TIMER_IrqCompare0(HAL_TIMER_x timer_x)
{
    uint16_t val = 0;
    uint32_t val1;
    val1 = UTIMER_IE & UTIMER_IF;
    switch (timer_x)
    {
        case HAL_TIMER_0: ///< TIMERģ��0
            val = val1 & BIT1;
            break;
        case HAL_TIMER_1: ///< TIMERģ��1
            val = val1 & BIT4;
            break;
        case HAL_TIMER_2: ///< TIMERģ��2
            val = val1 & BIT7;
            break;
        case HAL_TIMER_3: ///< TIMERģ��3
            val = val1 & BIT10;
            break;
        default:
            break;
    }
    if (val)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
void HAL_TIMER_IrqCompare0Enable(HAL_TIMER_x timer_x)
{
    switch (timer_x)
    {
        case HAL_TIMER_0: ///< TIMERģ��0
            HAL_REG_SET(UTIMER_IE, BIT1);
            break;
        case HAL_TIMER_1: ///< TIMERģ��1
            HAL_REG_SET(UTIMER_IE, BIT4);
            break;
        case HAL_TIMER_2: ///< TIMERģ��2
            HAL_REG_SET(UTIMER_IE, BIT7);
            break;
        case HAL_TIMER_3: ///< TIMERģ��3
            HAL_REG_SET(UTIMER_IE, BIT10);
            break;
        default:
            break;
    }
}
void HAL_TIMER_IrqCompare0Disable(HAL_TIMER_x timer_x)
{
    switch (timer_x)
    {
        case HAL_TIMER_0: ///< TIMERģ��0
            HAL_REG_RESET(UTIMER_IE, BIT1);
            break;
        case HAL_TIMER_1: ///< TIMERģ��1
            HAL_REG_RESET(UTIMER_IE, BIT4);
            break;
        case HAL_TIMER_2: ///< TIMERģ��2
            HAL_REG_RESET(UTIMER_IE, BIT7);
            break;
        case HAL_TIMER_3: ///< TIMERģ��3
            HAL_REG_RESET(UTIMER_IE, BIT10);
            break;
        default:
            break;
    }
}
void HAL_TIMER_IrqCompare0Clear(HAL_TIMER_x timer_x)
{
    switch (timer_x)
    {
        case HAL_TIMER_0: ///< TIMERģ��0
            HAL_REG_WRITE(UTIMER_IF, BIT1);
            break;
        case HAL_TIMER_1: ///< TIMERģ��1
            HAL_REG_WRITE(UTIMER_IE, BIT4);
            break;
        case HAL_TIMER_2: ///< TIMERģ��2
            HAL_REG_WRITE(UTIMER_IE, BIT7);
            break;
        case HAL_TIMER_3: ///< TIMERģ��3
            HAL_REG_WRITE(UTIMER_IE, BIT10);
            break;
        default:
            break;
    }
}

uint8_t HAL_TIMER_IrqCompare1(HAL_TIMER_x timer_x)
{
    uint16_t val = 0;
    uint32_t val1;
    val1 = UTIMER_IE & UTIMER_IF;
    switch (timer_x)
    {
        case HAL_TIMER_0: ///< TIMERģ��0
            val = val1 & BIT2;
            break;
        case HAL_TIMER_1: ///< TIMERģ��1
            val = val1 & BIT5;
            break;
        case HAL_TIMER_2: ///< TIMERģ��2
            val = val1 & BIT8;
            break;
        case HAL_TIMER_3: ///< TIMERģ��3
            val = val1 & BIT11;
            break;
        default:
            break;
    }
    if (val)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
void HAL_TIMER_IrqCompare1Enable(HAL_TIMER_x timer_x)
{
    switch (timer_x)
    {
        case HAL_TIMER_0: ///< TIMERģ��0
            HAL_REG_SET(UTIMER_IE, BIT2);
            break;
        case HAL_TIMER_1: ///< TIMERģ��1
            HAL_REG_SET(UTIMER_IE, BIT5);
            break;
        case HAL_TIMER_2: ///< TIMERģ��2
            HAL_REG_SET(UTIMER_IE, BIT8);
            break;
        case HAL_TIMER_3: ///< TIMERģ��3
            HAL_REG_SET(UTIMER_IE, BIT11);
            break;
        default:
            break;
    }
}
void HAL_TIMER_IrqCompare1Disable(HAL_TIMER_x timer_x)
{
    switch (timer_x)
    {
        case HAL_TIMER_0: ///< TIMERģ��0
            HAL_REG_RESET(UTIMER_IE, BIT2);
            break;
        case HAL_TIMER_1: ///< TIMERģ��1
            HAL_REG_RESET(UTIMER_IE, BIT5);
            break;
        case HAL_TIMER_2: ///< TIMERģ��2
            HAL_REG_RESET(UTIMER_IE, BIT8);
            break;
        case HAL_TIMER_3: ///< TIMERģ��3
            HAL_REG_RESET(UTIMER_IE, BIT11);
            break;
        default:
            break;
    }
}
void HAL_TIMER_IrqCompare1Clear(HAL_TIMER_x timer_x)
{
    switch (timer_x)
    {
        case HAL_TIMER_0: ///< TIMERģ��0
            HAL_REG_WRITE(UTIMER_IE, BIT2);
            break;
        case HAL_TIMER_1: ///< TIMERģ��1
            HAL_REG_WRITE(UTIMER_IE, BIT5);
            break;
        case HAL_TIMER_2: ///< TIMERģ��2
            HAL_REG_WRITE(UTIMER_IE, BIT8);
            break;
        case HAL_TIMER_3: ///< TIMERģ��3
            HAL_REG_WRITE(UTIMER_IE, BIT11);
            break;
        default:
            break;
    }
}

/**
 * @brief ���ö�ʱ�����gpio
 * @param timer_x ��ʱ�����
 * @param px gpio���
 */
void HAL_TIMER_SetGpioOut(HAL_TIMER_x timer_x, HAL_GPIO_Px px)
{
    switch (timer_x)
    {
        case HAL_TIMER_0:
            HAL_GPIO_SetAf(px, HAL_GPIO_AF_TIMER0);
            HAL_GPIO_SetMode(px, HAL_GPIO_MODE_OUT);
            break;
        case HAL_TIMER_1:
            HAL_GPIO_SetAf(px, HAL_GPIO_AF_TIMER1);
            HAL_GPIO_SetMode(px, HAL_GPIO_MODE_OUT);
            break;
        case HAL_TIMER_2:
            HAL_GPIO_SetAf(px, HAL_GPIO_AF_TIMER2);
            HAL_GPIO_SetMode(px, HAL_GPIO_MODE_OUT);
            break;
        case HAL_TIMER_3:
            HAL_GPIO_SetAf(px, HAL_GPIO_AF_TIMER3);
            HAL_GPIO_SetMode(px, HAL_GPIO_MODE_OUT);
            break;
        default:
            break;
    }
}
/**
 * @brief ���ö�ʱ������gpio
 * @param timer_x ��ʱ�����
 * @param px gpio���
 */
void HAL_TIMER_SetGpioIn(HAL_TIMER_x timer_x, HAL_GPIO_Px px)
{
    switch (timer_x)
    {
        case HAL_TIMER_0:
            HAL_GPIO_SetAf(px, HAL_GPIO_AF_TIMER0);
            HAL_GPIO_SetMode(px, HAL_GPIO_MODE_IN);
            break;
        case HAL_TIMER_1:
            HAL_GPIO_SetAf(px, HAL_GPIO_AF_TIMER1);
            HAL_GPIO_SetMode(px, HAL_GPIO_MODE_IN);
            break;
        case HAL_TIMER_2:
            HAL_GPIO_SetAf(px, HAL_GPIO_AF_TIMER2);
            HAL_GPIO_SetMode(px, HAL_GPIO_MODE_IN);
            break;
        case HAL_TIMER_3:
            HAL_GPIO_SetAf(px, HAL_GPIO_AF_TIMER3);
            HAL_GPIO_SetMode(px, HAL_GPIO_MODE_IN);
            break;
        default:
            break;
    }
}
