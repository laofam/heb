#include "../include/hal_lksmcu_clk.h"
#include "../hal_lks32mc05x.h"
#include "lks32mc05x_user_manual.h"
#include "../include/hal_lksmcu_reg.h"
#include "../include/hal_lks32mc05x_reg.h"
static volatile uint32_t HAL_CLK_mclk = 96000000;
/**
 * @brief ������Ƶ
 * @param FREQ_x ��Ƶ
 */
void HAL_CLK_SetMcuFreq(HAL_CLK_FREQ_x FREQ_x)
{
    HAL_REG_SYS_UNLOCK();
    switch (FREQ_x)
    {
        case HAL_CLK_FREQ_RC_4MHZ: ///< ��Ƶ4Mhz
            HAL_CLK_mclk = 4000000;
            HAL_REG_WRITE(SYS_CLK_CFG, 0);
            break;
        case HAL_CLK_FREQ_RC_12MHZ: ///< ��Ƶ12Mhz
            HAL_CLK_mclk = 12000000;
            HAL_REG_WRITE(SYS_CLK_CFG, 0x101);
            break;
        case HAL_CLK_FREQ_RC_24MHZ: ///< ��Ƶ24Mhz
            HAL_CLK_mclk = 24000000;
            HAL_REG_WRITE(SYS_CLK_CFG, 0x111);
            break;
        case HAL_CLK_FREQ_RC_48MHZ: ///< ��Ƶ48Mhz
            HAL_CLK_mclk = 48000000;
            HAL_REG_WRITE(SYS_CLK_CFG, 0x155);
            break;
        default:
        case HAL_CLK_FREQ_RC_96MHZ: ///< ��Ƶ96Mhz
            HAL_CLK_mclk = 96000000;
            HAL_REG_WRITE(SYS_CLK_CFG, 0x1ff);
            break;
    }
    HAL_REG_SYS_LOCK();
}
/**
 * @brief ��ȡ��Ƶ
 * @return ��Ƶ
 */
uint32_t HAL_CLK_GetMcuFreq(void)
{
    return HAL_CLK_mclk;
}
