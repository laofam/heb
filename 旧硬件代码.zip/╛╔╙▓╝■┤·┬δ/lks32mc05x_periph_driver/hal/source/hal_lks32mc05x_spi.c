
#include "../include/hal_lksmcu_reg.h"
#include "../include/hal_lks32mc05x_reg.h"
#include "../include/hal_lksmcu_spi.h"
#include "../hal_lks32mc05x.h"
#include "lks32mc05x_user_manual.h"
#include "../include/hal_lksmcu_reg.h"
#include "../include/hal_lks32mc05x_reg.h"

/**
 * @brief ģ�鸴λ
 * @param spi SPIģ���
 */
void HAL_SPI_Reset(HAL_SPI_x spi)
{
    (void)spi;
    HAL_REG_SYS_UNLOCK();
    HAL_REG_SET(SYS_SFT_RST, SYS_SFT_RST_SPI_SFT_RST_BIT);
    HAL_REG_RESET(SYS_SFT_RST, SYS_SFT_RST_SPI_SFT_RST_BIT);
    HAL_REG_SYS_LOCK();
}

/**
 * @brief ģ���
 * @param spi SPIģ���
 */
void HAL_SPI_Enable(HAL_SPI_x spi)
{
    (void)spi;
    HAL_REG_SYS_UNLOCK();
    HAL_REG_SET(SYS_CLK_FEN, SYS_CLK_FEN_SPI_CKL_EN_BIT);
    HAL_REG_SYS_LOCK();
    HAL_REG_SET(HAL_SPI[spi]->CFG, SPI_CFG_EN_BIT);
}

/**
 * @brief ģ��ر�
 * @param spi SPIģ���
 */
void HAL_SPI_Disable(HAL_SPI_x spi)
{
    HAL_REG_RESET(HAL_SPI[spi]->CFG, SPI_CFG_EN_BIT);
    HAL_REG_SYS_UNLOCK();
    HAL_REG_RESET(SYS_CLK_FEN, SYS_CLK_FEN_SPI_CKL_EN_BIT);
    HAL_REG_SYS_LOCK();
}

/**
 * @brief ���ò�����
 * @param spi SPIģ���
 */
void HAL_SPI_SetBaud(HAL_SPI_x spi, uint32_t baud)
{
    uint32_t mclk = HAL_CLK_GetMcuFreq();
    uint32_t cnt  = (mclk / (2 * baud)) - 1;
    HAL_REG_WRITE_BIT_MASK_POS(HAL_SPI[spi]->BAUD, SPI_BAUD_BAUD, cnt);
}
/**
 * @brief ����SPIģʽ
 * @param spi SPIģ���
 * @param mode SPIģʽ
 */
void HAL_SPI_SetMode(HAL_SPI_x spi, HAL_SPI_MODE_x mode)
{
    uint32_t mask = SPI_CFG_MS_BIT | SPI_CFG_CPHA_BIT | SPI_CFG_CPOL_BIT | SPI_CFG_ENDIAN_BIT;
    switch (mode)
    {
        case HAL_SPI_MODE_MASTER_LSB_00:
            HAL_REG_WRITE_BIT(HAL_SPI[spi]->CFG, mask, SPI_CFG_MS_BIT | SPI_CFG_ENDIAN_BIT);
            break;
        case HAL_SPI_MODE_MASTER_LSB_01:
            HAL_REG_WRITE_BIT(HAL_SPI[spi]->CFG, mask, SPI_CFG_MS_BIT | SPI_CFG_CPOL_BIT | SPI_CFG_ENDIAN_BIT);
            break;
        case HAL_SPI_MODE_MASTER_LSB_10:
            HAL_REG_WRITE_BIT(HAL_SPI[spi]->CFG, mask, SPI_CFG_MS_BIT | SPI_CFG_CPHA_BIT | SPI_CFG_ENDIAN_BIT);
            break;
        case HAL_SPI_MODE_MASTER_LSB_11:
            HAL_REG_WRITE_BIT(HAL_SPI[spi]->CFG, mask, SPI_CFG_MS_BIT | SPI_CFG_CPHA_BIT | SPI_CFG_CPOL_BIT | SPI_CFG_ENDIAN_BIT);
            break;
        case HAL_SPI_MODE_MASTER_MSB_00:
            HAL_REG_WRITE_BIT(HAL_SPI[spi]->CFG, mask, SPI_CFG_MS_BIT | 0);
            break;
        case HAL_SPI_MODE_MASTER_MSB_01:
            HAL_REG_WRITE_BIT(HAL_SPI[spi]->CFG, mask, SPI_CFG_MS_BIT | SPI_CFG_CPOL_BIT);
            break;
        case HAL_SPI_MODE_MASTER_MSB_10:
            HAL_REG_WRITE_BIT(HAL_SPI[spi]->CFG, mask, SPI_CFG_MS_BIT | SPI_CFG_CPHA_BIT);
            break;
        case HAL_SPI_MODE_MASTER_MSB_11:
            HAL_REG_WRITE_BIT(HAL_SPI[spi]->CFG, mask, SPI_CFG_MS_BIT | SPI_CFG_CPHA_BIT | SPI_CFG_CPOL_BIT);
            break;
        case HAL_SPI_MODE_SLAVE_LSB_00:
            HAL_REG_WRITE_BIT(HAL_SPI[spi]->CFG, mask, SPI_CFG_ENDIAN_BIT);
            break;
        case HAL_SPI_MODE_SLAVE_LSB_01:
            HAL_REG_WRITE_BIT(HAL_SPI[spi]->CFG, mask, SPI_CFG_CPOL_BIT | SPI_CFG_ENDIAN_BIT);
            break;
        case HAL_SPI_MODE_SLAVE_LSB_10:
            HAL_REG_WRITE_BIT(HAL_SPI[spi]->CFG, mask, SPI_CFG_CPHA_BIT | SPI_CFG_ENDIAN_BIT);
            break;
        case HAL_SPI_MODE_SLAVE_LSB_11:
            HAL_REG_WRITE_BIT(HAL_SPI[spi]->CFG, mask, SPI_CFG_CPHA_BIT | SPI_CFG_CPOL_BIT | SPI_CFG_ENDIAN_BIT);
            break;
        case HAL_SPI_MODE_SLAVE_MSB_00:
            HAL_REG_WRITE_BIT(HAL_SPI[spi]->CFG, mask, 0);
            break;
        case HAL_SPI_MODE_SLAVE_MSB_01:
            HAL_REG_WRITE_BIT(HAL_SPI[spi]->CFG, mask, SPI_CFG_CPOL_BIT);
            break;
        case HAL_SPI_MODE_SLAVE_MSB_10:
            HAL_REG_WRITE_BIT(HAL_SPI[spi]->CFG, mask, SPI_CFG_CPHA_BIT);
            break;
        case HAL_SPI_MODE_SLAVE_MSB_11:
            HAL_REG_WRITE_BIT(HAL_SPI[spi]->CFG, mask, SPI_CFG_CPHA_BIT | SPI_CFG_CPOL_BIT);
            break;
        default:
            break;
    }
}
/**
 * @brief ��ʼ��CS����
 * @param spi SPIģ���
 * @param pin GPIO����
 * @see ��Ҫ�ȳ�ʼ��SPI
 */
void HAL_SPI_SetGpioCs(HAL_SPI_x spi, HAL_GPIO_Px pin)
{
    if (HAL_REG_READ_BIT(HAL_SPI[spi]->CFG, SPI_CFG_MS_BIT) == 0)
    {
        // ��ģʽ
        HAL_GPIO_SetAf(pin, HAL_GPIO_AF_SPI);
        HAL_GPIO_SetMode(pin, HAL_GPIO_MODE_IN);
    }
    else
    {
        // ��ģʽ
        HAL_GPIO_SetAf(pin, HAL_GPIO_AF_SPI);
        HAL_GPIO_SetMode(pin, HAL_GPIO_MODE_OUT);
    }
}
/**
 * @brief ��ʼ��Mosi����
 * @param spi SPIģ���
 * @param pin GPIO����
 * @see ��Ҫ�ȳ�ʼ��SPI
 */
void HAL_SPI_SetGpioMosi(HAL_SPI_x spi, HAL_GPIO_Px pin)
{
    if (HAL_REG_READ_BIT(HAL_SPI[spi]->CFG, SPI_CFG_MS_BIT) == 0)
    {
        // ��ģʽ
        HAL_GPIO_SetAf(pin, HAL_GPIO_AF_SPI);
        HAL_GPIO_SetMode(pin, HAL_GPIO_MODE_IN);
    }
    else
    {
        // ��ģʽ
        HAL_GPIO_SetAf(pin, HAL_GPIO_AF_SPI);
        HAL_GPIO_SetMode(pin, HAL_GPIO_MODE_OUT);
    }
}
/**
 * @brief ��ʼ��Miso����
 * @param spi SPIģ���
 * @param pin GPIO����
 * @see ��Ҫ�ȳ�ʼ��SPI
 */
void HAL_SPI_SetGpioMiso(HAL_SPI_x spi, HAL_GPIO_Px pin)
{
    if (HAL_REG_READ_BIT(HAL_SPI[spi]->CFG, SPI_CFG_MS_BIT) == 0)
    {
        // ��ģʽ
        HAL_GPIO_SetAf(pin, HAL_GPIO_AF_SPI);
        HAL_GPIO_SetMode(pin, HAL_GPIO_MODE_OUT);
    }
    else
    {
        // ��ģʽ
        HAL_GPIO_SetAf(pin, HAL_GPIO_AF_SPI);
        HAL_GPIO_SetMode(pin, HAL_GPIO_MODE_IN);
    }
}
/**
 * @brief ��ʼ��Clk����
 * @param spi SPIģ���
 * @param pin GPIO����
 * @see ��Ҫ�ȳ�ʼ��SPI
 */
void HAL_SPI_SetGpioClk(HAL_SPI_x spi, HAL_GPIO_Px pin)
{
    if (HAL_REG_READ_BIT(HAL_SPI[spi]->CFG, SPI_CFG_MS_BIT) == 0)
    {
        // ��ģʽ
        HAL_GPIO_SetAf(pin, HAL_GPIO_AF_SPI);
        HAL_GPIO_SetMode(pin, HAL_GPIO_MODE_IN);
    }
    else
    {
        // ��ģʽ
        HAL_GPIO_SetAf(pin, HAL_GPIO_AF_SPI);
        HAL_GPIO_SetMode(pin, HAL_GPIO_MODE_OUT);
    }
}
/**
 * @brief ��ʼ��SPI����������
 * @param spi SPIģ���
 * @param pin GPIO����
 */
void HAL_SPI_SetGpioDi(HAL_SPI_x spi, HAL_GPIO_Px pin)
{
    (void)spi;
    HAL_GPIO_SetAf(pin, HAL_GPIO_AF_SPI);
    HAL_GPIO_SetMode(pin, HAL_GPIO_MODE_IN);
}
/**
 * @brief ��ʼ��SPI���������
 * @param spi SPIģ���
 * @param pin GPIO����
 */
void HAL_SPI_SetGpioDo(HAL_SPI_x spi, HAL_GPIO_Px pin)
{
    (void)spi;
    HAL_GPIO_SetAf(pin, HAL_GPIO_AF_SPI);
    HAL_GPIO_SetMode(pin, HAL_GPIO_MODE_OUT);
}

/**
 * @brief ��������
 * @param spi SPIģ���
 * @param data Ҫ���͵�����
 * @param len ���ݳ���
 * @return ����״̬
 */
uint8_t HAL_SPI_TxData(HAL_SPI_x spi, uint8_t *data, uint32_t len)
{
    uint32_t i = 0;
    HAL_REG_WRITE(HAL_SPI[spi]->SIZE, 8);
    HAL_REG_SET(HAL_SPI[spi]->BAUD, SPI_BAUD_TRANS_MODE_BIT);
    HAL_REG_WRITE_BIT_MASK_POS(HAL_SPI[spi]->CFG, SPI_CFG_DUPLEX, 2);
    for (i = 0; i < len; i++)
    {
        HAL_REG_WRITE_BIT(HAL_SPI[spi]->IE, 0x07, BIT2);
        HAL_REG_WRITE(HAL_SPI[spi]->TXDATA, data[i]);
        while (HAL_REG_READ(HAL_SPI[spi]->IE & BIT2) == 0)
        {
        }
    }
    return 0;
}

/**
 * @brief ��������
 * @param spi SPIģ���
 * @param data ���ջ�����
 * @param len ���ݳ���
 * @return ����״̬
 */
uint8_t HAL_SPI_RxData(HAL_SPI_x spi, uint8_t *data, uint32_t len)
{
    uint32_t i = 0;
    HAL_REG_WRITE(HAL_SPI[spi]->SIZE, 8);
    HAL_REG_SET(HAL_SPI[spi]->BAUD, SPI_BAUD_TRANS_MODE_BIT);
    HAL_REG_WRITE_BIT_MASK_POS(HAL_SPI[spi]->CFG, SPI_CFG_DUPLEX, 3);
    for (i = 0; i < len; i++)
    {
        HAL_REG_WRITE_BIT(HAL_SPI[spi]->IE, 0x07, BIT2);
        HAL_REG_WRITE(HAL_SPI[spi]->TXDATA, 0); // ����һ�����ֽ�,�Դ�������
        while (HAL_REG_READ(HAL_SPI[spi]->IE & BIT2) == 0)
        {
        }
        data[i] = HAL_REG_READ(HAL_SPI[spi]->RXDATA);
    }
    // ʵ�ֽ������ݵĴ���
    return 0; // ���ؽ���״̬
}

/**
 * @brief ���ͺͽ�������
 * @param spi SPIģ���
 * @param rxdata ���ջ�����
 * @param txdata Ҫ���͵�����
 * @param len ���ݳ���
 * @return ���ͺͽ���״̬
 */
uint8_t HAL_SPI_RxTxData(HAL_SPI_x spi, uint8_t *rxdata, uint8_t *txdata, uint32_t len)
{
    uint32_t i = 0;
    HAL_REG_WRITE(HAL_SPI[spi]->SIZE, 8);
    HAL_REG_SET(HAL_SPI[spi]->BAUD, SPI_BAUD_TRANS_MODE_BIT);
    HAL_REG_WRITE_BIT_MASK_POS(HAL_SPI[spi]->CFG, SPI_CFG_DUPLEX, 0);
    for (i = 0; i < len; i++)
    {
        HAL_REG_WRITE_BIT(HAL_SPI[spi]->IE, 0x07, BIT2);
        HAL_REG_WRITE(HAL_SPI[spi]->TXDATA, txdata[i]);
        while (HAL_REG_READ(HAL_SPI[spi]->IE & BIT2) == 0)
        {
        }
        rxdata[i] = HAL_REG_READ(HAL_SPI[spi]->RXDATA);
    }
    return 0; // ���ط��ͺͽ���״̬
}

/**
 * @brief ��������
 * @param spi SPIģ���
 * @param data Ҫ���͵�����
 * @param len ���ݳ���
 * @return ����״̬
 */
uint8_t HAL_SPI_TxDataWidth16(HAL_SPI_x spi, uint16_t *data, uint32_t len)
{
    uint32_t i = 0;
    HAL_REG_WRITE(HAL_SPI[spi]->SIZE, 16);
    HAL_REG_SET(HAL_SPI[spi]->BAUD, SPI_BAUD_TRANS_MODE_BIT);
    HAL_REG_WRITE_BIT_MASK_POS(HAL_SPI[spi]->CFG, SPI_CFG_DUPLEX, 2);
    for (i = 0; i < len; i++)
    {
        HAL_REG_WRITE_BIT(HAL_SPI[spi]->IE, 0x07, BIT2);
        HAL_REG_WRITE(HAL_SPI[spi]->TXDATA, data[i]);
        while (HAL_REG_READ(HAL_SPI[spi]->IE & BIT2) == 0)
        {
        }
    }
    return 0;
}
/**
 * @brief ��������
 * @param spi SPIģ���
 * @param data ���ջ�����
 * @param len ���ݳ���
 * @return ����״̬
 */
uint8_t HAL_SPI_RxDataWidth16(HAL_SPI_x spi, uint16_t *data, uint32_t len)
{
    uint32_t i = 0;
    HAL_REG_WRITE(HAL_SPI[spi]->SIZE, 16);
    HAL_REG_SET(HAL_SPI[spi]->BAUD, SPI_BAUD_TRANS_MODE_BIT);
    HAL_REG_WRITE_BIT_MASK_POS(HAL_SPI[spi]->CFG, SPI_CFG_DUPLEX, 3);
    for (i = 0; i < len; i++)
    {
        HAL_REG_WRITE_BIT(HAL_SPI[spi]->IE, 0x07, BIT2);
        HAL_REG_WRITE(HAL_SPI[spi]->TXDATA, 0); // ����һ�����ֽ�,�Դ�������
        while (HAL_REG_READ(HAL_SPI[spi]->IE & BIT2) == 0)
        {
        }
        data[i] = HAL_REG_READ(HAL_SPI[spi]->RXDATA);
    }
    return 0; // ���ؽ���״̬
}
/**
 * @brief ���ͺͽ�������
 * @param spi SPIģ���
 * @param rxdata ���ջ�����
 * @param txdata Ҫ���͵�����
 * @param len ���ݳ���
 * @return ���ͺͽ���״̬
 */
uint8_t HAL_SPI_RxTxDataWidth16(HAL_SPI_x spi, uint16_t *rxdata, uint16_t *txdata, uint32_t len)
{
    uint32_t i = 0;
    HAL_REG_WRITE(HAL_SPI[spi]->SIZE, 16);
    HAL_REG_SET(HAL_SPI[spi]->BAUD, SPI_BAUD_TRANS_MODE_BIT);
    HAL_REG_WRITE_BIT_MASK_POS(HAL_SPI[spi]->CFG, SPI_CFG_DUPLEX, 0);
    for (i = 0; i < len; i++)
    {
        HAL_REG_WRITE_BIT(HAL_SPI[spi]->IE, 0x07, BIT2);
        HAL_REG_WRITE(HAL_SPI[spi]->TXDATA, txdata[i]);
        while (HAL_REG_READ(HAL_SPI[spi]->IE & BIT2) == 0)
        {
        }
        rxdata[i] = HAL_REG_READ(HAL_SPI[spi]->RXDATA);
    }
    return 0; // ���ط��ͺͽ���״̬
}
