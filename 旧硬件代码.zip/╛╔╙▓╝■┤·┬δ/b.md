# 改动日志

## 2026-07-30 ADC 高速采样 + UART 非阻塞发送优化

### 1. ADC 高速采样 ISR 优化（adc_sample.c）
- **位置**：`PWM_ADC_IRQHandler()`
- **修改内容**：
  - 不再调用 `ADC_GetIRQFlag()` / `ADC_ClearIRQFlag()`，改为直接读 `ADC0->IF`、写 `ADC0->IF` 清标志。
  - 不再调用 `ADC_GetConversionValue()` 读取 14 个 DAT，改为直接通过 `volatile u32 *dat = (volatile u32 *)&ADC0->DAT0` 按数组方式读取。
  - 偏移量 `g_adc_diff_offset` / `g_adc_ch7_offset` 提前复制到局部变量，避免循环中反复读全局变量。
- **原因**：工程编译优化为 `-O0`，`ADC_GetConversionValue()` 内部是 16 路 `if-else` 大 switch，调用开销极大。原 ISR 每 26.3µs 进入一次，调用 14 次该函数导致 CPU 被 ISR 占满，主循环饿死，灯不亮、电机不转、UART 无输出。

### 2. ADC 零点校准增加超时保护（adc_sample.c）
- **位置**：`PWM_ADC_OffsetCalibration()`
- **修改内容**：
  - 函数返回类型由 `void` 改为 `u8`：0=成功，1=OPA0 校准超时，2=CH7 校准超时。
  - 每次软件触发后增加约 1ms 超时退出，避免 `while (!ADC_EOS0_IRQ_IF)` 硬等死循环。
  - OPA0 短路后增加约 100µs 延时，等待输入建立稳定。
- **原因**：防止校准阶段因 ADC 状态异常导致系统卡死。

### 3. 14 个 ADC 原始 code 遥测输出（hardware_init.c）
- **位置**：`Debug_ReportTelemetry()`
- **修改内容**：在 UART 遥测末尾增加一行 `ADC_RAW: BLDC=[...] STEP=[...]`，输出最近一次 38kHz 触发得到的 14 个原始 code。
  - 偶数位 DAT0/2/4/6/8/10/12 = OPA0 差分（无刷电流）
  - 奇数位 DAT1/3/5/7/9/11/13 = CH7（步进电流）
- **原因**：便于观察 ADC 高速采样实际数据，定位电流读数跳动问题。

### 4. UART1 改为非阻塞发送（hardware_init.c）
- **位置**：`UART1_TelemetryInit()` / `UART1_SendByte()`
- **修改内容**：
  - 新增 256 字节环形发送缓冲区 `g_uart1_tx_buf[]`。
  - `UART1_SendByte()` 不再等待 `UART1->STT` 发送缓冲空，而是把字节写入环形缓冲区后立即返回。
  - 若当前无发送进行，检查发送缓冲是否为空：空则立即写第一个字节，然后使能 `SendBuffEmpty` 中断；非空则直接使能中断，由中断在发送完当前字节后继续发送。
  - 缓冲区满时直接丢弃该字节，绝不阻塞主循环。
  - 写缓冲区 + 启动发送的过程短暂关闭全局中断，防止 UART1 发送中断抢占造成竞态。
- **原因**：原阻塞式 UART 发送长遥测数据时占用主循环时间过长，拖慢 38K 节拍，导致步进走步、无刷换相不均匀/卡顿。

### 5. UART1 发送空中断处理（interrupt.c）
- **位置**：`UART1_IRQHandler()`
- **修改内容**：
  - 检测 `UART_IF_SendBufEmpty` 标志，读取环形缓冲区下一个字节发送。
  - 缓冲区发空后关闭 `SendBuffEmpty` 中断，并将 `g_uart1_tx_busy` 清零。
- **原因**：配合 `hardware_init.c` 的非阻塞 UART 发送机制。

### 6. 中断优先级配置（hardware_init.c）
- **当前配置**：
  - HALL_IRQn：0（最高，无刷换相）
  - MCPWM_IRQn：1
  - TIMER0/1_IRQn：2
  - ADC0_IRQn：3
  - UART1_IRQn：3
- **说明**：ADC0 和 UART1 优先级低于 HALL/MCPWM/TIMER0/1，不会抢占无刷换相；ADC0 与 UART1 同级，互不抢占。

### 7. 高速 ADC 采样参数
- **触发源**：TIMER3 CH0 比较事件
- **触发频率**：38 kHz（周期 26.3 µs）
- **每触发一次采样数**：14 次
  - 7 次 OPA0 差分（DAT0/2/4/6/8/10/12）
  - 7 次 CH7（DAT1/3/5/7/9/11/13）
- **ISR 频率**：38 kHz（每 26.3 µs 一次）
- **每通道原始采样率**：266 kSPS
- **总 ADC 转换次数**：532 kSPS

### 当前状态
- ADC 高速采样：已恢复并使能。
- UART 遥测 14 个 RAW code：已恢复。
- UART 发送：非阻塞，不会阻塞主循环。
- ADC 校准：带超时保护。
- 低速轮询模式 `PWM_ADC_38KStep()`：在高速模式启用后主循环中直接返回，不参与触发/读回。

## 2026-07-30 红绿灯全新控制：无料/堵转锁存 + 红绿灯统一监管

### 1. 新增系统监管状态机（hardware_init.c）
- **新增全局**：`SysMode g_sys_mode`（SYS_NORMAL / SYS_NOMATERIAL / SYS_STALL）、`g_nomaterial_tick`（P1.1 连续低计数）、`g_blink_tick`/`g_red_blink_state`（红灯闪烁相位）、`g_bldc_inhibit`/`g_wheel_inhibit`（无刷/轮盘强制停）、`g_iBldc_mA`/`g_iStep_mA`（每 tick 电流）。

> **2026-08-03 更新**：原 `g_suppress_p23`（锁存期压制 P2.3 命令）已**删除**——错误状态改由 P2.3 引脚的高电平时间对应的状态为 REV（关断）统一清除（见下文"2026-08-03"章节）。锁存期 `g_cmd` 保持强制值，不被 P2.3 带跑。
- **新增宏**：`SYS_NOMAT_3S_TICKS = 38000*3`（无料 3s 判定）、`SYS_BLINK_HALF_TICKS = 38000/2`（红灯 0.5s 半周期）。
- **新增函数**：`SysSupervisor_Tick()`（每 38K tick 首步调用：无料/堵转判定 + 电机动作兜底 + 红绿灯）、`Sys_UpdateCurrents()`（每 tick 刷新两路电流到全局，遥测与堵转判定共用）。
- **主循环**：`SysSupervisor_Tick()` 置于 `StepperFSM_Tick()` 之前；堵转态每 tick `Stepper_AllOff()` 且门控 `Stepper_Tick()`（堵转时绝不走步）。

### 2. 四态互斥优先级（高->低）
1. **无料（锁存到断电）**：P1.1 连续 3s 为低 -> 红灯常亮 + 全停动作（无刷 `Bldc_Stop`/三相高阻、38K 轮盘强制停、步进反转寻 P0.15 到位后按 50% 锁定；5s 超时则 `FSM_FAULT`=锁定不继续）；压制 P2.3 命令。
2. **堵转（锁存到断电）**：`|I_BLDC|>4A` 或 `|I_STEP|>1A`（瞬时、不去抖）-> 红灯 0.5s 闪烁 + 全停（无刷关、三相高阻、步进 `Stepper_AllOff()` 直接断电、轮盘停）；压制 P2.3 命令。
3. **FAULT（可恢复）**：寻位超时(BUjinBUdaoWEI) / 两霍尔同低 -> 红灯 0.5s 闪烁（与堵转同表现）。
4. **正常**：绿灯亮、红灯灭，各电机按 P2.3/P2.5 正常门控运行。

### 3. 删除旧红绿灯控制
- 删除初始化处 `GPIO_ResetBits(GPIO0, GPIO_Pin_2)`（上电绿灯常亮），绿/红灯改由监管每 tick 统一驱动。
- 删除 `HALL_ApplyCommutation()` 末尾 hall bit0 调试映射红灯（`GPIO_ResetBits/SetBits(GPIO2, GPIO_Pin_7)`）。

### 4. 电机门控注入
- `Bldc_Update()`：新增 `if (g_bldc_inhibit) { if (g_bldc_running) Bldc_Stop(); return; }`，无料/堵转时强制三相高阻（两种 BLDC_DEBUG 模式都生效）。
- `FeedControl_Tick()`：新增 `if (g_wheel_inhibit) { TIMER2->CMPT1 = FEED_TIMER_TH; ... return; }`，轮盘强制停（优先于 P2.5）。

> **2026-08-03 更新**：上述"命令去抖块包 `if (!g_suppress_p23)`"已删除。P2.3 命令改为由统一 `CmdDebounce_Update()` 做 100ms 去抖出 `g_p23_state`，锁存期 `g_cmd` 保持强制值（不读 P2.3），错误清除改为 P2.3 为 REV 时统一清（详见下文）。

### 5. 步进真正断电接口（stepper.c / stepper.h）
- 新增公开 `void Stepper_AllOff(void)`：内部调用原 `static stepper_all_off()`，四相 GPIO 全拉低（真正断电、释放转子），用于堵转保护；配合主循环门控 `Stepper_Tick()` 确保堵转时不重新励磁。

### 当前状态
- 红绿灯全新控制：已按规格实施，旧控制已删除。
- 无料/堵转均锁存到断电；FAULT 并入红灯闪烁。
- 电流阈值按现状（异步采样）使用，未改采样时序。

## 2026-07-30 增加无刷电机转速检测（UART 输出）

### 1. 实现要点
- **转速来源**：复用 HALL 换相中断中已累加的 `g_hall_edge_cnt`（interrupt.c 每次成功换相 `g_hall_edge_cnt++`）。用户规格：**6 个霍尔状态 = 转 1 圈**，即 6 次换相 = 1 机械圈。
- **测量窗口**：主循环遥测上报周期 = 38000 个 38K tick ≈ 1.000 秒（精确），故 `RPM = 换相次数 × 60 / 6 = 换相次数 × 10`。
- **读取/清零**：在 `Debug_ReportTelemetry()` 中读 `g_hall_edge_cnt` 后清零；16 位读写为单指令原子，无需关中断（HALL 中断仍持续累加，窗口误差 <0.1% 可忽略）。

### 2. 代码改动（hardware_init.c）
- 新增 `extern volatile u16 g_hall_edge_cnt;`（引用 interrupt.c 的换相计数）。
- 打开 `#define UART_TELEMETRY_ENABLE 1`（原被注释关闭；不打开则转速无 UART 输出）。
- `Debug_ReportTelemetry()` 末尾新增一行转速字段（与既有遥测同行输出）：
  - `BLDC_HALL_n=NNN`：本秒 HALL 换相次数；
  - `BLDC_RPS=x.xx`：圈/秒（两位小数，= 换相次数/6）；
  - `BLDC_RPM=NNN`：转/分（整数，= 换相次数×10）。
- 示例输出行（无刷运转时）：
  `P1.1=1 | P2.3=...us P2.4=...us P2.5=...us | I_BLDC=0.00A I_STEP=0.00A | BLDC_HALL_n=120 BLDC_RPS=20.00 BLDC_RPM=1200`
- 无刷停转（三相高阻 / 无料 / 堵转锁存）时 `g_hall_edge_cnt` 不再累加，转速场正常显示 `BLDC_RPM=0`。

### 当前状态
- 无刷转速检测：已实现并经 UART1(P0.7 TXD, 115200) 每秒上报；6 换相=1 圈按规格。
- 依赖 `UART_TELEMETRY_ENABLE=1` 才输出（已打开）。

---

## 2026-08-03 命令去抖 100ms 统一 + 错误由 P2.3 关断清除 + 轮盘门控 + 编译修复

### 1. 三路 PWM 命令软件去抖 10ms → 100ms（统一）

- **宏**：`FSM_CMD_TICKS` 由 `FSM_TICKS_PER_MS * 10u`（10ms）改为 `FSM_TICKS_PER_MS * 100u`（100ms）。
- **新增阈值**：`FSM_P24_FWD_US = 1700u`、`FSM_P25_FWD_US = 1u`（P2.5 高电平 > 0 = 运行，==0 无信号 = 停）。
- **新增 `CmdDebounce_Update()`**（每 38K tick 在 `SysSupervisor_Tick` 首步调用）：对 P2.3/P2.4/P2.5 各做 100ms 软件去抖，产出 `g_p23_state/g_p23_us_f`、`g_p24_state/g_p24_us_f`、`g_p25_state/g_p25_us_f`；仅连续稳定满窗口才切换状态，翻转累计期冻结 `*_us_f`。
- **约束落实**：`StepperFSM_Tick` 不再直接读 `PWM_HighLevel_GetUs(PWM_CH_P23)`；`FeedControl_Tick` 改读 `g_p25_us_f`；`Debug_ReportTelemetry` 改读三路 `*_us_f`。**仅 `CmdDebounce_Update` 内部作为去抖源读 `PWM_HighLevel_GetUs`**，其余控制/遥测代码一律读去抖后状态。
- **变量前移**：`FsmCmd`/`FsmState` typedef 及全部去抖状态变量前移到文件顶部全局区，消除 `FeedControl_Tick` 等函数对前向未声明变量的引用。

### 2. 错误清除机制（无料/堵转/FAULT 统一由 P2.3 引脚的高电平时间对应的状态为 REV 清除）

- **删除** `g_suppress_p23` 压制机制（全工程 0 处残留引用）。
- 锁存期 `g_cmd` 保持进入时强制值（无料→REV 强制反转归位；堵转→强制值），**不被 P2.3 带跑**，符合"锁存期 P2.3 不驱动电机方向"。
- **新增 3.5 节**（`SysSupervisor_Tick` 内）：当 `g_p23_state == FSM_CMD_REV`（关断，含无信号）时——
  - 清 `SYS_NOMATERIAL`/`SYS_STALL` 回 `SYS_NORMAL`，清 `g_bldc_inhibit`/`g_wheel_inhibit`；
  - 清 `FSM_FAULT` 回对应 SEEK（`g_fsm = (g_cmd==FWD)?FSM_FWD_SEEK:FSM_REV_SEEK`），并 `fsm_reset_seek()` + `Stepper_SetDir`。
- FAULT 原"命令边沿变化恢复"（`g_cmd != g_fault_cmd`）保留，与 REV 清除并存。无料强制反转归位逻辑不变。

### 3. 有刷轮盘电机运行门控（须 P2.3 开启且无错误才转）

- `FeedControl_Tick` 前置门控：须同时满足 `g_p23_state == FSM_CMD_FWD`（P2.3 开启）**且** `g_sys_mode == SYS_NORMAL`（无料/堵转未锁存）**且** `g_fsm != FSM_FAULT`（**FAULT 已纳入停止集**），才按 P2.5 去抖后 us 调速；任一不满足即轮盘停。
- 停止条件汇总：`g_wheel_inhibit`（无料/堵转锁存）OR P2.3 关断 OR 有 FAULT OR P2.5 无信号。

### 4. 编译修复（ARMCLANG V6.24 严格 C99）

- 工程编译器为 V6.24，默认严格 C99 不允许隐式函数声明。原 `UART1_SendByte`/`UART1_SendStr`/`UART1_SendU32`/`UART1_SendS32` 定义在文件后部（1022–1106 行），但 FSM/监管在 309/370/1060 行提前调用，导致 `implicit-function-declaration` 报错并连锁 `L6002U: could not open hardware_init.o`。
- **修复**：在 `SysSupervisor_Tick` 前向声明之后补 4 个 `static` 函数原型声明。`hardware_init.c` 重新全量构建通过（0 error 0 warning，Program Size 正常）。

### 当前状态
- 三路命令 100ms 去抖已实施，任何控制/遥测代码只读去抖后状态。
- 无料/堵转/FAULT 错误状态均可由 P2.3 引脚的高电平时间对应的状态为 REV（关断）清除；锁存期不驱动方向。
- 轮盘门控三条件（P2.3 开启 + 无错误 + FAULT 不在）已实施。
- 工程可正常编译链接。

