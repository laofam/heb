/*******************************************************************************
 * 版权所有 (C)2015, LINKO SEMICONDUCTOR Co.ltd
 *
 * 文件名称： hardware_init.c
 * 文件标识：
 * 内容摘要： 硬件初始化代码
 * 其它说明： 无
 * 当前版本： V 1.0
 * 作    者： 马达
 * 完成日期： 2015年11月5日
 *遥测显示的电流超过5A（BLDC）或1.6A（STEP）就会触发堵转锁存。
 *******************************************************************************/
#include "hardware_init.h"
#include "hardware_config.h"
#include "lks32mc05x_hall.h"        /* HALL 驱动：参考 12.LKS32MC_05x_HALL 工程，提供 HALL_GetFilterValue() */
#include "lks32mc05x_uart.h"          /* UART1 驱动：P0.7=UART1_TXD，替代 RTT 输出调试数据 */
#include "pwm_highlevel_capture.h"  /* 新增：基于 TIMER0(八分频) 的 PWM 高电平计时模块 */
#include "adc_sample.h"              /* 新增：两路 ADC 采样（OPA0 差分 + P0.3/CH7），38K 交替采样 */
#include "stepper.h"                 /* 新增：35BYJ46 步进电机 GPIO 驱动（半步八拍） */

void HALL_Perip_Init(void);        /* HALL 外设初始化（前向声明） */
void DebugPWM_OutputFunction(void);
extern 	int hallstatus;
extern 
uint8_t oldhall;
extern volatile u16 g_hall_edge_cnt;  /* HALL 换相计数(interrupt.c 累加)：6 次换相=1 圈，供无刷转速测量 */
extern volatile u16 g_hall_skip_cnt;   /* HALL 跳步计数(interrupt.c 累加)：自上次 UART 输出后累计，输出后清零 */

//duty 0.8 24V 1.55A
//duty 0.9 24V 2A
//#define DUTY 0.88f
#define DUTY 0.88f
/*******************************************************************************
 超前角配置：0=不超前, 1=超前一位, 2=超前两位, 3=超前三位
*******************************************************************************/
#define COMM_ADVANCE  2

/* ===================== 播料电机速度闭环（PI） =====================
   目标：P1.0 频率(Hz) 稳定到 FEED_TARGET_HZ（按 P1.0 读数计；实测 P1.0 读数≈2×霍尔电频率，
   故“100Hz 霍尔”应设 FEED_TARGET_HZ=200）。
   控制量 = TIMER2(P0.4,38K 载波)占空比 duty_q(0~1000=0%~100%)，
   写入 CMP1 = TH*(1000-duty_q)/1000（CMP1 越大占空比越小，电机越慢）。
   标定(硬件实测)：CMP1=2400(duty5%)→17Hz；CMP1=1200(duty52.5%)→180Hz。
   反馈来自 pwm_highlevel_capture.c 的“相邻上升沿周期法 + EMA”(低延迟、高分辨率)，
   取代原“800ms 滞后/整数边沿量化”方案，是 PI 能稳的前提。 */
#define FEED_DEBUG_CONST_100HZ   0       /* 1=上电固定目标 FEED_TARGET_HZ(忽略 P2.5)；0=目标由 P2.5 高电平宽度决定(100~200Hz) */
#define FEED_TARGET_HZ          100u     /* 恒速调试目标(P1.0 读数, Hz) */
#define FEED_TIMER_TH           2526u    /* TIMER2 计数模值(须与 UTimer_init 的 Timer_TH 一致) */
#define FEED_DUTY_MIN           30u      /* 最小占空比(per-mille)，防停转/堵转 */
#define FEED_DUTY_MAX           800u     /* 最大占空比(per-mille) */
#define FEED_KP                 3        /* 比例增益: 每 Hz 误差 -> 多少 per-mille 占空比(映射陡, 取小) */
#define FEED_KI_DIV             10       /* 积分增益: 每 PI tick 累加 I += err/FEED_KI_DIV (per-mille) */
#define FEED_I_MIN              (-200)   /* 积分项下限(per-mille) */
#define FEED_I_MAX              1200     /* 积分项上限(per-mille) */
#define FEED_RATE_MAX           15       /* 每 PI tick 占空比最大变化(per-mille)，抑制过冲 */
#define FEED_PI_INTERVAL_TICKS  760u     /* PI 执行间隔 ≈760*26.3us≈20ms */
#define FEED_DUTY_INIT          290      /* 初值占空比(per-mille)≈目标100Hz附近，加速收敛 */

static s32 g_feed_duty_q = (s32)FEED_DUTY_INIT;  /* 当前占空比(per-mille) */
static s32 g_feed_i      = 0;                    /* 积分项(per-mille) */
static u32 g_feed_pi_tick = 0;                   /* PI 间隔计数(38K tick) */
static u8  g_fan_enable   = 0;                   /* 无刷使能门控：仅 StepperFSM 的 FWD_HOME 置 1；现仅作为无刷(BLDC)门控(生产模式)，轮盘改由 P2.5 控制(见 10.7) */
volatile u8 g_bldc_running = 0;                  /* 无刷实际驱动状态：与轮盘同启同停(复用 g_fan_enable 门控)；1=转，0=三相高阻 */
static void Bldc_Update(void);   /* 每 38K tick 调用：按 g_fan_enable 边沿启停无刷 */
static void Bldc_Start(void);    /* 启动无刷：短时再预充 + 踢一脚换相 + 使能输出 */
static void Bldc_Stop(void);     /* 停止无刷：PWMOutputs(DISABLE) 三相高阻、自由滑行 */

/* ===================== 系统监管：无料/堵转锁存 + 红绿灯 =====================
   优先级（高->低）：无料(SYS_NOMATERIAL, 锁存) > 堵转(SYS_STALL, 锁存)
     > FAULT(FSM_FAULT, 红灯闪烁, 关断信号即清) > 正常(绿灯)
   · 无料：P1.1 连续 3s 为低 -> 红灯常亮 + 全停(无刷关/三相高阻/轮盘停)
            + 步进反转寻 P0.15 到位后按 50% 锁定(复用 REV_SEEK->REV_HOME)；
            若反转寻位 5s 超时 -> 锁定不继续(FSM 进 FAULT，红灯仍常亮)。
   · 堵转：I_BLDC>4A 或 I_STEP>1A(瞬时、不去抖) -> 红灯 0.5s 闪烁 + 全停
            (无刷关/三相高阻/步进直接断电不动作/轮盘停)，锁存到断电。
   · 无料/堵转一旦锁存，收到关断信号(P2.3 高电平<=1700us)即清、重新正常跑；FAULT 同此逻辑。
   · 步进寻位最长 5s(FSM_SEEK_TIMEOUT_TICKS)，超时必进 FAULT 停，不会一直转。 */
typedef enum {
    SYS_NORMAL = 0,
    SYS_NOMATERIAL,   /* 无料，锁存到断电 */
    SYS_STALL         /* 堵转，锁存到断电 */
} SysMode;

#define SYS_NOMAT_3S_TICKS     (38000u * 3u)   /* 无料判定：P1.1 连续低 3s */
#define SYS_BLINK_HALF_TICKS   (38000u / 10u)  /* 红灯闪烁半周期 0.1s */

static SysMode g_sys_mode        = SYS_NORMAL;
static u32     g_nomaterial_tick = 0;          /* P1.1 连续低计数(38K tick) */
static u32     g_blink_tick      = 0;          /* 红灯闪烁相位计数 */
static u8      g_red_blink_state = 0;          /* 红灯当前亮/灭(闪烁用) */
static u8      g_bldc_inhibit    = 0;          /* 1=强制无刷三相高阻 */

/* ---- 步进/命令状态类型与全局变量（前移，供 FeedControl_Tick 等前部函数使用，避免前向引用） ---- */
typedef enum { FSM_CMD_FWD = 0, FSM_CMD_REV = 1 } FsmCmd;
typedef enum {
    FSM_BOOT_REV = 0,   /* 上电反转归位 */
    FSM_FWD_SEEK,       /* 正转寻 P0.14 */
    FSM_REV_SEEK,       /* 反转寻 P0.15 */
    FSM_FWD_HOME,       /* 正转到位 STOP，风机转 */
    FSM_REV_HOME,       /* 反转到位 STOP，风机停 */
    FSM_FAULT           /* 故障锁定 */
} FsmState;

static FsmState g_fsm        = FSM_BOOT_REV;
static FsmCmd   g_cmd        = FSM_CMD_REV; /* 步进 FSM 当前方向命令：NORMAL 时由系统监管同步为 g_p23_state；锁存时保持强制值(不被 P2.3 带跑) */

/* 三路 PWM 输入统一 100ms 软件去抖：任何代码只读以下 *_state / *_us_f，禁止直接读 PWM_HighLevel_GetUs 未去抖值 */
static FsmCmd g_p23_state = FSM_CMD_REV;  /* P2.3 引脚的高电平时间对应的状态(去抖后)：FWD=开启/正转，REV=关断/反转(默认) */
static u32    g_p23_us_f  = 0;            /* P2.3 去抖稳定后的高电平时间(us)，仅用于遥测显示 */
static u32    g_p23_deb   = 0;            /* P2.3 去抖计数 */
static FsmCmd g_p24_state = FSM_CMD_REV;  /* P2.4 引脚的高电平时间对应的状态(去抖后) */
static u32    g_p24_us_f  = 0;
static u32    g_p24_deb   = 0;
static FsmCmd g_p25_state = FSM_CMD_REV;  /* P2.5 引脚的高电平时间对应的状态(去抖后)：FWD=有信号/运行，REV=无信号/停 */
static u32    g_p25_us_f  = 0;            /* P2.5 去抖稳定后的高电平时间(us)，用于轮盘调速 */
static u32    g_p25_deb   = 0;

/* 注：原 g_fault_cmd(FAULT 边沿恢复)已删除——FAULT 现改为关断信号即清，无需记录进入时命令 */
static u8      g_wheel_inhibit   = 0;          /* 1=强制轮盘停(优先于 P2.5) */
static s32     g_iBldc_mA        = 0;          /* 无刷相电流(mA)，每 tick 更新 */
static s32     g_iStep_mA        = 0;          /* 步进相电流(mA)，每 tick 更新 */

static void SysSupervisor_Tick(void);   /* 每 38K tick：无料/堵转判定 + 红绿灯 + 电机动作兜底 */

/* UART1 遥测辅助函数前向声明：定义在文件后部，但 FSM/监管等处提前调用，
   ARMCLANG V6 严格 C99 不允隐式声明，须在此先声明（修复 implicit-function-declaration 报错）。 */
static void UART1_SendByte(u8 b);
static void UART1_SendStr(const char *s);
static void UART1_SendU32(u32 v);
static void UART1_SendS32(s32 v);

/* 播料(轮盘)电机速度闭环 PI：每 ~20ms 由主循环 38K 节拍调用一次。
   读取 P1.0 平滑频率，算误差，更新积分(抗饱和)，输出占空比(限变化率)，写 TIMER2->CMPT1。
   门控（2026-07 需求变更：轮盘【只听 P2.5】，见需求日志 10.7）——
     P2.5 有有效信号(h25>0) -> 按 h25 宽度调速运行；
     P2.5 无信号(h25==0，含信号丢失自动清零) -> 轮盘停转(占空比 0)，不跑 PI；
   步进到位(g_fan_enable)不再控制轮盘，解除“步进到位即转”旧绑定。
   注：FEED_DEBUG_CONST_100HZ=1 时忽略 P2.5、强制恒速运行（调试单独调轮盘 PI 用）。 */
static void FeedControl_Tick(void)
{
    u32 h25 = 0u;

    /* 轮盘运行门控：必须步进风门正转到位(g_fan_enable=1)，且 P2.3 引脚的高电平时间对应的状态为 FWD(开启) 且 无错误，才按 P2.5 调速；否则停。
       错误集含：无料/堵转锁存(g_sys_mode!=SYS_NORMAL) 与 FAULT(g_fsm==FSM_FAULT)。 */
    if (!g_fan_enable)              { TIMER2->CMPT1 = (u32)FEED_TIMER_TH; g_feed_pi_tick = 0; return; }  /* 步进风门未到位 -> 轮盘停(与无刷风机同启同停) */
    if (g_p23_state != FSM_CMD_FWD) { TIMER2->CMPT1 = (u32)FEED_TIMER_TH; g_feed_pi_tick = 0; return; }  /* P2.3 关断 -> 轮盘停 */
    if (g_sys_mode != SYS_NORMAL)   { TIMER2->CMPT1 = (u32)FEED_TIMER_TH; g_feed_pi_tick = 0; return; }  /* 无料/堵转锁存 -> 轮盘停 */
    if (g_fsm == FSM_FAULT)         { TIMER2->CMPT1 = (u32)FEED_TIMER_TH; g_feed_pi_tick = 0; return; }  /* FAULT -> 轮盘停 */

#if (FEED_DEBUG_CONST_100HZ == 1)
    /* 调试恒速模式：忽略 P2.5，强制按目标转速运行 */
#else
    /* 轮盘调速：读 P2.5 去抖稳定后的高电平时间(us)；无信号(g_p25_us_f==0)即停。 */
    h25 = g_p25_us_f;
    if (h25 > 2000u) h25 = 2000u;
    if (h25 < 1000u) h25 = 1000u;
    if (h25 == 0u)
    {
        TIMER2->CMPT1 = (u32)FEED_TIMER_TH;
        g_feed_pi_tick = 0;
        return;
    }
#endif

    u32 freq, target;
    s32 err, P, duty_raw, duty;

    /* 1) 目标频率 */
#if (FEED_DEBUG_CONST_100HZ == 1)
    target = FEED_TARGET_HZ;
#else
//    target = 100u + ((h25 - 1000u) * 100u) / 1000u;   /* 1000us→100Hz, 2000us→200Hz, 线性调速 */
    target = (100u + ((h25 - 1000u) * 800u))>>10;   /* 1000us→100Hz, 2000us→200Hz, 线性调速 */
#endif

    /* 2) 当前速度(P1.0 平滑频率) */
    freq = PWM_HighLevel_GetP10FreqInstant();
    if (freq > 100000u) freq = 0;   /* 防垃圾值 */

    /* 3) PI 间隔：仅每 FEED_PI_INTERVAL_TICKS 个 38K tick 计算一次（解耦测量，不进中断） */
    g_feed_pi_tick++;
    if (g_feed_pi_tick < FEED_PI_INTERVAL_TICKS) return;
    g_feed_pi_tick = 0;

    /* 4) 误差 = 目标 - 实际（实际为 0 表示停转，下方会全力提速） */
    err = (s32)target - (s32)freq;

    /* 5) 比例项 */
    P = (s32)FEED_KP * err;

    /* 6) 积分项（抗饱和 + 停转不积分防深饱和） */
    if (freq != 0u)
    {
        s32 i_new = g_feed_i + err / (s32)FEED_KI_DIV;
        if (i_new < (s32)FEED_I_MIN) i_new = (s32)FEED_I_MIN;
        else if (i_new > (s32)FEED_I_MAX) i_new = (s32)FEED_I_MAX;
        g_feed_i = i_new;
    }

    /* 7) 位置式输出 duty = P + I，先钳位 */
    duty_raw = P + g_feed_i;
    if (duty_raw > (s32)FEED_DUTY_MAX) duty_raw = (s32)FEED_DUTY_MAX;
    else if (duty_raw < (s32)FEED_DUTY_MIN) duty_raw = (s32)FEED_DUTY_MIN;

    /* 8) 抗积分饱和回退：若被钳位且误差继续同向推，把 I 拉回使 P+I==钳位值 */
    if (duty_raw == (s32)FEED_DUTY_MAX && (P + g_feed_i) > (s32)FEED_DUTY_MAX)
        g_feed_i = (s32)FEED_DUTY_MAX - P;
    else if (duty_raw == (s32)FEED_DUTY_MIN && (P + g_feed_i) < (s32)FEED_DUTY_MIN)
        g_feed_i = (s32)FEED_DUTY_MIN - P;

    /* 9) 输出变化率限幅（每 tick 最大 ±FEED_RATE_MAX），抑制过冲 */
    duty = duty_raw;
    {
        s32 delta = duty - g_feed_duty_q;
        if (delta > (s32)FEED_RATE_MAX) duty = g_feed_duty_q + (s32)FEED_RATE_MAX;
        else if (delta < -(s32)FEED_RATE_MAX) duty = g_feed_duty_q - (s32)FEED_RATE_MAX;
    }

    /* 10) 限幅并写入 TIMER2->CMPT1（CMP1 越大占空比越小） */
    if (duty > (s32)FEED_DUTY_MAX) duty = (s32)FEED_DUTY_MAX;
    else if (duty < (s32)FEED_DUTY_MIN) duty = (s32)FEED_DUTY_MIN;
    g_feed_duty_q = duty;

    /* 遥测：target / freq / duty / I（仅 PI 执行周期，约每 20ms 一行） */
    UART1_SendByte('T'); UART1_SendByte(':'); UART1_SendU32(target);
    UART1_SendByte(' '); UART1_SendByte('F'); UART1_SendByte(':'); UART1_SendU32(freq);
    UART1_SendByte(' '); UART1_SendByte('D'); UART1_SendByte(':'); UART1_SendS32(duty);
    UART1_SendByte(' '); UART1_SendByte('I'); UART1_SendByte(':'); UART1_SendS32(g_feed_i);
    UART1_SendStr("\r\n");

    {
        s32 cmp1 = (s32)((u32)FEED_TIMER_TH * ((u32)1000u - (u32)duty)) / 1000;
        if (cmp1 < 0) cmp1 = 0;
        if (cmp1 > (s32)FEED_TIMER_TH) cmp1 = (s32)FEED_TIMER_TH;
        TIMER2->CMPT1 = (u32)cmp1;
    }
}

/* ===================== 步进归位状态机（StepperFSM） =====================
   （接口声明见 stepper.h：StepperFSM_Init / StepperFSM_Tick）
   时间基准 = 38K tick（≈26.3us/tick）。设计要点（来自需求日志 + 用户拍板）：
   · 上电进入 BOOT_REV：反转找 P0.15 低（反转到位），到位后转 REV_HOME(STOP@50%,风机停)。
   · P2.3 高电平宽度(us)：>1700 => 正转命令；<=1700(含无信号=0) => 反转命令(安全默认)。
   · 命令=正转：正转寻 P0.14 低 -> FWD_HOME(STOP@50%, 立即启动风机 PID)。
   · 命令=反转：反转寻 P0.15 低 -> REV_HOME(STOP@50%, 风机停)。
   · 外力移位：目标霍尔连续 20ms 高 -> 重新寻位（途中风机停，到位后再启动）。
   · 运动中命令反转：立即中止当前方向、反向寻位（含上电归位途中命令反转 -> 放弃归位直接正转）。
   · 到位判定：首次读到低即停步 + 2ms 确认（去抖）。
   · 故障：P0.14 与 P0.15 同时低(去抖 10ms) -> FAULT(步进停、风机停)；命令边沿变化 -> 反向旋转恢复，再等 5s。
   · 寻位 5s(≈190000 tick)超时未到位 -> FAULT。
   斩波占空比由 stepper.c 的 Stepper_Tick 按 g_state 自动选：运行(FWD/REV)=STEPPER_RUN_DUTY_PCT(90%)，
   停止(STOP)=STEPPER_STOP_DUTY_PCT(50%)，本 FSM 不改动占空比。 */
#define FSM_TICKS_PER_MS        ((u32)38u)
#define FSM_HOME_LOW_TICKS      (FSM_TICKS_PER_MS *  2u)    /* 到位确认 2ms */
#define FSM_SHIFT_HIGH_TICKS    (FSM_TICKS_PER_MS * 20u)    /* 移位重寻迟滞 20ms */
#define FSM_FAULT_TICKS         (FSM_TICKS_PER_MS * 10u)    /* 故障去抖 10ms */
#define FSM_CMD_TICKS           (FSM_TICKS_PER_MS * 100u)   /* 命令去抖 100ms（三路 P2.3/P2.4/P2.5 统一） */
#define FSM_SEEK_TIMEOUT_TICKS  (38000u * 5u)               /* 寻位超时 5s */
#define FSM_P23_FWD_US          ((u32)1700u)                /* P2.3 高电平 > 此值 = 正转命令(FWD/开启) */
#define FSM_P24_FWD_US          ((u32)1700u)                /* P2.4 高电平 > 此值 = FWD */
#define FSM_P25_FWD_US          ((u32)1u)                   /* P2.5 高电平 > 0(有信号) = FWD(运行)，==0(无信号) = REV(停) */

/* 注：FsmCmd/FsmState 类型与 g_fsm/g_cmd/g_p2x_state 等全局变量已前移至文件顶部全局区 */

static u32 g_fsm_seek_to     = 0;           /* 寻位超时计数 */
static u32 g_fsm_home_high   = 0;           /* home 态目标霍尔"连续高"计数(移位迟滞) */
static u32 g_fsm_fault_low   = 0;           /* 两路同时低计数(故障去抖) */
static u8  g_fsm_confirm     = 0;           /* 到位确认子状态进行中 */
static u32 g_fsm_confirm_cnt = 0;           /* 到位确认计数 */
static u8  g_fault_active         = 0;       /* 1=正在 FAULT 锁定中(等待用户切 P2.3 才清) */
static FsmCmd g_fault_entered_cmd = FSM_CMD_REV; /* 进入 FAULT 时的 g_cmd，用于检测命令变化 */

/* 复位一次寻位的临时计数（不改变方向/门控，仅清超时/迟滞/确认计数） */
static void fsm_reset_seek(void)
{
    g_fsm_seek_to     = 0;
    g_fsm_home_high   = 0;
    g_fsm_confirm     = 0;
    g_fsm_confirm_cnt = 0;
    g_fsm_fault_low   = 0;   /* 清故障去抖计数：FAULT 恢复回 SEEK 后从 0 重新判定，避免故障源未排除时立即重触发 FAULT */
}

/* 三路 PWM 输入统一 100ms 软件去抖更新：任何代码只读 *_state / *_us_f，不直接读 PWM_HighLevel_GetUs。
   状态翻转须连续稳定 FSM_CMD_TICKS(100ms) 才切换；仅状态稳定时刷新 *_us_f，翻转累计期间冻结，确保数值亦来自去抖后。 */
static void CmdDebounce_Update(void)
{
    u32 us; FsmCmd now;

    /* P2.3 */
    us  = PWM_HighLevel_GetUs(PWM_CH_P23);
    now = (us > FSM_P23_FWD_US) ? FSM_CMD_FWD : FSM_CMD_REV;
    if (now == g_p23_state) { g_p23_deb = 0; g_p23_us_f = us; }
    else { g_p23_deb++; if (g_p23_deb >= FSM_CMD_TICKS) { g_p23_state = now; g_p23_deb = 0; g_p23_us_f = us; } }

    /* P2.4 */
    us  = PWM_HighLevel_GetUs(PWM_CH_P24);
    now = (us > FSM_P24_FWD_US) ? FSM_CMD_FWD : FSM_CMD_REV;
    if (now == g_p24_state) { g_p24_deb = 0; g_p24_us_f = us; }
    else { g_p24_deb++; if (g_p24_deb >= FSM_CMD_TICKS) { g_p24_state = now; g_p24_deb = 0; g_p24_us_f = us; } }

    /* P2.5 */
    us  = PWM_HighLevel_GetUs(PWM_CH_P25);
    now = (us > FSM_P25_FWD_US) ? FSM_CMD_FWD : FSM_CMD_REV;
    if (now == g_p25_state) { g_p25_deb = 0; g_p25_us_f = us; }
    else { g_p25_deb++; if (g_p25_deb >= FSM_CMD_TICKS) { g_p25_state = now; g_p25_deb = 0; g_p25_us_f = us; } }
}

/* 读取两路霍尔：低电平有效 -> 返回 1 表示到位 */
static u8 fsm_read_h14(void)
{
    return (GPIO_ReadInputDataBit(GPIO0, GPIO_Pin_14) == Bit_RESET) ? (u8)1u : (u8)0u;
}
static u8 fsm_read_h15(void)
{
    return (GPIO_ReadInputDataBit(GPIO0, GPIO_Pin_15) == Bit_RESET) ? (u8)1u : (u8)0u;
}

/* SEEK 公共逻辑：超时(5s)->FAULT；到位确认(2ms)完成 -> 进入对应 HOME（或假触发则继续寻位）。
   target_low   = 当前目标霍尔是否低(1=到位)
   is_fwd_home  = 确认成功后是 FWD_HOME(风机转) 还是 REV_HOME(风机停)
   注：首次读低"停步+置风机"已在各 SEEK case 入口完成，此处只做计时/确认判定。 */
static void fsm_seek_common(u8 target_low, u8 is_fwd_home)
{
    g_fsm_seek_to++;
    if (g_fsm_seek_to >= FSM_SEEK_TIMEOUT_TICKS)   /* 5s 未到位 -> 故障锁定 */
    {
        g_fsm = FSM_FAULT; g_fan_enable = 0;
        Stepper_SetDir(STEPPER_DIR_STOP);
        fsm_reset_seek();
#if (UART_TELEMETRY_ENABLE == 1)
        UART1_SendStr("BUjinBUdaoWEI\r\n");   /* 步进寻位5s超时未到位；仅状态切换这一刻发一次(阻塞但不关中断)，不每 tick 发，避免拖慢主循环 */
#endif
				return;
    }
    if (g_fsm_confirm)
    {
        g_fsm_confirm_cnt++;
        if (g_fsm_confirm_cnt >= FSM_HOME_LOW_TICKS)   /* 2ms 确认窗口结束 */
        {
            g_fsm_confirm = 0;
            g_fsm_confirm_cnt = 0;
            if (target_low)
            {
                g_fsm = is_fwd_home ? FSM_FWD_HOME : FSM_REV_HOME;
                g_fsm_home_high = 0;
                g_fsm_seek_to   = 0;
            }
            else
            {
                /* 假触发：取消确认，恢复走步继续寻位 */
                Stepper_SetDir(is_fwd_home ? STEPPER_DIR_FWD : STEPPER_DIR_REV);
            }
        }
    }
}

void StepperFSM_Init(void)
{
    g_fan_enable    = 0;
    g_fsm           = FSM_BOOT_REV;
    g_cmd           = FSM_CMD_REV;   /* 默认反转(安全)；上电无 P2.3 信号时即反转归位 */
    g_p23_state = FSM_CMD_REV; g_p23_us_f = 0; g_p23_deb = 0;
    g_p24_state = FSM_CMD_REV; g_p24_us_f = 0; g_p24_deb = 0;
    g_p25_state = FSM_CMD_REV; g_p25_us_f = 0; g_p25_deb = 0;
    fsm_reset_seek();
    g_fsm_fault_low = 0;
    g_fault_active = 0;                 /* 上电无 FAULT */
    Stepper_SetDir(STEPPER_DIR_REV);  /* 上电进入反转归位（找 P0.15） */
}

void StepperFSM_Tick(void)
{
    u8 h14 = fsm_read_h14();
    u8 h15 = fsm_read_h15();

    /* 1) 命令来源：P2.3 引脚的高电平时间对应的状态由 CmdDebounce_Update() 统一 100ms 去抖为 g_p23_state；
          系统监管在 g_sys_mode==SYS_NORMAL 时把 g_cmd 同步为 g_p23_state；锁存期间 g_cmd 保持强制值(不被 P2.3 带跑)。
          故此处不再直接读 P2.3 硬件。 */

    /* 2) 故障检测：两路同时低（去抖 10ms）-> FAULT（非 FAULT 态才检测） */
    if (g_fsm != FSM_FAULT)
    {
        if (h14 && h15)
        {
            g_fsm_fault_low++;
            if (g_fsm_fault_low >= FSM_FAULT_TICKS)
            {
                g_fsm = FSM_FAULT; g_fan_enable = 0;
                Stepper_SetDir(STEPPER_DIR_STOP);
                fsm_reset_seek();
#if (UART_TELEMETRY_ENABLE == 1)
                UART1_SendStr("FAULT: both HALL low\r\n");   /* 两路同时低(去抖后)锁定；仅切换这一刻发一次 */
#endif
								return;
            }
        }
        else g_fsm_fault_low = 0;
    }

    switch (g_fsm)
    {
    case FSM_BOOT_REV:   /* 上电反转归位：找 P0.15 低 */
        if (g_cmd == FSM_CMD_FWD) { g_fsm = FSM_FWD_SEEK; fsm_reset_seek(); Stepper_SetDir(STEPPER_DIR_FWD); g_fan_enable = 0; break; }
        if (h15 && !g_fsm_confirm) { g_fsm_confirm = 1; g_fsm_confirm_cnt = 0; Stepper_SetDir(STEPPER_DIR_STOP); g_fan_enable = 0; }
        else if (!g_fsm_confirm)  { g_fan_enable = 0; }   /* 仍在走步寻位 -> 风机停 */
        fsm_seek_common(h15, 0);
        break;

    case FSM_FWD_SEEK:   /* 正转寻 P0.14 */
        if (g_cmd == FSM_CMD_REV) { g_fsm = FSM_REV_SEEK; fsm_reset_seek(); Stepper_SetDir(STEPPER_DIR_REV); g_fan_enable = 0; break; }
        if (h14 && !g_fsm_confirm) { g_fsm_confirm = 1; g_fsm_confirm_cnt = 0; Stepper_SetDir(STEPPER_DIR_STOP); g_fan_enable = 1; /* 首次读低即停步 + 立即启动风机 */ }
        else if (!g_fsm_confirm)  { g_fan_enable = 0; }   /* 仍在走步寻位(未到位/已取消确认) -> 风机停 */
        fsm_seek_common(h14, 1);
        break;

    case FSM_REV_SEEK:   /* 反转寻 P0.15 */
        if (g_cmd == FSM_CMD_FWD) { g_fsm = FSM_FWD_SEEK; fsm_reset_seek(); Stepper_SetDir(STEPPER_DIR_FWD); g_fan_enable = 0; break; }
        if (h15 && !g_fsm_confirm) { g_fsm_confirm = 1; g_fsm_confirm_cnt = 0; Stepper_SetDir(STEPPER_DIR_STOP); g_fan_enable = 0; }
        else if (!g_fsm_confirm)  { g_fan_enable = 0; }
        fsm_seek_common(h15, 0);
        break;

    case FSM_FWD_HOME:   /* 正转到位：风机转，持续监控命令翻转/外力移位 */
        g_fan_enable = 1;
        if (g_cmd == FSM_CMD_REV) { g_fsm = FSM_REV_SEEK; fsm_reset_seek(); Stepper_SetDir(STEPPER_DIR_REV); g_fan_enable = 0; break; }
        if (h14) g_fsm_home_high = 0;
        else { g_fsm_home_high++; if (g_fsm_home_high >= FSM_SHIFT_HIGH_TICKS) { g_fsm = FSM_FWD_SEEK; fsm_reset_seek(); Stepper_SetDir(STEPPER_DIR_FWD); g_fan_enable = 0; } }
        break;

    case FSM_REV_HOME:   /* 反转到位：风机停，持续监控命令翻转/外力移位 */
        g_fan_enable = 0;
        if (g_cmd == FSM_CMD_FWD) { g_fsm = FSM_FWD_SEEK; fsm_reset_seek(); Stepper_SetDir(STEPPER_DIR_FWD); break; }
        if (h15) g_fsm_home_high = 0;
        else { g_fsm_home_high++; if (g_fsm_home_high >= FSM_SHIFT_HIGH_TICKS) { g_fsm = FSM_REV_SEEK; fsm_reset_seek(); Stepper_SetDir(STEPPER_DIR_REV); } }
        break;

    case FSM_FAULT:      /* 故障锁定：步进停、风机停。
                             进入时记住 g_cmd；只有用户切 P2.3(命令变了)才清 FAULT、重新寻位。
                             防止自动循环清 FAULT 导致步进不停转。 */
        g_fan_enable = 0;
        if (!g_fault_active)
        {
            g_fault_active = 1;
            g_fault_entered_cmd = g_cmd;   /* 刚进 FAULT：记住当时的命令 */
        }
        if (g_cmd != g_fault_entered_cmd)  /* 用户切了 P2.3(命令变了) -> 清 FAULT */
        {
            g_fault_active = 0;
            if (g_cmd == FSM_CMD_REV)
            {
                g_fsm = FSM_REV_SEEK;
                fsm_reset_seek();
                Stepper_SetDir(STEPPER_DIR_REV);
            }
            else
            {
                g_fsm = FSM_FWD_SEEK;
                fsm_reset_seek();
                Stepper_SetDir(STEPPER_DIR_FWD);
            }
        }
        /* 否则：保持 FAULT，步进停，等用户切 P2.3 */
        break;

    default: break;
    }
}



/*******************************************************************************
 方向配置：0=正转(FORWARD), 1=反转(REVERSE)
 仅修改此宏即可切换电机转向；hall_to_step 与 NEXT_MAP 会自动随之重建。
*******************************************************************************/
#define MOTOR_DIR  0   /* 0:正转, 1:反转。与"MCPWM旧版会转"工程保持一致(MOTOR_DIR=0)，该旧版无刷可正常转动；
                           当前无刷换相完全沿用旧版逻辑(SEQ_FWD / BuildHallTables / NEXT_MAP / HALL_ApplyCommutation /
                           三相下管预充2秒后初始换相)，不再依赖 TIMER3 38K 中断。若仍锁死，再查霍尔接线/序列。 */

/*******************************************************************************
 最小无刷模式开关（定位"旧版会转、当前锁死"的根因）
 --------------------------------------------------------------------------
 逐行对比"MCPWM旧版会转"工程后确认：旧版能转的运行环境极其干净——
   · 只使能 MCPWM(优先级1) + HALL(优先级0) 两个中断；
   · 主循环为空 for(;;){__NOP();}；
   · 无 ADC、无 TIMER0/1 捕获、无 RTT 打印。
 当前版新增的“三路捕获(P2.3/2.4/2.5 双沿, NOPULL) + TIMER0/1 中断 + ADC + 主循环 RTT 打印”
 会带来中断风暴/外设交互/主循环阻塞，改变了无刷的运行环境，导致锁死。

 BLDC_MINIMAL_MODE = 1（默认）：关闭上述所有非无刷子系统，使无刷运行环境与旧版完全一致，
   仅保留步进(纯 GPIO + 主循环轮询 TIMER3 计数，对无刷零干扰)。用于确认无刷是否恢复转动。
 BLDC_MINIMAL_MODE = 0：恢复全部子系统(捕获/ADC/遥测)。确认无刷 OK 后再逐一打开定位具体干扰源。
*******************************************************************************/
#define BLDC_MINIMAL_MODE  0   /* 恢复“其他都打开”：捕获/ADC/TIMER0/1 中断全开。
                                    此前无刷锁死的根因之一是 RTT 在 Keil+M0 下用 PRIMASK 全局关中断，
                                    屏蔽了 HALL 换相中断；现已彻底弃用 RTT，改用 UART1(P0.7 TXD) 阻塞发送，
                                    发送期间不关中断，对换相零干扰。
                                    若此后无刷再锁死，与调试输出无关，最大嫌疑是 P2.3/2.4 双沿捕获中断风暴
                                    (可用软件手段关 TIMER0/1 NVIC 或改单沿捕获缓解，不动 GPIO 引脚本身)。 */

/* 串口遥测开关：=0 关闭主循环 UART1 调试数据输出；=1 打开。
   调试数据经 UART1(P0.7 TXD, 115200-8-N-1) 阻塞发送，发送期间不关中断，对电机控制零干扰。
   打开捕获(TIMER0/1)与 ADC 已随 BLDC_MINIMAL_MODE=0 恢复。 */
#define UART_TELEMETRY_ENABLE  1   /* 打开 UART 遥测：无刷转速/电流/电平每秒经 P0.7 TXD 上报 */

/* 步进序列（唯一真源）：正转/反转下 step0..step5 随转子前进依次出现的霍尔值 */
static const uint8_t SEQ_FWD[6] = {4, 0, 1, 3, 7, 6};   /* 正转：霍尔随 step 递增的出现顺序 */
static const uint8_t SEQ_REV[6] = {6, 7, 3, 1, 0, 4};   /* 反转序列(正转序列反向)：仅供 NEXT_MAP 合法性校验使用；
                                                           实际转矩反向由 HALL_ApplyCommutation 对 COMM_ADVANCE 取负实现 */
#if (MOTOR_DIR == 0)
#define SEQ  SEQ_FWD
#else
#define SEQ  SEQ_REV
#endif

void BuildHallTables(void);   /* 依据 SEQ 自动生成 hall_to_step 与 NEXT_MAP（前向声明） */


/*******************************************************************************
 函数名称：    void Hardware_init(void)
 功能描述：    硬件部分初始化
 输入参数：    无
 输出参数：    无
 返 回 值：    无
 其它说明：
 修改日期      版本号          修改人            修改内容
 -----------------------------------------------------------------------------
 2015/11/5      V1.0           Howlet Li          创建
 *******************************************************************************/
void Hardware_init(void)
{
    __disable_irq();                 /* 关闭中断 中断总开关 */
    SYS_WR_PROTECT = 0x7a83;         /* 开启寄存器写使能 */
    FLASH_CFG |= 0x00080000;         /* enable prefetch */
    GPIO_init();                     /* GPIO初始化 */
    MCPWM_init();                    /* MCPWM初始化 */
    UTimer_init();                    /* 通用计数器初始化 */
    HALL_Perip_Init();               /* HALL 外设初始化（参考 HALL 工程，仅轮询采样） */
#if (BLDC_MINIMAL_MODE == 0)
    PWM_HighLevel_Init();            /* TIMER0/1(八分频) 三路捕获(P2.3/2.4/2.5)：会引入捕获中断，最小模式下关闭 */
    PWM_ADC_Init();                  /* 两路 ADC 采样(OPA0 差分 + P0.3/CH7)：最小模式下关闭 */
    /* 校准前强制关断步进四相，确保 CH7 采样电阻无电流。
       必须先配成输出模式再拉低——输入模式下 GPIO_ResetBits 不驱动引脚，外部驱动管可能仍导通。 */
    {
        GPIO_InitTypeDef tmp;
        GPIO_StructInit(&tmp);
        tmp.GPIO_Mode = GPIO_Mode_OUT;
        tmp.GPIO_PuPd = GPIO_PuPd_NOPULL;
        tmp.GPIO_Pin  = GPIO_Pin_9 | GPIO_Pin_10;
        GPIO_Init(GPIO2, &tmp);   /* A/B 相 -> 输出 */
        GPIO_Init(GPIO0, &tmp);   /* C/D 相 -> 输出 */
    }
    GPIO_ResetBits(GPIO2, (u16)(GPIO_Pin_9 | GPIO_Pin_10));   /* A=0 B=0 */
    GPIO_ResetBits(GPIO0, (u16)(GPIO_Pin_9 | GPIO_Pin_10));   /* C=0 D=0 */
    SoftDelay(100000);               /* 延时约 5ms，等待 OPA0、外部运放及 ADC 模拟前端稳定 + RSTN 电路稳定 */
    /* P0.2/RSTN 切 GPIO，驱动绿色 LED（低电平亮）。借上面 5ms 延时，RSTN 电路已稳定。 */
    SYS_WR_PROTECT = 0x7a83;
    SYS_RST_CFG |= BIT5;              /* RST_IO=1: P0.2 从 RSTN 切为 GPIO */
    SYS_WR_PROTECT = 0;
    {
        GPIO_InitTypeDef led;
        GPIO_StructInit(&led);
        led.GPIO_Mode = GPIO_Mode_OUT;
        led.GPIO_Pin  = GPIO_Pin_2;
        led.GPIO_PuPd = GPIO_PuPd_NOPULL;
        GPIO_Init(GPIO0, &led);
    }
    /* P0.2 绿灯初态由系统监管 SysSupervisor_Tick 每 tick 统一控制，此处不预点亮 */
    PWM_ADC_OffsetCalibration();     /* 软件零点校准：步进四相已关断，确保无电流 */
    PWM_ADC_StartHighSpeedSampling();/* 启动 ADC 高速中断自触发采样，ISR 中维护两路电流峰值 */
#endif
    Stepper_Init();                  /* 35BYJ46 步进电机 GPIO 驱动初始化（四相八拍，默认正转）——纯 GPIO，对无刷无干扰，始终保留 */
    StepperFSM_Init();               /* 步进归位 FSM：进入上电反转归位(BOOT_REV)，由 38K 主循环 StepperFSM_Tick 驱动 */
    NVIC_EnableIRQ(MCPWM_IRQn);      /*使能MCPWM定时器中断*/
    NVIC_SetPriority(MCPWM_IRQn, 1); /*MCPWM中断优先级配置*/
	    NVIC_EnableIRQ(HALL_IRQn);      /* 使能HALL中断 */
    NVIC_SetPriority(HALL_IRQn, 0); /* 配置HALL中断优先级 */
#if (BLDC_MINIMAL_MODE == 0)
    /* TIMER0/TIMER1 改为轮询模式：不在中断中读捕获值，改由主循环 38K 节拍轮询标志位+读 CMPTx。
       消除 TIMER0/1 中断对 HALL 换相的抢占延迟。 */
    /* NVIC_EnableIRQ(TIMER0_IRQn); */
    NVIC_SetPriority(TIMER0_IRQn, 2);/* 保留优先级设置（无害） */
    /* NVIC_EnableIRQ(TIMER1_IRQn); */
    NVIC_SetPriority(TIMER1_IRQn, 2);
    /* ADC 改为软件触发+轮询，不用中断 */
    /* NVIC_EnableIRQ(ADC0_IRQn); */
    NVIC_SetPriority(ADC0_IRQn, 3);
    NVIC_EnableIRQ(UART1_IRQn);       /* 使能 UART1 发送空中断（非阻塞遥测后台发送） */
    NVIC_SetPriority(UART1_IRQn, 3);  /* UART1 优先级与 ADC 同级，低于电机控制中断 */
#endif
    __enable_irq();                  /* 开启总中断 */
}

/*******************************************************************************
 函数名称：    void UTimer_init(void)
 功能描述：    UTimer硬件初始化
 输入参数：    无
 输出参数：    无
 返 回 值：    无
 其它说明：
 修改日期      版本号          修改人            修改内容
 -----------------------------------------------------------------------------
 2015/11/5      V1.0           Howlet Li          创建
 *******************************************************************************/
void UTimer_init(void)
{
	//不用CH1
    TIM_TimerInitTypeDef TIM_InitStruct;
    TIM_TimerStrutInit(&TIM_InitStruct);
    TIM_InitStruct.Timer_CH0_WorkMode = TIMER_OPMode_CMP;  /* 设置Timer CH0 为比较模式 */
    TIM_InitStruct.Timer_CH0_CapMode = TIMER_CapMode_None;
    TIM_InitStruct.Timer_CH0Output = 0;                    /* 计数器回零时，比较模式输出极性控制 */
    TIM_InitStruct.Timer_CH1_WorkMode = TIMER_OPMode_CAP;  /* 设置Timer CH1 为比较模式 */
    TIM_InitStruct.Timer_CH1_CapMode = TIMER_CapMode_None;
    TIM_InitStruct.Timer_CH1Output = 0;                    /* 计数器回零时，比较模式输出极性控制 */
    TIM_InitStruct.Timer_TH = 2526;                       /* 设置计数器计数模值 96M/38K=2526.3*/
    TIM_InitStruct.Timer_CMP0 = 1263;                     /* 设置比较模式的CH0比较值 2526/2=1263,50%占空比*/
    TIM_InitStruct.Timer_CMP1 = 0;
    TIM_InitStruct.Timer_Filter0 = 0;                      /* 设置捕捉模式或编码器模式下对应通道的数字滤波值 */
    TIM_InitStruct.Timer_Filter1 = 0;
    TIM_InitStruct.Timer_ClockDiv = TIM_Clk_Div1;          /* 设置Timer模块数据分频系数 */
    TIM_InitStruct.Timer_IRQEna = Timer_IRQEna_None;       /* 不开 TIMER3 中断：旧版“会转”工程即如此，避免 38K ISR 干扰无刷换相；步进改由主循环轮询 TIMER3 CNT 驱动 */
    TIM_TimerInit(TIMER3, &TIM_InitStruct);
	  TIM_TimerCmd(TIMER3, ENABLE);                          /* Timer3 模块使能 */
	
		//不用CH0
	  TIM_TimerStrutInit(&TIM_InitStruct);
    TIM_InitStruct.Timer_CH0_WorkMode = TIMER_OPMode_CAP;  /* 设置Timer CH0 为捕获模式 */
    TIM_InitStruct.Timer_CH0_CapMode = TIMER_CapMode_None;
    TIM_InitStruct.Timer_CH0Output = 0;                    /* 计数器回零时，比较模式输出极性控制 */
    TIM_InitStruct.Timer_CH1_WorkMode = TIMER_OPMode_CMP;  /* 设置Timer CH1 为比较模式 */
    TIM_InitStruct.Timer_CH1_CapMode = TIMER_CapMode_None;
    TIM_InitStruct.Timer_CH1Output = 0;                    /* 计数器回零时，比较模式输出极性控制 */
    TIM_InitStruct.Timer_TH = 2526;                       /* 设置计数器计数模值 96M/38K=2526.3*/
    TIM_InitStruct.Timer_CMP0 = 0;                     /* 设置比较模式的CH0比较值 2526/2=1263,50%占空比*/
		//TIMERx->CMPT1 = TIM_TimerInitStruct->Timer_CMP1;
		//越大占空比越小，播料电机功率越低
		//Timer_CMP1 = 2400时霍尔输出17HZ 54%占空比方波。
		//Timer_CMP1 = 1200时霍尔输出180HZ 53%占空比方波。
		// 初始 CMP1=1790 ≈ duty 29%(≈目标100Hz初值)，加速 PI 收敛；PI 会在 ~20ms 内接管。
    TIM_InitStruct.Timer_CMP1 = (u32)FEED_TIMER_TH;   /* 初始占空比 0：未使能(g_fan_enable=0)时轮盘不转，避免上电瞬间误转；g_fan_enable=1 后 FeedControl_Tick 立即接管写入调速值 */
    TIM_InitStruct.Timer_Filter0 = 0;                      /* 设置捕捉模式或编码器模式下对应通道的数字滤波值 */
    TIM_InitStruct.Timer_Filter1 = 0;
    TIM_InitStruct.Timer_ClockDiv = TIM_Clk_Div1;          /* 设置Timer模块数据分频系数 */
    TIM_InitStruct.Timer_IRQEna = Timer_IRQEna_None;       /* 开启Timer模块过0中断 */
    TIM_TimerInit(TIMER2, &TIM_InitStruct);
	  TIM_TimerCmd(TIMER2, ENABLE);                          /* Timer2 模块使能 */

}
/*******************************************************************************
 函数名称：    void HALL_Perip_Init(void)
 功能描述：    HALL 外设初始化（参考 12.LKS32MC_05x_HALL 工程）
 其它说明：    仅使能 HALL 模块与数字滤波，关闭中断（本工程为轮询采样霍尔值）
 *******************************************************************************/
void HALL_Perip_Init(void)
{

  HALL_InitTypeDef HALL_InitStruct;

  HALL_StructInit(&HALL_InitStruct);
  HALL_InitStruct.HALL_Ena = ENABLE;             /* 模块使能 */
  HALL_InitStruct.ClockDivision = HALL_CLK_DIV1; /* 设置Hall模块时钟分频系数 */
	HALL_InitStruct.CountTH = 9600000;             /* Hall模块计数模值，计数超过模值会产生超时中断 */
  HALL_InitStruct.FilterLen = 32;                /* Hall信号数字滤波长度（减小滤波延迟） */
  HALL_InitStruct.Filter75_Ena = DISABLE;         /* Hall信号滤波方式：全1有效模式（更快响应） */
  HALL_InitStruct.Capture_IRQ_Ena = ENABLE;      /* 捕捉中断使能 */
  HALL_InitStruct.OverFlow_IRQ_Ena = ENABLE;     /* 超时中断使能 */
  HALL_InitStruct.softIE = ENABLE;              /* 软件中断使能 */
  HALL_Init(&HALL_InitStruct);
}

/*******************************************************************************
 函数名称：    void Clock_Init(void)
 功能描述：    时钟配置
 输入参数：    无
 输出参数：    无
 返 回 值：    无
 其它说明：
 修改日期      版本号          修改人            修改内容
 -----------------------------------------------------------------------------
 2015/11/5      V1.0           Howlet Li          创建

 -----------------------------------------------------------------------------
 修改日期      版本号          修改人            修改内容
 -----------------------------------------------------------------------------
 2021/4/17      V1.1           Howlet Li          增加延时函数，等待PLL稳定
 *******************************************************************************/
void Clock_Init(void)
{
    SYS_WR_PROTECT = 0x7a83;   /* 解除系统寄存器写保护 */
    SYS_AFE_REG5 |= BIT15;     /* BIT15:PLLPDN 开PLL */
    SoftDelay(100);            /* 延时100us, 等待PLL稳定 21.4.17*/
    SYS_CLK_CFG = 0x000001ff; /* BIT8:0: CLK_HS,1:PLL  | BIT[7:0]CLK_DIV  | 1ff对应96M时钟 */
}

/*******************************************************************************
 函数名称：    void SystemInit(void)
 功能描述：    硬件系统初始化，调用时钟初始化函数
 输入参数：    无
 输出参数：    无
 返 回 值：    无
 其它说明：
 修改日期      版本号          修改人            修改内容
 -----------------------------------------------------------------------------
 2016/3/14      V1.0           Howlet Li          创建
 *******************************************************************************/
void SystemInit(void)
{
    Clock_Init(); /* 时钟初始化 */
}

/*******************************************************************************
 函数名称：    void GPIO_init(void)
 功能描述：    GPIO硬件初始化
 输入参数：    无
 输出参数：    无
 返 回 值：    无
 其它说明：
 修改日期      版本号          修改人            修改内容
 -----------------------------------------------------------------------------
 2021/8/25      V1.0         HuangMG             创建
 *******************************************************************************/
void GPIO_init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct;
    GPIO_StructInit(&GPIO_InitStruct);
    /* MCPWM P1.4~P1.9 */
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7 | GPIO_Pin_8 | GPIO_Pin_9;
    GPIO_Init(GPIO1, &GPIO_InitStruct);
    GPIO_PinAFConfig(GPIO1, GPIO_PinSource_4, AF3_MCPWM);
    GPIO_PinAFConfig(GPIO1, GPIO_PinSource_5, AF3_MCPWM);
    GPIO_PinAFConfig(GPIO1, GPIO_PinSource_6, AF3_MCPWM);
    GPIO_PinAFConfig(GPIO1, GPIO_PinSource_7, AF3_MCPWM);
    GPIO_PinAFConfig(GPIO1, GPIO_PinSource_8, AF3_MCPWM);
    GPIO_PinAFConfig(GPIO1, GPIO_PinSource_9, AF3_MCPWM);

    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN;
    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_11|GPIO_Pin_12|GPIO_Pin_13;
		// GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_Init(GPIO0, &GPIO_InitStruct);

    GPIO_PinAFConfig(GPIO0, GPIO_PinSource_11, AF2_HALL);
    GPIO_PinAFConfig(GPIO0, GPIO_PinSource_12, AF2_HALL);
    GPIO_PinAFConfig(GPIO0, GPIO_PinSource_13, AF2_HALL);

		//P2.7低电平红色LED亮
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_7;
    GPIO_Init(GPIO2, &GPIO_InitStruct);


//P0.7：UART1_TXD（调试串口 TX，115200-8-N-1，替代 RTT 输出）,不用UART时作状态指示(默认低,异常拉高)
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStruct.GPIO_Pin  = GPIO_Pin_7;
    GPIO_Init(GPIO0, &GPIO_InitStruct);
    GPIO_ResetBits(GPIO0, GPIO_Pin_7);   /* 默认拉低：正常=低，无料/堵料才拉高 */
#if (UART_TELEMETRY_ENABLE == 1)
    GPIO_PinAFConfig(GPIO0, GPIO_PinSource_7, AF4_UART);  /* P0.7 -> UART1_TXD */
#endif
		
		//驱动38K 测料红外LED
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_2;
    GPIO_Init(GPIO1, &GPIO_InitStruct);
    GPIO_PinAFConfig(GPIO1, GPIO_PinSource_2, AF8_TIMER23);
		
		//驱动38K 播料电机
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_4;
    GPIO_Init(GPIO0, &GPIO_InitStruct);
    GPIO_PinAFConfig(GPIO0, GPIO_PinSource_4, AF8_TIMER23);

    /* P0.3 = ADC_CH7：外部运放输出经 1K 接入。必须设为模拟输入并关闭内部上拉，
       否则复位默认的内部弱上拉会把 CH7 拉到 VDD，造成"运放无输出但 CH7 有电压"的假象 */
    GPIO_StructInit(&GPIO_InitStruct);
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_ANA;   /* 模拟输入：禁数字输入缓冲、禁输出 */
    GPIO_InitStruct.GPIO_Pin  = GPIO_Pin_3;
    GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_NOPULL; /* 关闭内部上拉 */
    GPIO_Init(GPIO0, &GPIO_InitStruct);

    /* ---- P0.14：步进到位霍尔 HALL_IN2（输入）----
       按设计文档第八节 + stepper.h：P0.14 为步进归位到位霍尔输入（与 P0.15 构成双路限位，低有效）。
       复用 = AF0_GPIO（GPIO 输入）。采用内部上拉，使低有效霍尔的 idle 态稳定为高
       （若板载已有外部上拉，内拉仅作冗余，无冲突）。
       注：调试串口已迁回 P0.7/UART1（见上），P0.14 不再被 UART 占用，故归位霍尔可正常使用此脚。
       当前 StepperFSM 归位状态机（stepper.h 声明）尚未实现，此处仅完成引脚配置，供后续 FSM 读取电平。 */
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN;
    GPIO_InitStruct.GPIO_Pin  = GPIO_Pin_14;
    GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_Init(GPIO0, &GPIO_InitStruct);
    GPIO_PinAFConfig(GPIO0, GPIO_PinSource_14, AF0_GPIO);  /* P0.14 -> GPIO 输入(HALL_IN2, 正转到位, 低有效) */

    /* ---- P0.15：步进反转到位霍尔 HALL_IN3（输入，低有效）----
       与 P0.14 同为限位霍尔，到位低、默认高(外部上拉)；内拉作冗余。
       上电反转归位找 P0.15 低，外力移位亦据此重寻。 */
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN;
    GPIO_InitStruct.GPIO_Pin  = GPIO_Pin_15;
    GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_Init(GPIO0, &GPIO_InitStruct);
    GPIO_PinAFConfig(GPIO0, GPIO_PinSource_15, AF0_GPIO);  /* P0.15 -> GPIO 输入(HALL_IN3) */

//    /* MCPWM_BKIN1 */
//    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN;
//    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_14;
//    GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_NOPULL; /*GPIO上拉*/
//    GPIO_Init(GPIO0, &GPIO_InitStruct);
//    GPIO_PinAFConfig(GPIO0, GPIO_PinSource_14, AF3_MCPWM); //复用MCPWM_BKIN1，FALL1的IO触发引脚
}




/*******************************************************************************
 函数名称：    void Invers_GPIO(void)
 功能描述：    GPIO电平反转函数
 输入参数：    无
 输出参数：    无
 返 回 值：    无
 其它说明：
 修改日期      版本号          修改人            修改内容
 -----------------------------------------------------------------------------
 2022/4/14     V1.0          HuangMG            创建
 *******************************************************************************/
uint8_t Invers_GPIO(GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin) // GPIO电平翻转函数
{
    u16 reg;
    reg = GPIO_ReadOutputDataBit(GPIOx, GPIO_Pin); //读GPIO电平
    if (reg)
    {
        GPIO_ResetBits(GPIOx, GPIO_Pin);
        return 0;
    }
    else
    {
        GPIO_SetBits(GPIOx, GPIO_Pin);
        return 1;
    }
}





/*******************************************************************************
 函数名称：    void SoftDelay(u32 cnt)
 功能描述：    延时函数
 输入参数：    无
 输出参数：    无
 返 回 值：    无
 其它说明：
 修改日期      版本号          修改人            修改内容
 -----------------------------------------------------------------------------
 2017/11/5      V1.0           Howlet Li          创建
 *******************************************************************************/
void SoftDelay(u32 cnt)
{
    u32 t_cnt;

    for (t_cnt = 0; t_cnt < cnt; t_cnt++)
    {
        __nop();
    }
}

/*******************************************************************************
 函数名称：    void MCPWM_init(void)
 功能描述：    MCPWM_init硬件初始化
 输入参数：    无
 输出参数：    无
 返 回 值：    无
 其它说明：
 修改日期      版本号          修改人            修改内容
 -----------------------------------------------------------------------------
 2021/8/25      V1.0          HuangMG            创建
 *******************************************************************************/
void MCPWM_init(void)
{
    MCPWM_InitTypeDef MCPWM_InitStructure;

    MCPWM_StructInit(&MCPWM_InitStructure); /*初始化结构体变量*/

    MCPWM_InitStructure.CLK_DIV = 0;           /* MCPWM时钟分频设置 */
    MCPWM_InitStructure.MCLK_EN = ENABLE;      /* 模块时钟开启 */
    MCPWM_InitStructure.MCPWM_Cnt_EN = ENABLE; /* 主计数器开始计数使能开关 */
    MCPWM_InitStructure.MCPWM_WorkModeCH0 = CENTRAL_PWM_MODE;
    MCPWM_InitStructure.MCPWM_WorkModeCH1 = CENTRAL_PWM_MODE; /* 通道工作模式设置，中心对齐或边沿对齐 */
    MCPWM_InitStructure.MCPWM_WorkModeCH2 = CENTRAL_PWM_MODE;

    MCPWM_InitStructure.AUEN = TH00_AUEN | TH01_AUEN | TH10_AUEN | TH11_AUEN |
                               TH20_AUEN | TH21_AUEN | TMR0_AUEN | TMR1_AUEN |
                               TH_AUEN; //开启MCPWM_TH00~TH21、MCPWM_TMR0~TMR1、MCPWM_TH

    MCPWM_InitStructure.MCPWM_T0_UpdateEN = ENABLE;  /* MCPWM T0事件更新使能 */
    MCPWM_InitStructure.MCPWM_T1_UpdateEN = ENABLE;  /* MCPWM T1事件更新使能（同时开启，减小更新延迟） */
    MCPWM_InitStructure.T0_Update_INT_EN = DISABLE;   /* T0更新事件中斷使能 */

    MCPWM_InitStructure.MCPWM_PERIOD = PWM_PERIOD;               /* 计数周期设置 */
    MCPWM_InitStructure.TriggerPoint0 = (u16)(100 - PWM_PERIOD); /* MCPWM_TMR0 ADC触发事件T0 设置 */
    MCPWM_InitStructure.TriggerPoint1 = (u16)(800 - PWM_PERIOD); /* MCPWM_TMR1 ADC触发事件T1 设置 */
    MCPWM_InitStructure.DeadTimeCH0N = DEADTIME;                 /* CH0N死区时间设置　*/
    MCPWM_InitStructure.DeadTimeCH0P = DEADTIME;                 /* CH0P死区时间设置　*/
    MCPWM_InitStructure.DeadTimeCH1N = DEADTIME;
    MCPWM_InitStructure.DeadTimeCH1P = DEADTIME;
    MCPWM_InitStructure.DeadTimeCH2N = DEADTIME;
    MCPWM_InitStructure.DeadTimeCH2P = DEADTIME; /* 死区时间设置 */

#if (PRE_DRIVER_POLARITY == P_HIGH__N_LOW)           /* CHxP 高有效， CHxN低电平有效 */
    MCPWM_InitStructure.CH0N_Polarity_INV = ENABLE;  /* CH0N通道输出极性设置 | 正常输出或取反输出*/
    MCPWM_InitStructure.CH0P_Polarity_INV = DISABLE; /* CH0P通道输出极性设置 | 正常输出或取反输出 */
    MCPWM_InitStructure.CH1N_Polarity_INV = ENABLE;
    MCPWM_InitStructure.CH1P_Polarity_INV = DISABLE;
    MCPWM_InitStructure.CH2N_Polarity_INV = ENABLE;
    MCPWM_InitStructure.CH2P_Polarity_INV = DISABLE;

    MCPWM_InitStructure.Switch_CH0N_CH0P = DISABLE; /* 通道交换选择设置 | CH0P和CH0N是否选择信号交换 */
    MCPWM_InitStructure.Switch_CH1N_CH1P = DISABLE; /* 通道交换选择设置 */
    MCPWM_InitStructure.Switch_CH2N_CH2P = DISABLE; /* 通道交换选择设置 */

    /* 默认电平设置 默认电平输出不受MCPWM_IO01和MCPWM_IO23的 BIT0、BIT1、BIT8、BIT9、BIT6、BIT14
                                                     通道交换和极性控制的影响，直接控制通道输出 */
    MCPWM_InitStructure.CH0P_default_output = LOW_LEVEL;
    MCPWM_InitStructure.CH0N_default_output = HIGH_LEVEL;
    MCPWM_InitStructure.CH1P_default_output = LOW_LEVEL;  /* CH1P对应引脚在空闲状态输出低电平 */
    MCPWM_InitStructure.CH1N_default_output = HIGH_LEVEL; /* CH1N对应引脚在空闲状态输出高电平 */
    MCPWM_InitStructure.CH2P_default_output = LOW_LEVEL;
    MCPWM_InitStructure.CH2N_default_output = HIGH_LEVEL;
#else
#if (PRE_DRIVER_POLARITY == P_HIGH__N_HIGH) /* CHxP 高有效， CHxN高电平有效 */
    MCPWM_InitStructure.CH0N_Polarity_INV = DISABLE; /* CH0N通道输出极性设置 | 正常输出或取反输出*/
    MCPWM_InitStructure.CH0P_Polarity_INV = DISABLE; /* CH0P通道输出极性设置 | 正常输出或取反输出 */
    MCPWM_InitStructure.CH1N_Polarity_INV = DISABLE;
    MCPWM_InitStructure.CH1P_Polarity_INV = DISABLE;
    MCPWM_InitStructure.CH2N_Polarity_INV = DISABLE;
    MCPWM_InitStructure.CH2P_Polarity_INV = DISABLE;

    MCPWM_InitStructure.Switch_CH0N_CH0P = DISABLE; /* 通道交换选择设置 | CH0P和CH0N是否选择信号交换 */
    MCPWM_InitStructure.Switch_CH1N_CH1P = DISABLE; /* 通道交换选择设置 */
    MCPWM_InitStructure.Switch_CH2N_CH2P = DISABLE; /* 通道交换选择设置 */

    /* 默认电平设置 默认电平输出不受MCPWM_IO01和MCPWM_IO23的 BIT0、BIT1、BIT8、BIT9、BIT6、BIT14
                                                     通道交换和极性控制的影响，直接控制通道输出 */
    MCPWM_InitStructure.CH0P_default_output = LOW_LEVEL;
    MCPWM_InitStructure.CH0N_default_output = LOW_LEVEL;
    MCPWM_InitStructure.CH1P_default_output = LOW_LEVEL; /* CH1P对应引脚在空闲状态输出低电平 */
    MCPWM_InitStructure.CH1N_default_output = LOW_LEVEL; /* CH1N对应引脚在空闲状态输出高电平 */
    MCPWM_InitStructure.CH2P_default_output = LOW_LEVEL;
    MCPWM_InitStructure.CH2N_default_output = LOW_LEVEL;
#endif
#endif

    MCPWM_InitStructure.DebugMode_PWM_out = ENABLE; /* 在接上仿真器debug程序时，暂停MCU运行时，选择各PWM通道正常输出调制信号
                                                                 还是输出默认电平，保护功率器件 ENABLE:正常输出 DISABLE:输出默认电平*/
    MCPWM_InitStructure.GPIO_BKIN_Filter = 12;      /* 急停事件(来自IO口信号)数字滤波器时间设置 */
    MCPWM_InitStructure.CMP_BKIN_Filter = 12;       /* 急停事件(来自比较器信号)数字滤波器时间设置 */

    MCPWM_InitStructure.FAIL0_INT_EN = DISABLE;             /* FAIL0事件 中断使能或关闭 */
    MCPWM_InitStructure.FAIL0_INPUT_EN = DISABLE;           /* FAIL0通道急停功能打开或关闭 */
    MCPWM_InitStructure.FAIL0_Signal_Sel = FAIL_SEL_CMP;    /* FAIL0事件信号选择，比较器或IO口 */
    MCPWM_InitStructure.FAIL0_Polarity = HIGH_LEVEL_ACTIVE; /* FAIL0事件极性选择，高有效 */

    MCPWM_InitStructure.FAIL1_INT_EN = DISABLE;              /* FAIL1事件 中断使能或关闭 */
    MCPWM_InitStructure.FAIL1_INPUT_EN = DISABLE;            /* FAIL1通道急停功能打开或关闭 */
    MCPWM_InitStructure.FAIL1_Signal_Sel = FAIL_SEL_IO;     /* FAIL1事件信号选择，比较器或IO口 */
    MCPWM_InitStructure.FAIL1_Polarity = HIGH_LEVEL_ACTIVE; /* FAIL1事件极性选择，高有效或低有效 */

#ifdef MCPWM_SWAP_FUNCTION  /* 使用054D, 057D内置预驱芯片需要打开PWM交换功能 */
    MCPWM_PRT = 0x0000DEAD; /*输入密码，解锁写保护*/
    MCPWM_SWAP = 0x67;
    MCPWM_PRT = 0x0000CAFE;
#endif
    MCPWM_Init(&MCPWM_InitStructure);

    //DebugPWM_OutputFunction(); //输出25%占空比
}




/*******************************************************************************
 函数名称：    void DebugPWM_OutputFunction(void)
 功能描述：    六种导通序列循环，每2秒切换一次
               顺序：U?V → U?W → V?W → V?U → W?U → W?V → 循环
               占空比固定为15%（上管 PWM，U 相）
               使用软件延时（for-nop）实现2秒等待
               初始状态：三个下管全通，上管全断
 修改日期      版本号          修改人            修改内容
 -----------------------------------------------------------------------------
 2026/07/16    V2.1           User              初始三下管全通
 *******************************************************************************/

/* 软件延时（双重 for + __NOP）。实测 12000 外循环在 96MHz 下约 3.88s，
   因此按 2s/3.88s 比例缩放：12000 * 2/3.88 ≈ 6186，使每步约 2s。
   若更换编译优化等级或时钟，请按实测值重新微调本常数。 */
#define DELAY_OUTER_LOOP  6186    // 外循环次数（每步约 2s）
#define DELAY_INNER_LOOP  1000    // 内循环次数
/* 无刷每次启动前的短时再预充(下管全通)：约 100ms，保证上电后等待很久才到正转命令时自举电容仍有电 */
#define BLDC_START_PREOUTER  320
#define BLDC_START_PREINNER  1000

/* 通道<->相位映射（依据芯片资源图：CH0=U, CH1=V, CH2=W；如实际板卡 V/W 反接可调换） */
#define CH_U  0
#define CH_V  1
#define CH_W  2

/* 强制某相：上管关断、下管恒通 */
#define FORCE_LOWER_ON(io, ch)   do { \
    (io) |=  ((ch==2)?(1<<3):(ch==1?(1<<11):(1<<3))); \
    (io) |=  ((ch==2)?(1<<2):(ch==1?(1<<10):(1<<2))); \
    (io) &= ~((ch==2)?(1<<5):(ch==1?(1<<13):(1<<5))); \
    (io) |=  ((ch==2)?(1<<4):(ch==1?(1<<12):(1<<4))); \
} while (0)

/* 强制某相：上管、下管全断 */
#define FORCE_ALL_OFF(io, ch)    do { \
    (io) |=  ((ch==2)?(1<<3):(ch==1?(1<<11):(1<<3))); \
    (io) |=  ((ch==2)?(1<<2):(ch==1?(1<<10):(1<<2))); \
    (io) &= ~((ch==2)?(1<<5):(ch==1?(1<<13):(1<<5))); \
    (io) &= ~((ch==2)?(1<<4):(ch==1?(1<<12):(1<<4))); \
} while (0)

/* 清除某相全部强制位（恢复为内部计数器产生的 PWM） */
#define CLEAR_FORCE(io, ch)      do { \
    (io) &= ~((ch==2)?((1<<3)|(1<<2)|(1<<5)|(1<<4)) \
              :(ch==1)?((1<<11)|(1<<10)|(1<<13)|(1<<12)) \
                     :((1<<3)|(1<<2)|(1<<5)|(1<<4))); \
} while (0)

/* ===================== 调试数据经 UART1(P0.7 TXD) 输出（彻底弃用 RTT） =====================
   RTT 在 Keil+M0 下曾用 PRIMASK 全局关中断屏蔽 HALL 换相中断、导致无刷锁死，故彻底弃用。
   改用 UART1 非阻塞发送 + 环形缓冲区 + 发送空中断：主循环只把字节丢进缓冲区立即返回，
   由 UART1 中断在后台逐字节发送；发送期间不关中断，对电机控制零干扰。
   波特率 115200，8-N-1；仅用 TX，不使能接收中断。
   以下整个 UART 遥测模块由 UART_TELEMETRY_ENABLE 闸控：关闭后不占用代码/数据，也不初始化外设。 */
#if (UART_TELEMETRY_ENABLE == 1)

#define UART1_TX_BUF_SIZE 256   /* 环形发送缓冲区大小(须为 2 的幂，便于掩码取模) */

/* 非阻塞发送缓冲区：被 hardware_init.c 主循环写入，被 interrupt.c UART1_IRQHandler 读出。
   注意：UART1_TX_BUF_SIZE 必须为 2 的幂。 */
volatile u8  g_uart1_tx_buf[UART1_TX_BUF_SIZE];
volatile u16 g_uart1_tx_wr   = 0;   /* 写索引(主循环写入) */
volatile u16 g_uart1_tx_rd   = 0;   /* 读索引(中断读出) */
volatile u8  g_uart1_tx_busy = 0;   /* 1=发送进行中(中断仍可能为忙) */

/* UART1 初始化（P0.7 引脚复用已在 GPIO_init 中配置为 UART1_TXD，见上） */
static void UART1_TelemetryInit(void)
{
    UART_InitTypeDef UART_InitStruct;
    UART_StructInit(&UART_InitStruct);
    UART_InitStruct.BaudRate   = 115200;
    UART_InitStruct.WordLength = UART_WORDLENGTH_8b;
    UART_InitStruct.StopBits   = UART_STOPBITS_1b;
    UART_InitStruct.FirstSend  = UART_FIRSTSEND_LSB;
    UART_InitStruct.ParityMode = UART_Parity_NO;
    UART_InitStruct.IRQEna     = UART_IRQEna_SendBuffEmpty;  /* 使能发送缓冲空中断 */
    UART_Init(UART1, &UART_InitStruct);
}

/* 非阻塞发送一个字节：写入环形缓冲区，由 UART1 发送空中断在后台发送。
   缓冲区满时直接丢弃该字节，避免阻塞主循环 38K 节拍。
   短暂关全局中断以防止 UART1 发送中断在写索引/启动发送时抢占造成竞态。 */
static void UART1_SendByte(u8 b)
{
    u16 wr, next_wr;

    __disable_irq();

    wr = g_uart1_tx_wr;
    next_wr = (u16)((wr + 1u) & (UART1_TX_BUF_SIZE - 1u));

    if (next_wr == g_uart1_tx_rd)
    {
        /* 缓冲区满：直接丢弃，不能阻塞电机控制 */
        __enable_irq();
        return;
    }

    g_uart1_tx_buf[wr] = b;
    g_uart1_tx_wr = next_wr;

    if (g_uart1_tx_busy == 0)
    {
        /* 当前无发送在进行：尝试启动。先检查发送缓冲是否已空，
           空则直接写第一个字节，然后开中断让后续字节由 ISR 发送。 */
        if (UART1->STT & BIT0)
        {
            UART_SendData(UART1, (u32)g_uart1_tx_buf[g_uart1_tx_rd]);
            g_uart1_tx_rd = (u16)((g_uart1_tx_rd + 1u) & (UART1_TX_BUF_SIZE - 1u));
        }
        g_uart1_tx_busy = 1;
        UART1->IE |= UART_IRQEna_SendBuffEmpty;   /* 使能发送空中断 */
    }

    __enable_irq();
}

/* 有符号 32 位打印(供遥测) */
static void UART1_SendS32(s32 v)
{
    if (v < 0) { UART1_SendStr("-"); v = -v; }
    else       { UART1_SendStr(" "); }
    UART1_SendU32((u32)v);
}

/* 发送以 '\0' 结尾的字符串 */
static void UART1_SendStr(const char *s)
{
    if (s == 0) return;
    while (*s != '\0')
    {
        UART1_SendByte((u8)(*s));
        s++;
    }
}

/* 发送无符号十进制（按位拆分，避免依赖标准库 printf） */
static void UART1_SendU32(u32 v)
{
    char buf[12];
    int  i = 0, k;
    if (v == 0)
    {
        UART1_SendByte((u8)'0');
        return;
    }
    while (v > 0)
    {
        buf[i++] = (char)('0' + (v % 10u));
        v /= 10u;
    }
    for (k = i - 1; k >= 0; k--)
    {
        UART1_SendByte((u8)buf[k]);
    }
}

/* 发送电流（传入毫安，显示 A=整数.两位小数） */
static void UART1_SendCurrentMA(s32 ma)
{
    s32 whole = ma / 1000;
    s32 frac  = (ma < 0 ? -ma : ma) % 1000;
    s32 dec   = frac / 10;          /* 两位小数（取十位） */
    if (whole < 0)
    {
        UART1_SendByte((u8)'-');
        whole = -whole;
    }
    UART1_SendU32((u32)whole);
    UART1_SendByte((u8)'.');
    UART1_SendByte((u8)('0' + (dec / 10)));
    UART1_SendByte((u8)('0' + (dec % 10)));
}

/* 每个状态最后时刻，输出状态序号与采样到的霍尔值（bit2/1/0 = HALL_IN2/1/0）。
   注意：此诊断函数当前未被调用；保留为 UART 版本，便于需要时启用。 */
static void UART_ReportHall(u8 step, u8 hall)
{
    u8 raw = (u8)HALL_GetCaptureValue();   /* RAW_DATA：实时原始引脚电平（诊断用） */
    UART1_SendStr("Step ");
    UART1_SendU32((u32)step);
    UART1_SendStr(" FLT=");
    UART1_SendU32((u32)((hall >> 2) & 1));
    UART1_SendU32((u32)((hall >> 1) & 1));
    UART1_SendU32((u32)(hall & 1));
    UART1_SendStr("(");
    UART1_SendU32((u32)(hall & 7));
    UART1_SendStr(") RAW=");
    UART1_SendU32((u32)((raw >> 2) & 1));
    UART1_SendU32((u32)((raw >> 1) & 1));
    UART1_SendU32((u32)(raw & 1));
    UART1_SendStr("(");
    UART1_SendU32((u32)(raw & 7));
    UART1_SendStr(")\r\n");
}

/* ===================== 遥测上报（UART1，约每 1 秒一次） =====================
   精简输出（单行）：
   - P1.1 输入电平（0/1）
   - P2.3 / P2.4 / P2.5 高电平宽度（单位：微秒 us，整数，由硬件双沿捕获直接测得）
   - 两路 ADC 电流（安培，2 位小数）：
       I_BLDC：无刷相电流（OPA0 差分，检流电阻 25mΩ，片内 OPA 增益 17.24）
       I_STEP：步进相电流（P0.3/CH7，外部运放已放大 100x，检流电阻 25mΩ）
   说明：无有效测量时电流字段显示 0.00。 */
static void Debug_ReportTelemetry(void)
{
    u32 h23 = 0, h24 = 0, h25 = 0;   /* 高电平宽度(us) */
    s32 iBldc = 0, iStep = 0;

    /* P2.3/2.4/2.5 高电平宽度（us）：读 100ms 去抖稳定后的 *_us_f（不直接读硬件未去抖值）；
       无有效测量时显示 0（对应 us 显示 0） */
    h23 = g_p23_us_f;
    h24 = g_p24_us_f;
    h25 = g_p25_us_f;

    /* 电流由 SysSupervisor_Tick 每 tick 刷新到全局(含垃圾阈值处理)，此处直接采用 */
    iBldc = g_iBldc_mA;
    iStep = g_iStep_mA;

    /* 精简单行输出：P1.1 电平 + 三路 PWM 高电平宽度 + 两路电流；
       经 UART1(P0.7 TXD) 阻塞发送（不关中断，对换相零干扰） */
    UART1_SendStr("P1.1=");
    UART1_SendU32((GPIO_ReadInputDataBit(GPIO1, GPIO_Pin_1) == Bit_SET) ? 1u : 0u);
    UART1_SendStr(" | P2.3=");
    UART1_SendU32(h23);
    UART1_SendStr("us P2.4=");
    UART1_SendU32(h24);
    UART1_SendStr("us P2.5=");
    UART1_SendU32(h25);
    UART1_SendStr("us | I_BLDC=");
    UART1_SendCurrentMA(iBldc);
    UART1_SendStr("A I_STEP=");
    UART1_SendCurrentMA(iStep);
    UART1_SendStr("A");

    /* 无刷转速：g_hall_edge_cnt = 本窗口(≈1秒)内 HALL 换相次数；用户规格：6 个霍尔状态=转 1 圈。
       故 圈/秒 = edges/6，RPM = edges*60/6 = edges*10（窗口恰为 1 秒）。读取后清零（HALL 中断仍累加）。 */
    {
        u16 edges = g_hall_edge_cnt;
        g_hall_edge_cnt = 0;                       /* 主循环读取后清零；16 位读写原子，无需关中断 */
        u32 rpm    = (u32)edges * 10u;             /* 转/分（整数） */
        u32 rps100 = (u32)edges * 100u / 6u;       /* 圈/秒，×100 定点（两位小数） */
        UART1_SendStr(" | BLDC_HALL_n=");
        UART1_SendU32((u32)edges);
        UART1_SendStr(" BLDC_RPS=");
        UART1_SendU32(rps100 / 100u);
        UART1_SendByte((u8)'.');
        UART1_SendByte((u8)('0' + ((rps100 / 10u) % 10u)));
        UART1_SendByte((u8)('0' + (rps100 % 10u)));
        UART1_SendStr(" BLDC_RPM=");
        UART1_SendU32(rpm);        
				UART1_SendStr(" SKIP=");
        UART1_SendU32((u32)g_hall_skip_cnt);
        g_hall_skip_cnt = 0;                   /* 输出后清零，累计下次 */
    }
    UART1_SendStr("\r\n");
}

#endif  /* UART_TELEMETRY_ENABLE == 1 */


/* ===================== 系统监管：无料/堵转锁存 + 红绿灯 + 电机动作兜底 =====================
   每 38K tick 由主循环首步调用。优先级：无料(锁存) > 堵转(锁存) > FAULT(红灯闪烁,关断信号即清) > 正常(绿灯)。
   说明：旧红绿灯控制(初始化常亮绿、HALL bit0 映射红)已删除，改由本监管每 tick 统一控制。 */

/* 刷新两路电流(mA)到全局，供堵转判定与遥测共用；含垃圾采样阈值处理（与旧遥测一致）。 */
static void Sys_UpdateCurrents(void)
{
    u32 code = 0; u8 have = 0;
    s32 a = 0, b = 0;
    have = PWM_ADC_GetDiff(&code);
    if (have)
    {
        a = PWM_ADC_DiffToCurrent_mA((s32)code) * 2;
        if (a > 40000 || a < -40000) a = 0;
    }
    have = PWM_ADC_GetCh7(&code);
    if (have)
    {
        b = PWM_ADC_Ch7ToCurrent_mA((s32)code) * 2;
        if (b > 10000 || b < -10000) b = 0;
    }
    g_iBldc_mA = a;
    g_iStep_mA = b;
}

static void SysSupervisor_Tick(void)
{
    u8 p11;

    /* 三路 PWM 输入统一 100ms 去抖更新（任何代码之后只读 *_state / *_us_f，不直接读硬件） */
    CmdDebounce_Update();

    /* NORMAL 态：把 P2.3 引脚的高电平时间对应的状态同步给步进方向命令 g_cmd；
       锁存态不在此同步，g_cmd 保持锁存时强制值(不被 P2.3 带跑) */
    if (g_sys_mode == SYS_NORMAL)
        g_cmd = g_p23_state;

    /* --- 1) 无料判定：P23 开启(FWD)期间，P1.1 连续 3s 为低 -> 锁存（优先级最高） ---
       仅在 P23=FWD(开启) 期间计无料时间；P23=REV(关断) 时清零，
       确保每次开启后 P11 无料也要重新低满 3s 才锁死，风机至少能转 3s。 */
    p11 = (GPIO_ReadInputDataBit(GPIO1, GPIO_Pin_1) == Bit_SET) ? 1u : 0u;
    if (g_p23_state == FSM_CMD_FWD)
    {
        if (p11 == 0u)
        {
            if (g_nomaterial_tick < 0xFFFFFFFFu) g_nomaterial_tick++;
        }
        else
            g_nomaterial_tick = 0;
    }
    else
        g_nomaterial_tick = 0;   /* P23 关断期间清零，下次开启重新计 3s */

    Sys_UpdateCurrents();   /* 每 tick 刷新电流(供堵转判定 + 遥测)；锁存态下读数归零亦无妨 */

    if (g_sys_mode == SYS_NORMAL)
    {
        if (g_nomaterial_tick >= SYS_NOMAT_3S_TICKS)
        {
            /* 进入无料：红灯常亮 + 步进反转归位锁定 + 无刷/轮盘停；锁存到断电。P2.3 仍由 CmdDebounce 去抖，
               仅用于"关断(REV)清除错误"，锁存期 g_cmd 保持此强制反转(不被 P2.3 带跑) */
            g_sys_mode = SYS_NOMATERIAL;
            g_cmd = FSM_CMD_REV;                /* 强制反转方向 */
            g_fsm = FSM_REV_SEEK;               /* 走反转寻位->到位锁定；5s超时则进 FAULT=锁定不继续 */
            Stepper_SetDir(STEPPER_DIR_REV);
            fsm_reset_seek();
            g_fan_enable = 0;
#if (UART_TELEMETRY_ENABLE == 1)
            UART1_SendStr("NOMAT latched\r\n");
#endif
        }
    }

    /* --- 2) 堵转判定：电流瞬时超限(不去抖)；仅 SYS_NORMAL 可进入 --- */
    if (g_sys_mode == SYS_NORMAL)
    {
        if ((g_iBldc_mA > 24000) || (g_iBldc_mA < -24000) ||
            (g_iStep_mA  >  2000) || (g_iStep_mA  < -2000))
        {
            g_sys_mode = SYS_STALL;
            Stepper_AllOff();                   /* 步进直接断电不动作 */
#if (UART_TELEMETRY_ENABLE == 1)
            UART1_SendStr("STALL latched\r\n");
#endif
        }
    }

    /* --- 3) 锁存态电机动作兜底（每 tick，防被其它逻辑重启） --- */
    if (g_sys_mode == SYS_NOMATERIAL)
    {
        g_bldc_inhibit  = 1;   /* 无刷风机关闭(三相高阻) */
        g_wheel_inhibit = 1;   /* 38K 轮盘停(优先于 P2.5) */
        /* 步进由 FSM 走反转归位->锁定，不在此停 */
    }
    else if (g_sys_mode == SYS_STALL)
    {
        g_bldc_inhibit  = 1;
        g_wheel_inhibit = 1;
        /* 步进断电不动作：由主循环 Stepper_AllOff() + 门控 Stepper_Tick 保证 */
    }
    else
    {
        g_bldc_inhibit  = 0;
        g_wheel_inhibit = 0;
    }

    /* --- 3.5) 错误清除：P2.3 引脚的高电平时间对应的状态为 REV(关断, 高电平时间<=1700us, 含无信号) 即清所有错误 ---
       锁存时电机已自关/反转归位，故清除只解除锁存，无需重复关电机/反转复位；
       g_cmd 会在下一 NORMAL tick 同步为 g_p23_state(REV)，FSM 自然走反转/不转。用户确认"立刻清掉无问题"。
       FAULT 的清除已由 FSM_FAULT 分支统一处理：收到关断信号即清、重新寻位跑(步进5s超时闸，不会一直转)。 */
    if (g_p23_state == FSM_CMD_REV)
    {
        if ((g_sys_mode == SYS_NOMATERIAL) || (g_sys_mode == SYS_STALL))
        {
            g_sys_mode      = SYS_NORMAL;
            g_bldc_inhibit  = 0;
            g_wheel_inhibit = 0;
        }
    }

    /* --- 4) 红绿灯（每 tick 统一控制，旧映射已删） --- */
    g_blink_tick++;
    if (g_blink_tick >= SYS_BLINK_HALF_TICKS) { g_blink_tick = 0; g_red_blink_state ^= 1u; }

    if (g_sys_mode == SYS_NOMATERIAL)
    {
        GPIO_ResetBits(GPIO2, GPIO_Pin_7);   /* 红灯常亮 */
        GPIO_SetBits(GPIO0, GPIO_Pin_2);     /* 绿灯灭 */
    }
    else if (g_sys_mode == SYS_STALL)
    {
        if (g_red_blink_state) GPIO_ResetBits(GPIO2, GPIO_Pin_7);
        else                   GPIO_SetBits(GPIO2, GPIO_Pin_7);
        GPIO_SetBits(GPIO0, GPIO_Pin_2);     /* 绿灯灭 */
    }
    else if (g_fsm == FSM_FAULT)
    {
        if (g_red_blink_state) GPIO_ResetBits(GPIO2, GPIO_Pin_7);
        else                   GPIO_SetBits(GPIO2, GPIO_Pin_7);
        GPIO_SetBits(GPIO0, GPIO_Pin_2);     /* 绿灯灭 */
    }
    else
    {
        GPIO_SetBits(GPIO2, GPIO_Pin_7);     /* 红灯灭 */
        GPIO_ResetBits(GPIO0, GPIO_Pin_2);   /* 绿灯亮 */
    }

#if (UART_TELEMETRY_ENABLE == 1)
    /* 宏开启：P0.7 作 UART1 TX，不由软件控制 GPIO 电平，避免与串口发送冲突 */
#else
    /* 宏关闭：P0.7 作状态指示 —— 无料(经 3s 滤波)或堵料(电流超限)拉高，正常拉低。
       FAULT(寻位超时)不拉高(走 g_fsm，g_sys_mode 仍为 NORMAL)。 */
    if (g_sys_mode != SYS_NORMAL)
        GPIO_SetBits(GPIO0, GPIO_Pin_7);     /* 无料/堵料 -> 拉高 */
    else
        GPIO_ResetBits(GPIO0, GPIO_Pin_7);   /* 正常 -> 拉低 */
#endif
}

void DebugPWM_OutputFunction(void)
{
    uint32_t th = PWM_PERIOD;                      // 1600
    int16_t cmp = (int16_t)(DUTY * th);           // 占空比 15%

#if (UART_TELEMETRY_ENABLE == 1)
    UART1_TelemetryInit();    /* 初始化 UART1(P0.7 TXD)，115200-8-N-1，替代 RTT 输出调试数据 */
#endif

    volatile uint32_t i, j;   // volatile 防止循环被优化

    /* ==================== 初始配置：三个下管全通，上管全断 ==================== */
//    MCPWM_PRT = 0x0000DEAD;
//    /* 先清除三个通道的全部强制位 */
//    CLEAR_FORCE(MCPWM_IO01, CH_U);
//    CLEAR_FORCE(MCPWM_IO01, CH_V);
//    CLEAR_FORCE(MCPWM_IO23, CH_W);
//    /* U/V/W 三相下管恒通、上管关断 */
//    FORCE_LOWER_ON(MCPWM_IO01, CH_U);
//    FORCE_LOWER_ON(MCPWM_IO01, CH_V);
//    FORCE_LOWER_ON(MCPWM_IO23, CH_W);
//    /* 清零所有比较值（强制模式已覆盖，清零更稳妥） */
//    MCPWM_TH00 = 0; MCPWM_TH01 = 0;
//    MCPWM_TH10 = 0; MCPWM_TH11 = 0;
//    MCPWM_TH20 = 0; MCPWM_TH21 = 0;
//    MCPWM_UPDATE = (1<<0)|(1<<1)|(1<<2)|(1<<3)|(1<<4)|(1<<5);
//    MCPWM_PRT = 0x0000CAFE;
//    PWMOutputs(ENABLE);
//    /* ---------- 等待 2 秒（让下管先导通给自举电容充电，下管导通时间完全受这个控制） ---------- */
//    for (i = 0; i < DELAY_OUTER_LOOP; i++) {
//        for (j = 0; j < DELAY_INNER_LOOP; j++) {
//            __NOP();
//					j++;
//        }
//    }
    /* ---------- 依据 MOTOR_DIR 重建霍尔查找表（必须在换相前完成） ---------- */
    BuildHallTables();

    /* ---------- 上电不启动无刷：保持三相高阻，等待风门正转到位门控(g_fan_enable) ----------
       仅做硬件预充(下管全通已在前完成)，不踢、不转；oldhall 保留 0xFF(interrupt.c 初值)，
       待 Bldc_Start 首次上升沿时再建立霍尔基准。彻底改掉原"上电即常转"行为。 */
    PWMOutputs(DISABLE);
    g_bldc_running = 0;

    /* ---------- 主循环：步进走步 + 遥测上报（无刷换相由 HALL 中断完成） ----------
       时间基准改用 TIMER3 自由运行的 38K 计数（CNT 每 2526 计数为一个 38K 周期），
       不再依赖 TIMER3 过零中断——旧版“会转”工程即不开该中断，避免 38K ISR 干扰无刷换相。
       主循环轮询 TIMER3 CNT，按累计 38K 周期数驱动步进（catch-up 不丢步）。 */
    {
        #define TIMER3_TH_LOCAL  2526u
        u16 step_last_cnt = (u16)TIM_Timer_GetCount(TIMER3);
        u32 cnt_accum    = 0;   /* 累计 TIMER3 计数(每满一个 TH = 1 个 38K tick) */
        u32 report_accum = 0;   /* 遥测计时累计(38K 周期数) */

        for (;;)
        {
            u16 cnt = (u16)TIM_Timer_GetCount(TIMER3);
            u32 diff;
            if (cnt >= step_last_cnt) diff = (u32)(cnt - step_last_cnt);
            else                      diff = (u32)(cnt + TIMER3_TH_LOCAL - step_last_cnt);
            step_last_cnt = cnt;
            cnt_accum += diff;

            /* 防突发：万一主循环某次被长时间阻塞(积压很多计数)，最多只补 1 个 38K tick，
               不把积压的步一次性倾泻给电机(否则步进会瞬间连跳多步 -> 震动+发热)。 */
            if (cnt_accum >= TIMER3_TH_LOCAL)
            {
                cnt_accum -= TIMER3_TH_LOCAL;
                if (cnt_accum >= TIMER3_TH_LOCAL) cnt_accum = 0;   /* 丢弃更早的积压，只保留相位 */

                /* 步进：每个 38K tick 调用一次 Stepper_Tick()，其内部按 STEPPER_DIV 分频走步。
                   注意：这里绝不能再按 STEPPER_DIV 预分频后调用(否则 = STEPPER_DIV^2 双重分频，速度慢 STEPPER_DIV 倍)。 */
                SysSupervisor_Tick(); /* 系统监管：无料/堵转锁存 + 红绿灯 + 电机动作兜底(须最先调用) */
                StepperFSM_Tick();   /* 步进归位状态机：先据 P2.3/霍尔决定方向 + 风机门控 */
                if (g_sys_mode == SYS_STALL) Stepper_AllOff();  /* 堵转：步进直接断电不动作(每 tick 覆盖 FSM) */
                Bldc_Update();       /* 无刷使能门控：风门正转到位(g_fan_enable=1)才转，否则三相高阻 */
                if (g_sys_mode != SYS_STALL) Stepper_Tick();    /* 堵转时不走步；其余态按方向走步/斩波 */

                /* 38K 周期任务（P1.0 频率轮询 + 两路 ADC 交替采样 PWM_ADC_38KStep）：
                   原由 TIMER3 过零中断驱动，但该中断为不干扰无刷换相已在 UTimer_init 关闭，
                   故改由主循环此 38K 节拍调用（与 Stepper_Tick 同级），功能等价且对换相零干扰。 */
                PWM_HighLevel_38K_Exec();
                FeedControl_Tick();    /* 播料电机速度闭环 PI（内部每 ~20ms 节流执行一次） */

                report_accum++;
#if (UART_TELEMETRY_ENABLE == 1)
                if (report_accum >= 38000u)   /* 约每 38000 个 38K 周期(≈1 秒)上报一次遥测；
                                                经 UART1(P0.7 TXD) 阻塞发送，不关中断，对换相零干扰。 */
                {
                    report_accum = 0;
                    Debug_ReportTelemetry();
                }
#else
                (void)report_accum;           /* 串口遥测关闭：不做 UART 打印 */
#endif
            }
        }
        #undef TIMER3_TH_LOCAL
    }
}


/*******************************************************************************
 函数名称：    void HALL_ApplyCommutation(uint8_t hall)
 功能描述：    根据霍尔值执行 6 步换相（由 HALL_IRQHandler 调用）
 说明：        hall_to_step 始终为正转映射(方向无关)，switch 内 step0~5 的物理相通电逻辑
               保持不变；正反转区别仅在于超前方向：正转 step+COMM_ADVANCE，反转 step-COMM_ADVANCE。
               例：COMM_ADVANCE=1 时，反转读到霍尔6 → 输出霍尔7的驱动(Step4)。
 霍尔→步骤映射（实测，MOTOR_DIR=0）：
    Hall=4 (100) → Step0: U+PWM, V下管恒通, W全断 (u-v)
    Hall=0 (000) → Step1: U+PWM, W下管恒通, V全断 (u-w)
    Hall=1 (001) → Step2: V+PWM, W下管恒通, U全断 (v-w)
    Hall=3 (011) → Step3: V+PWM, U下管恒通, W全断 (v-u)
    Hall=7 (111) → Step4: W+PWM, U下管恒通, V全断 (w-u)
    Hall=6 (110) → Step5: W+PWM, V下管恒通, U全断 (w-v)
*******************************************************************************/
/* ---------- 霍尔查找表（由 BuildHallTables() 依据 SEQ 在运行时自动生成，唯一真源为上方 SEQ）---------- */
uint8_t hall_to_step[8];     /* 霍尔→步索引(0~5)，0xFF=无效；供本文件 HALL_ApplyCommutation 使用 */
uint8_t NEXT_MAP[8][3];      /* 某霍尔的后续1/2/3步；供 interrupt.c 的 HALL 合法性校验使用 */

/*******************************************************************************
 函数名称：    void BuildHallTables(void)
 功能描述：    依据 MOTOR_DIR 选定的序列 SEQ，自动构建 hall_to_step[8] 与 NEXT_MAP[8][3]。
               hall_to_step 与 NEXT_MAP 同源(SEQ)，消除两表重复维护；
               切换转向只需改 MOTOR_DIR，无需手工同步 NEXT_MAP。
 说明：        NEXT_MAP[s][0]/[1]/[2] 分别为当前霍尔 s 的后续第1/2/3步霍尔值；
               其中第3步恰为相反态(按位取反)，HALL 中断里故意只放行 [0]/[1]、不放行 [2]。
*******************************************************************************/
void BuildHallTables(void)
{
    uint8_t i, s;

    for (i = 0; i < 8; i++)
    {
        hall_to_step[i] = 0xFF;
        NEXT_MAP[i][0] = NEXT_MAP[i][1] = NEXT_MAP[i][2] = 0;
    }
    /* hall_to_step 始终用正转映射(方向无关)：反转向量的超前由 HALL_ApplyCommutation 对
       COMM_ADVANCE 取负实现，故无需为反转单独建表。 */
    for (i = 0; i < 6; i++)
    {
        s = SEQ_FWD[i];
        hall_to_step[s] = i;                       /* 正转：霍尔→步索引(0~5) */
    }
    /* NEXT_MAP 用"当前方向"序列生成，保证合法性校验(防互补振荡/漏步)随转向正确 */
    for (i = 0; i < 6; i++)
    {
        s = SEQ[i];
        NEXT_MAP[s][0] = SEQ[(i + 1) % 6];         /* 后续第1步 */
        NEXT_MAP[s][1] = SEQ[(i + 2) % 6];         /* 后续第2步(漏1步容错) */
        NEXT_MAP[s][2] = SEQ[(i + 3) % 6];         /* 后续第3步(相反态，中断不放行) */
    }
}

void HALL_ApplyCommutation(uint8_t hall)
{
    uint8_t step;
    int16_t cmp;

    step = hall_to_step[hall & 0x07];
    if (step == 0xFF) return;               /* 无效霍尔值，不换相 */
#if (MOTOR_DIR == 0)
    step = (step + COMM_ADVANCE) % 6;       /* 正转：沿转向超前 COMM_ADVANCE 步 */
#else
    step = (step - COMM_ADVANCE + 6) % 6;   /* 反转：超前方向取反(沿反转向超前) */
#endif

    /* 占空比：DUTY 为期望的"真实"占空比(0 ~ 约0.94)，含死区补偿。
       中心对齐互补模式真实占空比公式(手册 12.1.4.1)：duty_real = (2*cmp - DEADTIME)/(2*PWM_PERIOD)
       反推使 duty_real == DUTY：cmp = DUTY*PWM_PERIOD + DEADTIME/2
         (开上管那条边只扣一次死区 Tdead1=DEADTIME，故补 DEADTIME/2)
       cmp 必须 < PWM_PERIOD，故 DUTY 上限约 (PWM_PERIOD-DEADTIME/2)/PWM_PERIOD ≈ 94%(受死区限制到不了100%)。 */
    s32 cmp32 = (s32)(DUTY * PWM_PERIOD) + (DEADTIME / 2);
    if (cmp32 > PWM_PERIOD) cmp32 = PWM_PERIOD;   /* 钳位，避免 cmp 超过周期上限导致占空比反相 */
    cmp = (int16_t)cmp32;

    MCPWM_PRT = 0x0000DEAD;
    CLEAR_FORCE(MCPWM_IO01, CH_U);
    CLEAR_FORCE(MCPWM_IO01, CH_V);
    CLEAR_FORCE(MCPWM_IO23, CH_W);

    switch (step)
    {
        case 0: /* Step0: U+PWM, V下管恒通, W全断 (Hall=4 100: u-v) */
            MCPWM_TH00 = -cmp; MCPWM_TH01 = cmp;
            FORCE_LOWER_ON(MCPWM_IO01, CH_V);
            FORCE_ALL_OFF(MCPWM_IO23, CH_W);
            break;

        case 1: /* Step1: U+PWM, W下管恒通, V全断 (Hall=0 000: u-w) */
            MCPWM_TH00 = -cmp; MCPWM_TH01 = cmp;
            FORCE_LOWER_ON(MCPWM_IO23, CH_W);
            FORCE_ALL_OFF(MCPWM_IO01, CH_V);
            break;

        case 2: /* Step2: V+PWM, W下管恒通, U全断 (Hall=1 001: v-w) */
            MCPWM_TH10 = -cmp; MCPWM_TH11 = cmp;
            FORCE_LOWER_ON(MCPWM_IO23, CH_W);
            FORCE_ALL_OFF(MCPWM_IO01, CH_U);
            break;

        case 3: /* Step3: V+PWM, U下管恒通, W全断 (Hall=3 011: v-u) */
            MCPWM_TH10 = -cmp; MCPWM_TH11 = cmp;
            FORCE_LOWER_ON(MCPWM_IO01, CH_U);
            FORCE_ALL_OFF(MCPWM_IO23, CH_W);
            break;

        case 4: /* Step4: W+PWM, U下管恒通, V全断 (Hall=7 111: w-u) */
            MCPWM_TH20 = -cmp; MCPWM_TH21 = cmp;
            FORCE_LOWER_ON(MCPWM_IO01, CH_U);
            FORCE_ALL_OFF(MCPWM_IO01, CH_V);
            break;

        case 5: /* Step5: W+PWM, V下管恒通, U全断 (Hall=6 110: w-v) */
            MCPWM_TH20 = -cmp; MCPWM_TH21 = cmp;
            FORCE_LOWER_ON(MCPWM_IO01, CH_V);
            FORCE_ALL_OFF(MCPWM_IO01, CH_U);
            break;

        default:
            break;
    }

    MCPWM_UPDATE = (1<<0)|(1<<1)|(1<<2)|(1<<3)|(1<<4)|(1<<5);
    MCPWM_PRT = 0x0000CAFE;

    /* 旧红绿灯映射已删除：红/绿灯改由系统监管 SysSupervisor_Tick 每 tick 统一控制 */
}

/*******************************************************************************
 * 无刷 BLDC 使能：门控由 BLDC_DEBUG_ALWAYS_ON 决定（见 Bldc_Update 顶部宏定义）。
 *   正式模式(BLDC_DEBUG_ALWAYS_ON=0)：与轮盘完全绑死，复用"风门正转到位"标志 g_fan_enable，
 *     仅 g_fan_enable=1(风门正转到位首次读低)才转；否则三相高阻、自由滑行。
 *   调试模式(BLDC_DEBUG_ALWAYS_ON=1)：无需步进到位，但听 P2.3 指令——g_cmd==FSM_CMD_FWD(正转指令)才转、反转/无信号即停(三相高阻)；便于单独调无刷而不依赖风门。
 *   - 开启：先短时再预充下管(自举电容补电) -> 读当前霍尔踢一脚换相 -> 使能输出；
 *   - 关闭：PWMOutputs(DISABLE) 三相高阻(无制动、无额外电流) + g_bldc_running=0(中断跳过换相)。
 *   复用步进 FSM 已去抖的 P2.3 命令(g_cmd)控制无刷启停，不另行解析 P2.3 硬件捕获；亦不触碰轮盘 PI。允许循环启停，每次启动都重新踢一脚。
 *******************************************************************************/

/* 启动无刷：短时再预充下管补电 -> 建立霍尔基准 -> 踢一脚初始换相 -> 使能三相输出 */
static void Bldc_Start(void)
{
    volatile uint32_t i, j;

    /* 短时再预充：下管全通给自举电容补电（上电后可能等待很久才到正转命令） */
    MCPWM_PRT = 0x0000DEAD;
    CLEAR_FORCE(MCPWM_IO01, CH_U);
    CLEAR_FORCE(MCPWM_IO01, CH_V);
    CLEAR_FORCE(MCPWM_IO23, CH_W);
    FORCE_LOWER_ON(MCPWM_IO01, CH_U);
    FORCE_LOWER_ON(MCPWM_IO01, CH_V);
    FORCE_LOWER_ON(MCPWM_IO23, CH_W);
    MCPWM_UPDATE = (1<<0)|(1<<1)|(1<<2)|(1<<3)|(1<<4)|(1<<5);
    MCPWM_PRT = 0x0000CAFE;
    for (i = 0; i < BLDC_START_PREOUTER; i++)
        for (j = 0; j < BLDC_START_PREINNER; j++) __NOP();

    /* 建立霍尔基准并踢一脚初始换相，使转子转动并触发后续 HALL 中断自动换相 */
    oldhall = (uint8_t)HALL_GetFilterValue();
    HALL_ApplyCommutation(oldhall);

    PWMOutputs(ENABLE);
    g_bldc_running = 1;
#if BLDC_DEBUG_ALWAYS_ON
#if (UART_TELEMETRY_ENABLE == 1)
    UART1_SendStr("[BLDC] START hall=");
    UART1_SendU32((u32)oldhall);
    UART1_SendStr(" run=1\r\n");
#endif
#endif
}

/* 停止无刷：三相高阻、转子自由滑行减速（无制动、无额外电流） */
static void Bldc_Stop(void)
{
    PWMOutputs(DISABLE);   /* 关闭全局主输出使能(MOE)：三相立即高阻，物理输出不再受换相寄存器影响 */
    g_bldc_running = 0;    /* HALL 中断随后自动跳过换相，关得干净 */
}

/* Debug switch: =1 debug (no stepper-home gate, but follows P2.3 cmd via g_cmd); =0 production (gated by g_fan_enable/stepper-home). Change only this macro to revert. */
#ifndef BLDC_DEBUG_ALWAYS_ON
#define BLDC_DEBUG_ALWAYS_ON   0
#endif

/* Called every 38K tick to start/stop BLDC. */
static void Bldc_Update(void)
{
    if (g_bldc_inhibit) { if (g_bldc_running) Bldc_Stop(); return; }   /* 无料/堵转锁存 -> 强制三相高阻 */
#if BLDC_DEBUG_ALWAYS_ON
    /* 调试：不要求步进到位(跳过 g_fan_enable)，但听 P2.3 指令：
       复用步进 FSM 去抖后的命令 g_cmd —— FSM_CMD_FWD(正转指令)才转，否则(P2.3 反转/无信号)停(高阻)。 */
    if (g_cmd == FSM_CMD_FWD)
    {
        if (!g_bldc_running) Bldc_Start();   /* P2.3 正转 -> 启动并保持无刷运行 */
    }
    else
    {
        if (g_bldc_running) Bldc_Stop();      /* P2.3 反转/无信号 -> 停(三相高阻) */
    }
#else
    if (g_fan_enable && !g_bldc_running)
        Bldc_Start();          /* rising edge: stepper home reached -> start BLDC */
    else if (!g_fan_enable && g_bldc_running)
        Bldc_Stop();           /* falling edge: stop BLDC (high-Z), stepper reverses after */
#endif
}