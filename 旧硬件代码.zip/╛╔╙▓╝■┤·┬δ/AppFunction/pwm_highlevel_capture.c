/*******************************************************************************
 * 版权所有 (C)2015, LINKO SEMICONDUCTOR Co.ltd
 *
 * 文件名称： pwm_highlevel_capture.c
 * 文件标识：
 * 内容摘要： 基于 TIMER0/TIMER1(八分频) 的 PWM 计时模块（三路高电平硬件捕获 +
 P1.0 频率测量）
 * 其它说明： 无
 * 当前版本： V 1.9
 * 作    者： AutoGen
 * 完成日期： 2026年7月21日
 *
 * 修改日期      版本号          修改人            修改内容
 -----------------------------------------------------------------------------
 2026/7/20      V1.0           AutoGen           创建
 2026/7/20      V1.1           AutoGen           改为 P2.3/2.4/2.5 硬件捕获 +
 P1.0 轮询
 * 2026/7/20      V1.2           AutoGen           TIMER0 改为满 16
 位自由计数，P1.0 仅在
 *                                                TIMER0
 溢出(~5.46ms)顺带轮询，彻底不干扰三路捕获
 * 2026/7/20      V1.3           AutoGen           P1.0 轮询改为由 TIMER3 38K
 过零中断驱动
 *                                                （38K 任务函数
 PWM_HighLevel_38K_Exec），TIMER0 专用于 P2.3 捕获
 * 2026/7/20      V1.4           AutoGen           P1.0
 由“高电平测量”改为“频率测量”：
 *                                                相邻上升沿周期换算频率，每 10
 次求平均，
 *                                                新增
 PWM_HighLevel_GetP10Freq() 接口
 * 2026/7/20      V1.5           AutoGen           修复 P1.0 频率测量时间戳并发
 BUG：
 *                                                TIMER0 中断可抢占 38K 任务并使
 g_ovf0++，
 *                                                读 g_ovf0/CNT 非原子会造成
 ±一个 TH(5.46ms)
 *                                                跳变；改用 seqlock 双读 +
 g_ovf0 volatile
 * 2026/7/21      V1.6           AutoGen           撤销
 P2.4“34us”软件去抖（硬件将 P2.4 拉低，根因不在软件）；
 *                                                输入数字滤波 15->2 修复“小 PWM
 输出不清 0”（短高电平被滤波吞掉）；
 *                                                新增“上升沿未闭合则把读数清
 0”逻辑；删除无用的 g_period_valid 状态。
 * 2026/7/22      V1.7           AutoGen           P1.0 频率测量时基由 TIMER0
 12MHz 改为独立 SysTick
 *                                                24 位自由运行
 @96MHz（不进中断）：每 38K tick 用 VAL 回绕差累加 64 位
 *                                                tick，分辨率 ~10.4ns（优于
 83ns），且与 TIMER0/1 三路捕获解耦、无需 seqlock。
 * 2026/7/28      V1.8           AutoGen           高电平量程收窄至 ≤2ms：去掉
 64 位时间戳扩展
 *                                                (pwm_extend) 与 ZERO
 溢出中断，改用 16 位无符号减法直接算
 *                                                高电平/周期，降低 Cortex-M0 上
 64 位运算开销；TIMER0/1 仅使能 CHx 捕获中断。
 * 2026/7/28      V1.9           AutoGen           P1.0 频率测量由 64 位时基降为
 32 位：
 * g_p10_last_rise/g_p10_period_sum/g_systick_tick 及局部 abs/period/num 均改
 u32
 *                                                （相邻上升沿间隔恒 < 300ms
 超时 << 32 位回绕 44.7s，且 num=9.6e8 < 2^32），
 *                                                消除 M0 上 64
 位加/除库调用开销，频率量程不变。
 * 2026/7/29      V2.0           AutoGen           P1.0
 由“周期累加÷变量”改为“频率计数法”：
 *                                                固定 100ms
 窗口内统计上升沿个数(纯乘法) + 8 窗口 ÷8 移位平均，
 *                                                彻底消除唯一一处“除数为变量”的
 32 位 udiv；同步移除 SysTick 时基依赖。
 * 2026/7/29      V2.1           AutoGen           P1.0 频率测量由“频率计数法”改为“相邻上升沿周期法 + EMA 平滑”：
 *                                                以 38K 节拍 g_t38k_cnt 为时基测相邻接受上升沿的间隔(38K tick)作为周期，
 *                                                对周期做 EMA(右移 3 位)后 频率 = 38005 / 周期(仅新边沿时除一次)；
 *                                                延迟降至数十 ms、分辨率 ~0.25Hz@100Hz，并作为播料电机 PI 稳速反馈。
 *                                                撤销 V2.0 的“100ms 窗口数边沿 + 8 窗口÷8 平均”(800ms 滞后、整数边沿量化)方案。
 *******************************************************************************/
#include "hardware_config.h"
#include "pwm_highlevel_capture.h"
#include "adc_sample.h"   /* 新增：两路 ADC 采样（OPA0 差分 + P0.3/CH7），38K 交替采样 */

/* 前向声明 */
static void PWM_HighLevel_PollCapture(void);
static void PWM_ProcessEdge(u8 ch, u16 cap, u8 level_high);

/* ============================ 内部状态 ============================ */
/* 说明：高电平测量 ≤ 3ms，远小于 16 位溢出周期(5.46ms)，故一次“上升沿→下降沿”
   期间计数器不会回绕，直接对 16 位捕获值做无符号减法即得时间差，无需 64 位
   时间戳扩展，也无需 ZERO 溢出中断与 g_ovf 计数。 */

/* 各通道测量状态 */
static u8       g_rise_ok[PWM_CH_NUM] = {0};     /* 是否已捕获上升沿（等待下降沿） */
static u8       g_have_rise[PWM_CH_NUM] = {0};   /* 是否已记录过至少一次上升沿（用于算周期） */
static u16       g_rise_abs[PWM_CH_NUM] = {0};    /* 上升沿时刻的 16 位捕获值(CNT) */
static u32      g_last_us[PWM_CH_NUM]  = {0};     /* 最近一次测得的高电平宽度(us) */
static u32      g_last_period_us[PWM_CH_NUM] = {0}; /* 最近一次测得的周期(us) = 相邻上升沿间隔 */
static u8       g_updated[PWM_CH_NUM]  = {0};     /* 是否有新的有效测量 */
static volatile u32 g_last_edge_38k[PWM_CH_NUM] = {0}; /* 最近一次有效沿时的 38K 时标，用于信号丢失清零 */

static u8       g_p10_last = 0;                   /* P1.0 上一采样时刻电平 0/1 */
static u32      g_t38k_cnt = 0;                   /* 38K 任务自启动以来累计执行次数(每 38K 周期 +1) */

/* ---- P1.0 频率测量状态（相邻上升沿周期法 + EMA 平滑）---- */
static u32   g_p10_last_rise_tick = 0;   /* 上次“接受”的 P1.0 上升沿所在 38K 时标(g_t38k_cnt) */
static u8    g_p10_have_rise      = 0;   /* 是否已记录过一次上升沿（用于算周期） */
static u32   g_p10_period_ema     = 0;   /* 周期 EMA（单位：38K tick），无除法累加 */
static u32   g_p10_freq_hz        = 0;   /* 最近一次算出的频率(Hz) = TICKS_PER_SEC / period_ema */
static u8    g_p10_freq_new       = 0;   /* 是否有新频率(读 GetP10Freq 后清零) */
static u32   g_p10_last_edge_38k  = 0;   /* 最近一次接受上升沿的 38K 时标，供“信号丢失”超时清零 */



/*******************************************************************************
 函数名称：    void PWM_HighLevel_InvokeCallback(u8 ch, u32 high_us)
 功能描述：    根据通道号分派到对应的空白回调函数
 *******************************************************************************/
static void PWM_HighLevel_InvokeCallback(u8 ch, u32 high_us)
{
    switch (ch)
    {
        case PWM_CH_P10: PWM_HighLevel_P10_Callback(high_us); break;
        case PWM_CH_P23: PWM_HighLevel_P23_Callback(high_us); break;
        case PWM_CH_P24: PWM_HighLevel_P24_Callback(high_us); break;
        case PWM_CH_P25: PWM_HighLevel_P25_Callback(high_us); break;
        default: break;
    }
}

/*******************************************************************************
 函数名称：    void PWM_ProcessEdge(u8 ch, u16 cap, u8 level_high)
 功能描述：    处理一次边沿；level_high=1 表示刚发生上升沿，=0 表示刚发生下降沿。
              检测到完整的“上升沿->下降沿”组合后，计算高电平宽度并调用回调。
 说明：        高电平测量需求 ≤ 3ms，远小于 16 位计数器的溢出周期(5.46ms@12MHz)，
              故一次“上升沿->下降沿”期间 CNT 不会回绕，直接对两次 16 位捕获值做
              无符号减法即得 tick 数（跨溢出会因违背 3ms 前提而落入量程过滤）。
 *******************************************************************************/
static void PWM_ProcessEdge(u8 ch, u16 cap, u8 level_high)
{
    /* 记录本次有效沿的 38K 时标，供 38K 任务判定“信号丢失”后清零读数 */
    g_last_edge_38k[ch] = g_t38k_cnt;

    if (level_high)
    {
        /* 上升沿：若上一轮“上升沿->下降沿”尚未闭合（g_rise_ok 仍为 1），
           说明上一次高电平过短、其下降沿被输入数字滤波或中断延迟吞掉，
           必须把残留的旧读数清 0，否则“输入 PWM 变小时输出仍保持旧的大值”。*/
        if (g_rise_ok[ch])
        {
            g_last_us[ch]  = 0;
            g_updated[ch]  = 1;
            PWM_HighLevel_InvokeCallback(ch, 0);
        }
        /* 若已有“上一上升沿”，二者之差即一个完整周期(us)（仅对 < 一个溢出周期准确） */
        if (g_have_rise[ch])
        {
            u16 period = (u16)(cap - g_rise_abs[ch]);
            if ((u32)period <= (u32)PWM_CAPTURE_PERIOD_MAX_TICKS)
            {
                g_last_period_us[ch] = (u32)period / (u32)PWM_TICKS_PER_US;
            }
        }
        g_rise_abs[ch]   = cap;   /* 更新为本次上升沿 16 位捕获值 */
        g_have_rise[ch]  = 1;
        g_rise_ok[ch]    = 1;
    }
    else
    {
        if (g_rise_ok[ch])
        {
            u16 high = (u16)(cap - g_rise_abs[ch]);
            g_rise_ok[ch] = 0;

            /* 仅在量程内（<=3ms）才认为有效，避免异常长低电平/跨溢出误报 */
            if ((u32)high <= (u32)PWM_CAPTURE_MAX_HIGH_TICKS)
            {
                u32 us = (u32)high / (u32)PWM_TICKS_PER_US; /* 12 ticks = 1us */
                g_last_us[ch] = us;
                g_updated[ch] = 1;
                PWM_HighLevel_InvokeCallback(ch, us);
            }
        }
    }
}

/*******************************************************************************
 函数名称：    void PWM_HighLevel_Init(void)
 功能描述：    初始化 TIMER0/TIMER1（八分频）与 4 路被测引脚
 *******************************************************************************/
void PWM_HighLevel_Init(void)
{
    GPIO_InitTypeDef     GPIO_InitStruct;
    TIM_TimerInitTypeDef TIM_InitStruct;
    u8 i;

    /* ---- 1. P2.3/P2.4/P2.5 配置为 TIMER0/1 捕获输入（复用 TIMER0/1） ---- */
    /* 注意：必须显式指定 GPIO_Pin，否则 GPIO_StructInit 默认 GPIO_Pin_NONE 会使
       GPIO_Init 不配置任何引脚（GPIO 方向保持复位态，捕获可能收不到信号）。 */
    GPIO_StructInit(&GPIO_InitStruct);
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN;
    GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_NOPULL;
    GPIO_InitStruct.GPIO_Pin  = GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5;
    GPIO_Init(GPIO2, &GPIO_InitStruct);                     /* P2.3/4/5 设为输入（捕获） */
    GPIO_PinAFConfig(GPIO2, GPIO_PinSource_3, AF7_TIMER01); /* P2.3 -> TIM0_CH1 */
    GPIO_PinAFConfig(GPIO2, GPIO_PinSource_4, AF7_TIMER01); /* P2.4 -> TIM1_CH0 */
    GPIO_PinAFConfig(GPIO2, GPIO_PinSource_5, AF7_TIMER01); /* P2.5 -> TIM1_CH1（捕获，已恢复） */

    /* 注：UART 引脚复用(P0.7->UART1_TXD)已在 hardware_init.c 的 GPIO_init 中配置，
       本文件不再配置 UART，避免与 P0.7/UART1 方案冲突。 */

    /* ---- 2. P1.0 配置为普通输入（轮询方式测量，无 TIMER 复用） ---- */
    GPIO_StructInit(&GPIO_InitStruct);
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN;
    GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_NOPULL;
    GPIO_InitStruct.GPIO_Pin  = GPIO_Pin_0 | GPIO_Pin_1;    /* P1.0 频率测量 + P1.1 电平遥测（均无复用） */
    GPIO_Init(GPIO1, &GPIO_InitStruct);                     /* P1.0/P1.1 输入（无复用） */

    /* 注：P1.0 频率测量时基已改用 38K 节拍 g_t38k_cnt（见 PWM_HighLevel_38K_Exec），
       不再依赖 SysTick，故此处不再初始化 SysTick。 */

    /* ---- 3. TIMER0: 八分频, 满 16 位自由计数(TH=0xFFFF), CH1 双沿捕获(P2.3)。
                       ZERO 溢出中断已关闭：高电平 ≤3ms < 溢出周期 5.46ms，
                       测量窗口内计数器不回绕，直接取 16 位捕获值即可，无需 64 位扩展。 ---- */
    TIM_TimerStrutInit(&TIM_InitStruct);
    TIM_InitStruct.EN                 = ENABLE;
    TIM_InitStruct.Timer_CH0_WorkMode = TIMER_OPMode_CMP;    /* CH0 未用 */
    TIM_InitStruct.Timer_CH0_CapMode  = TIMER_CapMode_None;
    TIM_InitStruct.Timer_CH1_WorkMode = TIMER_OPMode_CAP;    /* CH1 捕获模式 */
    TIM_InitStruct.Timer_CH1_CapMode  = TIMER_CapMode_RiseFall; /* 双沿捕获 */
    TIM_InitStruct.Timer_TH           = PWM_T0_TH;
    TIM_InitStruct.Timer_ClockDiv     = PWM_CAPTURE_TIMER_DIV; /* 96M/8 = 12MHz */
    TIM_InitStruct.Timer_Filter0      = PWM_CAPTURE_FILTER;    /* CH0 数字滤波（未用，一并配置） */
    TIM_InitStruct.Timer_Filter1      = PWM_CAPTURE_FILTER;    /* CH1(P2.3) 数字滤波，抗边沿振铃 */
    TIM_InitStruct.Timer_IRQEna       = Timer_IRQEna_CH1;    /* 使能 CH1 标志位（轮询需要读标志），NVIC 已关闭不进 ISR */
    TIM_TimerInit(TIMER0, &TIM_InitStruct);
    TIM_TimerCmd(TIMER0, ENABLE);

    /* ---- 4. TIMER1: 八分频, 16 位满程, CH0 双沿捕获(P2.4), CH1 双沿捕获(P2.5)。
                       ZERO 溢出中断已关闭：高电平 ≤3ms < 溢出周期，仅使能 CH0/CH1 捕获即可。 ---- */
    TIM_TimerStrutInit(&TIM_InitStruct);
    TIM_InitStruct.EN                 = ENABLE;
    TIM_InitStruct.Timer_CH0_WorkMode = TIMER_OPMode_CAP;
    TIM_InitStruct.Timer_CH0_CapMode  = TIMER_CapMode_RiseFall;
    TIM_InitStruct.Timer_CH1_WorkMode = TIMER_OPMode_CAP;
    TIM_InitStruct.Timer_CH1_CapMode  = TIMER_CapMode_RiseFall;
    TIM_InitStruct.Timer_TH           = PWM_T1_TH;
    TIM_InitStruct.Timer_ClockDiv     = PWM_CAPTURE_TIMER_DIV;
    TIM_InitStruct.Timer_Filter0      = PWM_CAPTURE_FILTER;    /* CH0(P2.4) 数字滤波：P2.4 实际由硬件拉低，此处仅作轻微抗扰 */
    TIM_InitStruct.Timer_Filter1      = PWM_CAPTURE_FILTER;    /* CH1(P2.5) 数字滤波，抗边沿振铃 */
    TIM_InitStruct.Timer_IRQEna       = Timer_IRQEna_CH0 | Timer_IRQEna_CH1;  /* 使能 CH0/CH1 标志位，NVIC 已关闭不进 ISR */
    TIM_TimerInit(TIMER1, &TIM_InitStruct);
    TIM_TimerCmd(TIMER1, ENABLE);

    /* ---- 5. 状态初始化 ---- */
    for (i = 0; i < PWM_CH_NUM; i++)
    {
        g_rise_ok[i]      = 0;
        g_have_rise[i]    = 0;
        g_rise_abs[i]     = 0;
        g_last_us[i]      = 0;
        g_last_period_us[i] = 0;
        g_updated[i]      = 0;
        g_last_edge_38k[i] = 0;
    }
    /* P1.0 以当前电平为初值，避免上电瞬间误判边沿（等待下一个上升沿） */
    g_p10_last = (GPIO_ReadInputDataBit(GPIO1, GPIO_Pin_0) == Bit_SET) ? 1u : 0u;

    /* P1.0 频率测量状态复位（相邻上升沿周期法 + EMA） */
    g_p10_last_rise_tick = 0;
    g_p10_have_rise      = 0;
    g_p10_period_ema     = 0;
    g_p10_freq_hz        = 0;
    g_p10_freq_new       = 0;
    g_p10_last_edge_38k  = 0;
}

/*******************************************************************************
 函数名称：    void PWM_HighLevel_Timer0IRQ(void)
 功能描述：    已废弃：TIMER0 改为轮询模式，捕获逻辑移入 PWM_HighLevel_PollCapture()。
               保留空函数避免外部调用报链接错误。
 *******************************************************************************/
void PWM_HighLevel_Timer0IRQ(void)
{
    /* 废弃：改由 PWM_HighLevel_PollCapture() 轮询处理 */
}

/*******************************************************************************
 函数名称：    void PWM_HighLevel_38K_Exec(void)
 功能描述：    38K 周期任务（由主循环按 TIMER3 38K 节拍调用，约每 26.3us 一次）：
               当前实现 P1.0 频率测量（相邻上升沿周期法 + EMA 平滑：以 38K 节拍为时基
               测相邻上升沿周期，EMA 平滑后换算 Hz，延迟数十 ms、分辨率 ~0.25Hz@100Hz）；
               后续可在此继续添加其它需要在 38K 节拍上执行的任务。
 说明：        每 38K 节拍采样一次 P1.0 电平并做上升沿检测；
               以 g_t38k_cnt 为时基测相邻“接受”上升沿的间隔(38K tick)作为周期，
               对周期做 EMA 平滑(右移 PWM_P10_PERIOD_EMA_SHIFT 位)后，
               频率(Hz) = PWM_P10_TICKS_PER_SEC / 平滑周期(仅新边沿时除一次)；
               全程无 SysTick 时基，延迟远低于原“100ms×8 窗口平均(800ms)”。
               采样率 38K -> 可测最高频率约 19kHz(奈奎斯特)；本函数由主循环按
               TIMER3 38K 节拍调用，不与 P2.3/2.4/2.5 三路捕获争用任何定时器。
 *******************************************************************************/
void PWM_HighLevel_38K_Exec(void)
{
    g_t38k_cnt++;            /* 每进入一次 38K 任务 +1，可用于后续周期任务的节拍计数 */

    /* ---- 三路捕获“信号丢失”检测：超时未收到新沿则清零读数 ----
       避免被测信号停止后仍显示上一次的旧值（用户反馈“无信号仍保持输出”）。 */
    {
        u8 c;
        for (c = PWM_CH_P23; c <= PWM_CH_P25; c++)
        {
            if ((u32)(g_t38k_cnt - g_last_edge_38k[c]) > PWM_SIGNAL_TIMEOUT_38K)
            {
                g_last_us[c]        = 0;
                g_last_period_us[c] = 0;
                g_rise_ok[c]        = 0;
                g_have_rise[c]      = 0;
            }
        }
    }

    /* ---- P1.0 频率“信号丢失”检测：超时未收到新上升沿则清零频率读数 ----
       霍尔停转后无新上升沿，g_p10_freq_hz 会永远停在最后算出的旧值（用户实测断电后仍显示
       47Hz）。此处与三路捕获一致做超时清零，并复位计数/窗口状态等待信号恢复。 */
    if ((u32)(g_t38k_cnt - g_p10_last_edge_38k) > PWM_P10_TIMEOUT_38K)
    {
        g_p10_freq_hz        = 0;
        g_p10_period_ema     = 0;
        g_p10_have_rise      = 0;
        g_p10_last_rise_tick = 0;
    }

    /* ---- P1.0 频率测量：相邻上升沿周期法 + EMA 平滑（高分辨率、低延迟）----
       时基 = 38K 节拍 g_t38k_cnt（每 tick≈26.3us）。每检测到一次“接受”的 P1.0 上升沿，
       以 (当前tick - 上次接受上升沿tick) 作为本周期(单位 38K tick)，
       对 g_p10_period_ema 做 EMA（右移 PWM_P10_PERIOD_EMA_SHIFT 位 ≈ 1/2^SHIFT），再：
           g_p10_freq_hz = PWM_P10_TICKS_PER_SEC / period_ema
       （仅在出现新边沿时做一次除法，约每 10~25ms 一次，M0 开销可忽略）。
       毛刺滤波：相邻接受边沿间隔须 ≥ PWM_P10_MIN_EDGE_GAP_TICKS(=34,≈1.1kHz 截止)。
       这是播料电机 PI 稳速的反馈来源——平滑、低延迟，取代原“800ms 滞后/整数边沿量化”方案。 */
    {
        u8 lvl = (GPIO_ReadInputDataBit(GPIO1, GPIO_Pin_0) == Bit_SET) ? 1u : 0u;

        /* 上升沿处理：检测 0->1 跳变，并做“最小间隔”毛刺滤波。
           与上次“已接受”上升沿的间隔须 ≥ PWM_P10_MIN_EDGE_GAP_TICKS(=34) 个 38K tick；
           更小间隔视为过近毛刺直接丢弃：不更新周期、也不刷新时间戳，
           使下一次真实边沿仍与上次真实边沿比对。 */
        if (lvl && !g_p10_last)
        {
            u32 cur = g_t38k_cnt;
            if (!g_p10_have_rise || (cur - g_p10_last_rise_tick) >= PWM_P10_MIN_EDGE_GAP_TICKS)
            {
                if (g_p10_have_rise)
                {
                    u32 period = cur - g_p10_last_rise_tick;  /* 38K tick 环形回绕安全(差<2^31) */
                    if (period <= PWM_P10_PERIOD_MAX_TICKS)
                    {
                        /* EMA 平滑（无符号防下溢：分升/降两支，避免 (period-ema) 回绕成极大值） */
                        if (period > g_p10_period_ema)
                            g_p10_period_ema += (period - g_p10_period_ema) >> PWM_P10_PERIOD_EMA_SHIFT;
                        else
                            g_p10_period_ema -= (g_p10_period_ema - period) >> PWM_P10_PERIOD_EMA_SHIFT;
                        if (g_p10_period_ema > 0u)
                        {
                            g_p10_freq_hz  = PWM_P10_TICKS_PER_SEC / g_p10_period_ema;  /* 仅在出现新边沿时除一次 */
                            g_p10_freq_new = 1;
                        }
                    }
                }
                g_p10_have_rise     = 1;
                g_p10_last_rise_tick = cur;
                g_p10_last_edge_38k  = cur;   /* 供“信号丢失”超时判定 */
            }
        }
        g_p10_last = lvl;   /* 更新上一次采样电平，供下次沿判定 */
    }

    /* ---- 三路 PWM 捕获轮询（替代原 TIMER0/TIMER1 中断）---- */
    PWM_HighLevel_PollCapture();

    /* ---- ADC 轮询：软件触发14次过采样 + 轮询EOS0 + 读结果（无中断）---- */
    PWM_ADC_PollExec();

    /* 注：35BYJ46 步进走步已移至主循环 DebugPWM_OutputFunction() 按 TIMER3 CNT 节拍驱动，
       不在此 ISR 内，以免干扰无刷换相。 */
}

/*******************************************************************************
 函数名称：    void PWM_HighLevel_Timer1IRQ(void)
 功能描述：    已废弃：TIMER1 改为轮询模式，捕获逻辑移入 PWM_HighLevel_PollCapture()。
               保留空函数避免外部调用报链接错误。
 *******************************************************************************/
void PWM_HighLevel_Timer1IRQ(void)
{
    /* 废弃：改由 PWM_HighLevel_PollCapture() 轮询处理 */
}

/*******************************************************************************
 函数名称：    void PWM_HighLevel_PollCapture(void)
 功能描述：    轮询三路硬件捕获（P2.3/P2.4/P2.5），由 38K 主循环节拍调用。
               替代原 TIMER0/TIMER1 中断方案，消除捕获中断对 HALL 换相的抢占延迟。
               捕获精度不变：边沿瞬间由硬件锁存 CNT 到 CMPTx，轮询只是读取结果。
 *******************************************************************************/
static void PWM_HighLevel_PollCapture(void)
{
    /* ---- P2.3 (TIMER0 CH1) 硬件捕获 ---- */
    if (TIM_GetIRQFlag(TIMER0, TIMER_IF_CH1))
    {
        u16 cap = (u16)TIM_Timer_GetCMPT1(TIMER0);
        u8  lvl = (GPIO_ReadInputDataBit(GPIO2, GPIO_Pin_3) == Bit_SET) ? 1u : 0u;
        TIM_ClearIRQFlag(TIMER0, TIMER_IF_CH1);
        PWM_ProcessEdge(PWM_CH_P23, cap, lvl);
    }

    /* ---- P2.4 (TIMER1 CH0) 硬件捕获 ---- */
    if (TIM_GetIRQFlag(TIMER1, TIMER_IF_CH0))
    {
        u16 cap = (u16)TIM_Timer_GetCMPT0(TIMER1);
        u8  lvl = (GPIO_ReadInputDataBit(GPIO2, GPIO_Pin_4) == Bit_SET) ? 1u : 0u;
        TIM_ClearIRQFlag(TIMER1, TIMER_IF_CH0);
        PWM_ProcessEdge(PWM_CH_P24, cap, lvl);
    }

    /* ---- P2.5 (TIMER1 CH1) 硬件捕获 ---- */
    if (TIM_GetIRQFlag(TIMER1, TIMER_IF_CH1))
    {
        u16 cap = (u16)TIM_Timer_GetCMPT1(TIMER1);
        u8  lvl = (GPIO_ReadInputDataBit(GPIO2, GPIO_Pin_5) == Bit_SET) ? 1u : 0u;
        TIM_ClearIRQFlag(TIMER1, TIMER_IF_CH1);
        PWM_ProcessEdge(PWM_CH_P25, cap, lvl);
    }
}

/*******************************************************************************
 函数名称：    u32 PWM_HighLevel_GetUs(u8 ch)
 功能描述：    读取最近一次测得的高电平宽度（微秒）
 *******************************************************************************/
u32 PWM_HighLevel_GetUs(u8 ch)
{
    if (ch >= PWM_CH_NUM) return 0;
    return g_last_us[ch];
}

/*******************************************************************************
 函数名称：    u32 PWM_HighLevel_GetPeriodUs(u8 ch)
 功能描述：    读取最近一次测得的周期（微秒）= 相邻两个上升沿的时间差。
 *******************************************************************************/
u32 PWM_HighLevel_GetPeriodUs(u8 ch)
{
    if (ch >= PWM_CH_NUM) return 0;
    return g_last_period_us[ch];
}

/*******************************************************************************
 函数名称：    u8 PWM_HighLevel_IsUpdated(u8 ch)
 功能描述：    查询指定通道是否有新的有效测量（读取后清除标志）
 *******************************************************************************/
u8 PWM_HighLevel_IsUpdated(u8 ch)
{
    u8 ret = 0;
    if (ch < PWM_CH_NUM)
    {
        ret = g_updated[ch];
        g_updated[ch] = 0;
    }
    return ret;
}

/*******************************************************************************
 函数名称：    u32 PWM_HighLevel_Get38KTick(void)
 功能描述：    读取 38K 任务累计执行次数（每 38K 周期 +1），供后续扩展任务计时
 *******************************************************************************/
u32 PWM_HighLevel_Get38KTick(void)
{
    return g_t38k_cnt;
}

/*******************************************************************************
 函数名称：    u8 PWM_HighLevel_GetP10Freq(u32 *p_freq_hz)
 功能描述：    读取 P1.0 最近一次的平滑频率(由相邻上升沿周期法+EMA 算出，约每 10~25ms 刷新一次)，
               频率(Hz)通过参数 p_freq_hz 带出。
 返回值：      1=自上次调用以来有新的平滑频率；0=暂无新值（仍返回最近保存值）。
 *******************************************************************************/
u8 PWM_HighLevel_GetP10Freq(u32 *p_freq_hz)
{
    u8 is_new = g_p10_freq_new;
    if (p_freq_hz != 0)
    {
        *p_freq_hz = g_p10_freq_hz;   /* 无有效测量时为 0 */
    }
    g_p10_freq_new = 0;               /* 读取后清除“新值”标志 */
    return is_new;
}

/*******************************************************************************
 函数名称：    u32 PWM_HighLevel_GetP10FreqInstant(void)
 功能描述：    读取 P1.0 当前平滑频率(Hz)的即时值，不清除“新值”标志，供 PI 闭环轮询。
 返回值：      P1.0 当前频率(Hz)，无有效测量时为 0。
 *******************************************************************************/
u32 PWM_HighLevel_GetP10FreqInstant(void)
{
    return g_p10_freq_hz;
}

/* ===================== 各通道空白回调（留待以后实现） ===================== */
void PWM_HighLevel_P10_Callback(u32 freq_hz)
{
    (void)freq_hz;   /* 此处留待后续实现：P1.0 每算出一次平滑频率(Hz)后的业务逻辑 */
}
void PWM_HighLevel_P23_Callback(u32 high_us)
{
    (void)high_us;   /* 此处留待后续实现：P2.3 高电平计时完成后的业务逻辑 */
}
void PWM_HighLevel_P24_Callback(u32 high_us)
{
    (void)high_us;   /* 此处留待后续实现：P2.4 高电平计时完成后的业务逻辑 */
}
void PWM_HighLevel_P25_Callback(u32 high_us)
{
    (void)high_us;   /* 此处留待后续实现：P2.5 高电平计时完成后的业务逻辑 */
}

/************************ (C) COPYRIGHT LINKO SEMICONDUCTOR *****END OF FILE****/
