/*******************************************************************************
 * 文件名称： stepper.c
 * 文件标识：
 * 内容摘要： 35BYJ46 四相五线单极步进电机 GPIO 驱动（半步八拍）
 * 其它说明： 四相八拍（half-step）：8 个状态循环，每切换一次转子走半个基本步距角，
 *            运行最平稳、扭矩较好，是 35BYJ46 最推荐的驱动方式。
 *
 *            运行模式（Stepper_SetDir 控制）：
 *              - 正转 STEPPER_DIR_FWD / 反转 STEPPER_DIR_REV：每 g_step_div 个 38K tick 走一步；
 *              - 停止 STEPPER_DIR_STOP：冻结当前相位（保留最后驱动状态），按停止占空比斩波/全导。
 *            走步速度（每步 38K tick 数）：上电固定 1.5ms/步(STEPPER_DIV_DEFAULT=57 tick)正转；
 *              Stepper_SetStepPeriodTicks() 接口保留，如需再次动态调速可直接调用。
 *            斩波（降热）：软件在每个 38K tick 对“当前导通相”做“导通/关断”交替，降低线圈平均电流。
 *              斩波占空比 0~100(%) 由宏 STEPPER_RUN_DUTY_PCT(运行) / STEPPER_STOP_DUTY_PCT(停止)
 *              独立设置；100%=全导(不斩波,最大力矩/最热)，<100%=按比例斩波(降热,扭矩略降)。
 *              运行态为保证不丢步可保持较高占空比，停止态可更激进降热。
 *            所有运算均为整数，无任何浮点。
 * 当前版本： V 1.1
 * 作    者： AutoGen
 * 完成日期： 2026年7月20日
 *******************************************************************************/
#include "stepper.h"

/* ============================ 四相八拍正转序列（索引 0..7） ============================
   每相状态：1=导通(对应 GPIO 高电平)，0=断电(对应 GPIO 低电平)。
   与用户给定时序完全一致：
     步骤1: A=1 B=0 C=0 D=0
     步骤2: A=1 B=1 C=0 D=0
     步骤3: A=0 B=1 C=0 D=0
     步骤4: A=0 B=1 C=1 D=0
     步骤5: A=0 B=0 C=1 D=0
     步骤6: A=0 B=0 C=1 D=1
     步骤7: A=0 B=0 C=0 D=1
     步骤8: A=1 B=0 C=0 D=1   */
static const u8 g_seq_a[8] = {1, 1, 0, 0, 0, 0, 0, 1};
static const u8 g_seq_b[8] = {0, 1, 1, 1, 0, 0, 0, 0};
static const u8 g_seq_c[8] = {0, 0, 0, 1, 1, 1, 0, 0};
static const u8 g_seq_d[8] = {0, 0, 0, 0, 0, 1, 1, 1};

static u8  g_step_idx  = 0;          /* 当前步骤索引 0..7（停止时冻结 = 保留最后驱动相位） */
static u8  g_state     = (u8)STEPPER_DIR_FWD;   /* 运行模式：正转/反转/停止 */
static u16 g_step_div  = (u16)STEPPER_DIV_DEFAULT; /* 每步 38K tick 数：上电固定 1.5ms/步(57 tick)，不再由 P2.3 调速 */
static u16 g_div_cnt   = 0;          /* g_step_div 运行分频计数 */
static u8  g_run_duty  = (u8)STEPPER_RUN_DUTY_PCT;  /* 运行态斩波占空比(%) */
static u8  g_stop_duty = (u8)STEPPER_STOP_DUTY_PCT; /* 停止态斩波占空比(%) */
static u8  g_run_on    = 0;          /* 运行态：占空比换算出的“导通”tick 数(0..CHOP_PERIOD) */
static u8  g_stop_on   = 0;          /* 停止态：占空比换算出的“导通”tick 数 */
static u8  g_chop_cnt  = 0;          /* 斩波计时(每 38K tick +1 并对 CHOP_PERIOD 取模) */
static u8  g_applied   = 0;          /* 当前 GPIO 是否处于“导通”态(避免每 tick 重复写) */

/*******************************************************************************
 * 函数名称：    static void stepper_apply(u8 idx)
 * 功能描述：    将第 idx 步的四相状态写到对应 GPIO（A/B 在 GPIO2，C/D 在 GPIO0）
 *******************************************************************************/
static void stepper_apply(u8 idx)
{
    u16 set2 = 0, clr2 = 0, set0 = 0, clr0 = 0;

    if (g_seq_a[idx]) set2 |= STEPPER_A_PIN; else clr2 |= STEPPER_A_PIN;
    if (g_seq_b[idx]) set2 |= STEPPER_B_PIN; else clr2 |= STEPPER_B_PIN;
    if (g_seq_c[idx]) set0 |= STEPPER_C_PIN; else clr0 |= STEPPER_C_PIN;
    if (g_seq_d[idx]) set0 |= STEPPER_D_PIN; else clr0 |= STEPPER_D_PIN;

    if (set2) GPIO_SetBits(STEPPER_A_GPIO, set2);
    if (clr2) GPIO_ResetBits(STEPPER_A_GPIO, clr2);
    if (set0) GPIO_SetBits(STEPPER_C_GPIO, set0);
    if (clr0) GPIO_ResetBits(STEPPER_C_GPIO, clr0);
}

/*******************************************************************************
 * 函数名称：    static void stepper_all_off(void)
 * 功能描述：    四相全部关断（释放转子）。用于停止斩波的“关断”相，不更新 g_step_idx。
 *******************************************************************************/
static void stepper_all_off(void)
{
    GPIO_ResetBits(STEPPER_A_GPIO, STEPPER_A_PIN | STEPPER_B_PIN);
    GPIO_ResetBits(STEPPER_C_GPIO, STEPPER_C_PIN | STEPPER_D_PIN);
}

/*******************************************************************************
 * 函数名称：    static u8 stepper_duty_to_on(u8 duty)
 * 功能描述：    斩波占空比(%) -> “导通”tick 数(四舍五入)；100% -> =CHOP_PERIOD(全导)。
 *******************************************************************************/
static u8 stepper_duty_to_on(u8 duty)
{
    u8 on = (u8)(((u16)duty * (u16)STEPPER_CHOP_PERIOD + 50u) / 100u);
    if (on > (u8)STEPPER_CHOP_PERIOD) on = (u8)STEPPER_CHOP_PERIOD;
    return on;
}

/*******************************************************************************
 * 函数名称：    void Stepper_Init(void)
 * 功能描述：    配置 A/B/C/D 四相引脚为 GPIO 输出，并输出第 1 步（A 相导通）
 *******************************************************************************/
void Stepper_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct;

    GPIO_StructInit(&GPIO_InitStruct);
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_NOPULL;

    /* A/B 相在 GPIO2（P2.9 / P2.10） */
    GPIO_InitStruct.GPIO_Pin = STEPPER_A_PIN | STEPPER_B_PIN;
    GPIO_Init(STEPPER_A_GPIO, &GPIO_InitStruct);
    GPIO_PinAFConfig(STEPPER_A_GPIO, GPIO_PinSource_9,  AF0_GPIO);
    GPIO_PinAFConfig(STEPPER_A_GPIO, GPIO_PinSource_10, AF0_GPIO);

    /* C/D 相在 GPIO0（P0.9 / P0.10） */
    GPIO_InitStruct.GPIO_Pin = STEPPER_C_PIN | STEPPER_D_PIN;
    GPIO_Init(STEPPER_C_GPIO, &GPIO_InitStruct);
    GPIO_PinAFConfig(STEPPER_C_GPIO, GPIO_PinSource_9,  AF0_GPIO);
    GPIO_PinAFConfig(STEPPER_C_GPIO, GPIO_PinSource_10, AF0_GPIO);

    g_step_idx  = 0;
    g_state     = (u8)STEPPER_DIR_FWD;
    g_div_cnt   = 0;
    g_run_duty  = (u8)STEPPER_RUN_DUTY_PCT;
    g_stop_duty = (u8)STEPPER_STOP_DUTY_PCT;
    g_run_on    = stepper_duty_to_on(g_run_duty);
    g_stop_on   = stepper_duty_to_on(g_stop_duty);
    g_chop_cnt  = 0;
    g_applied   = 0;
    stepper_apply(g_step_idx);   /* 先输出第 1 步（A=1,B=0,C=0,D=0） */
}

/*******************************************************************************
 * 函数名称：    void Stepper_SetDir(Stepper_Dir_TypeDef dir)
 * 功能描述：    设置运行模式（正转/反转/停止）。下次 Stepper_Tick() 即按新模式动作。
 *            进入 STOP 时从“导通”相位开始（保证第一瞬间即保持力矩）；
 *            从 STOP 切回运行则从冻结的相位继续走步。
 *******************************************************************************/
void Stepper_SetDir(Stepper_Dir_TypeDef dir)
{
    g_chop_cnt = 0;     /* 进入/退出停止都从“导通”相位开始，保证切换瞬间不丢保持力矩 */
    g_applied  = 0;     /* 强制下次 Tick 重新决定导通/关断 */
    g_div_cnt  = 0;     /* 从停止切回运行：重新按 g_step_div 走步，相位从冻结处继续 */
    g_state    = (u8)dir;
}

/*******************************************************************************
 * 函数名称：    void Stepper_AllOff(void)
 * 功能描述：    四相全部关断（真正断电，释放转子）。堵转保护时由 hardware_init.c 调用，
 *            调用方须不跑 Stepper_Tick()，使步进保持完全断电。
 *******************************************************************************/
void Stepper_AllOff(void)
{
    stepper_all_off();
}

/*******************************************************************************
 * 函数名称：    void Stepper_SetStopDuty(u8 duty_pct)
 * 功能描述：    设置停止态斩波占空比(%)（仅处于 STEPPER_DIR_STOP 时生效）。
 *******************************************************************************/
void Stepper_SetStopDuty(u8 duty_pct)
{
    g_stop_duty = duty_pct;
    g_stop_on   = stepper_duty_to_on(duty_pct);
    g_chop_cnt  = 0;              /* 切换从“导通”相位开始，保证切换瞬间不丢保持力矩 */
    g_applied   = 0;
}

/*******************************************************************************
 * 函数名称：    void Stepper_SetRunDuty(u8 duty_pct)
 * 功能描述：    设置运行态斩波占空比(%)（正转/反转时生效）。
 *******************************************************************************/
void Stepper_SetRunDuty(u8 duty_pct)
{
    g_run_duty = duty_pct;
    g_run_on   = stepper_duty_to_on(duty_pct);
    g_chop_cnt = 0;
    g_applied  = 0;
}

/*******************************************************************************
 * 函数名称：    void Stepper_SetStepPeriodTicks(u16 ticks)
 * 功能描述：    设置走步周期（每步的 38K tick 数）。由 P2.3 输入 PWM 命令映射调用。
 * 输入参数：    ticks: 每步 38K tick 数（钳位到 [STEPPER_DIV_FAST, STEPPER_DIV_SLOW]）
 * 输出参数：    无
 * 返回信息：    无
 * 注：         值过小(接近 0)会使步进每步时间过短 -> 堵转啸叫/丢步，故钳位到安全区间。
 *******************************************************************************/
void Stepper_SetStepPeriodTicks(u16 ticks)
{
    if (ticks < (u16)STEPPER_DIV_FAST) ticks = (u16)STEPPER_DIV_FAST;
    if (ticks > (u16)STEPPER_DIV_SLOW) ticks = (u16)STEPPER_DIV_SLOW;
    g_step_div = ticks;
}

/*******************************************************************************
 * 函数名称：    void Stepper_Tick(void)
 * 功能描述：    每个 38K tick 调用一次：
 *              - 停止态：冻结相位（保留最后驱动状态），按 g_stop_on 占空比斩波；
 *              - 运行态：每 g_step_div 个 38K tick 走一步，按 g_run_on 占空比斩波。
 *              斩波 = 按 CHOP_PERIOD 周期对“当前导通相”做导通/关断交替，降低平均电流。
 *            全程整数运算，无任何浮点。
 *******************************************************************************/
void Stepper_Tick(void)
{
    /* ---------------- 选择当前生效的斩波“导通”tick 数，并在需要时走步 ---------------- */
    u8 active_on     = g_stop_on;   /* 停止态用停止占空比 */
    u8 phase_changed = 0u;

    if (g_state != (u8)STEPPER_DIR_STOP)
    {
        active_on = g_run_on;        /* 运行态用运行占空比 */
        g_div_cnt++;
        if (g_div_cnt >= g_step_div)
        {
            g_div_cnt = 0;
            if (g_state == (u8)STEPPER_DIR_FWD)
                g_step_idx = (u8)((g_step_idx + 1u) % 8u);   /* 正转：步骤 1->8 循环 */
            else
                g_step_idx = (u8)((g_step_idx + 7u) % 8u);   /* 反转：步骤 8->1 循环 */
            phase_changed = 1u;
        }
    }

    /* ---------------- 斩波应用：按 active_on/CHOP_PERIOD 决定本 tick 导通或关断 ---------------- */
    if (active_on >= (u8)STEPPER_CHOP_PERIOD)
    {
        /* 100%：全导(不斩波)，仅相位变化或当前为关断时重写 GPIO */
        if ((g_applied == 0u) || (phase_changed != 0u))
        {
            stepper_apply(g_step_idx);
            g_applied = 1u;
        }
    }
    else if (active_on == 0u)
    {
        /* 0%：全关（无保持力矩，一般不使用） */
        if (g_applied != 0u)
        {
            stepper_all_off();
            g_applied = 0u;
        }
    }
    else
    {
        g_chop_cnt++;
        if (g_chop_cnt >= (u8)STEPPER_CHOP_PERIOD) g_chop_cnt = 0u;   /* 等价 %CHOP_PERIOD，去掉每 tick 除法 */
        if (g_chop_cnt < active_on)
        {
            if ((g_applied == 0u) || (phase_changed != 0u))
            {
                stepper_apply(g_step_idx);
                g_applied = 1u;
            }
        }
        else
        {
            if (g_applied != 0u)
            {
                stepper_all_off();
                g_applied = 0u;
            }
        }
    }
}

/************************ (C) COPYRIGHT LINKO SEMICONDUCTOR *****END OF FILE****/
