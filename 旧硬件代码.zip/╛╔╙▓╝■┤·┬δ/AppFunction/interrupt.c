/*******************************************************************************
 * Copyright (C) 2015, LINKO SEMICONDUCTOR Co.ltd
 *
 * File:        interrupt.c
 * Description: Interrupt service routines
 * Note:        The following ISRs are actually enabled in NVIC and do work:
 *                - HALL_IRQHandler    : HALL commutation + overflow
 *                - UTIMER0_IRQHandler : P2.3 hardware capture (input PWM ch1)
 *                - UTIMER1_IRQHandler : P2.4/P2.5 hardware capture (input PWM ch2/3)
 *              All other peripheral IRQs (ADC0 / ENCODER0 / ENCODER1 / CMP /
 *              UART0 / UART1 / GPIO / I2C0 / SPI0 / UTIMER2 / UTIMER3 / SysTick /
 *              WAKE) are NOT enabled in NVIC, so their vectors fall back to the
 *              startup Weak Default_Handler and never fire. Their empty ISRs were
 *              removed to avoid dead/placeholder code.
 *******************************************************************************/
#include "hardware_init.h"
#include "pwm_highlevel_capture.h"
#include "adc_sample.h"

/* HALL capture interrupt: commutation on HALL change + overflow handling. */
uint8_t g_hall_acc = 0xFF;
uint8_t nowhall = 0;
uint8_t oldhall = 0xFF;   /* 0xFF = uninitialized; first edge accepted unconditionally */
extern uint8_t NEXT_MAP[8][3];
extern volatile u8 g_bldc_running;  /* 无刷使能状态(由 hardware_init.c 维护)：0=三相高阻，1=正常换相 */
volatile u16 g_hall_edge_cnt = 0;   /* HALL 换向沿计数：中断累加，主循环 100ms 读取后清零，用于无刷转速测量 */
volatile u16 g_hall_skip_cnt = 0;    /* HALL 跳步计数：自上次 UART 输出后累计的 skip-1-step 次数，输出后清零 */

void HALL_IRQHandler(void)
{
    if (HALL_GetIRQFlag(HALL_CAPTURE_EVENT))
    {
        HALL_ClearIRQFlag(HALL_CAPTURE_EVENT);
        if (!g_bldc_running) return;   /* 无刷门控关闭：三相已高阻，跳过换相，避免误改写驱动 */
        nowhall = (uint8_t)HALL_GetFilterValue();
        /* First edge (oldhall==0xFF) accepted unconditionally; afterwards only the
           forward 1-step / skip-1-step successors (NEXT_MAP[oldhall][0]/[1]) are
           accepted. Backward steps are ignored until the next forward edge. */
        if (oldhall == 0xFF || nowhall == NEXT_MAP[oldhall][0] || nowhall == NEXT_MAP[oldhall][1])
        {
            if (oldhall != 0xFF && nowhall == NEXT_MAP[oldhall][1])
                g_hall_skip_cnt++;  /* 跳步：非首沿且命中 NEXT_MAP[1]（skip-1-step） */
            oldhall = nowhall;
            HALL_ApplyCommutation(nowhall);
            g_hall_edge_cnt++;   /* 每次成功换相计一次，供主循环 100ms 窗口测算转速 */
        }
    }
    if (HALL_GetIRQFlag(HALL_OVERFLOW_EVENT))
    {
        HALL_ClearIRQFlag(HALL_OVERFLOW_EVENT);
    }
}

/* TIMER0/TIMER1 capture: 改为主循环 38K 轮询（PWM_HighLevel_PollCapture），
   不再使用中断，消除对 HALL 换相的抢占延迟。ISR 保留空壳避免链接警告。 */
void UTIMER0_IRQHandler(void) { }
void UTIMER1_IRQHandler(void) { }

/* ADC0: 改为软件触发+轮询（PWM_ADC_PollExec），不再使用中断。保留空壳。 */
void ADC0_IRQHandler(void) { }

#if (UART_TELEMETRY_ENABLE == 1)
/* UART1 发送空中断：从环形缓冲区取字节继续发送，发送完毕后关闭中断。
   缓冲区大小须与 hardware_init.c 中的 UART1_TX_BUF_SIZE 保持一致。 */
#define UART1_TX_BUF_SIZE 256
extern volatile u8  g_uart1_tx_buf[];
extern volatile u16 g_uart1_tx_wr;
extern volatile u16 g_uart1_tx_rd;
extern volatile u8  g_uart1_tx_busy;

void UART1_IRQHandler(void)
{
    if (UART_GetIRQFlag(UART1, UART_IF_SendBufEmpty))
    {
        UART_ClearIRQFlag(UART1, UART_IF_SendBufEmpty);

        if (g_uart1_tx_rd != g_uart1_tx_wr)
        {
            /* 缓冲区非空：发送下一个字节 */
            UART_SendData(UART1, (u32)g_uart1_tx_buf[g_uart1_tx_rd]);
            g_uart1_tx_rd = (u16)((g_uart1_tx_rd + 1u) & (UART1_TX_BUF_SIZE - 1u));
        }
        else
        {
            /* 缓冲区已空：标记空闲，关闭发送空中断 */
            g_uart1_tx_busy = 0;
            UART1->IE &= ~UART_IRQEna_SendBuffEmpty;
        }
    }
}
#endif  /* UART_TELEMETRY_ENABLE == 1 */

/* WAKE interrupt: low-power wakeup. Currently NVIC-disabled and never entered;
   kept as the wakeup/stop defensive handler. */
void WAKE_IRQHandler(void)
{
    while (1)
        ;
}

/************************ (C) COPYRIGHT LINKO SEMICONDUCTOR **********************/
/* ------------------------------END OF FILE------------------------------------ */
