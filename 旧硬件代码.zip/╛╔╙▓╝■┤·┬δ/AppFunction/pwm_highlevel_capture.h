/*******************************************************************************
 * 版权所有 (C)2015, LINKO SEMICONDUCTOR Co.ltd
 *
 * 文件名称： pwm_highlevel_capture.h
 * 文件标识：
 * 内容摘要： 基于 TIMER0/TIMER1(八分频) 的 PWM 高电平计时模块头文件（三路硬件捕获 + P1.0 低精度轮询）
 * 其它说明： 无
 * 当前版本： V 1.9
 * 作    者： AutoGen
 * 完成日期： 2026年7月21日
 *
 * 设计要点（详见 程序说明.md）：
 *   引脚分配：P1.0 轮询 / P2.3 = TIMER0_CH1 / P2.4 = TIMER1_CH0 / P2.5 = TIMER1_CH1。
 *   - P2.3/2.4/2.5 使用 TIMER 硬件“双沿捕获”（TIMER0_CH1、TIMER1_CH0/CH1），
 *     捕获值锁存到 CMPTx，分辨率 1 tick（12MHz 下约 83ns）。
 *   - P1.0 无 TIMER 捕获复用，故在主循环 38K 节拍轮询其电平边沿（38K 任务函数
 *     PWM_HighLevel_38K_Exec）：轮询周期 = TIMER3 溢出 ≈ 26.3us（38K）。
 *     该任务与 TIMER0/1 捕获完全独立，不影响 P2.3/2.4/2.5 三个硬件捕获。
 *   - P1.0 测量方式为“相邻上升沿周期法 + EMA 平滑”：以 38K 节拍 g_t38k_cnt 为时基，
 *     测相邻两次接受上升沿的间隔(38K tick)作为一个周期，对周期做 EMA 平滑(右移
 *     PWM_P10_PERIOD_EMA_SHIFT 位)后换算频率 = PWM_P10_TICKS_PER_SEC / period_ema；
 *     边沿加“最小间隔”毛刺滤波：相邻接受边沿间隔须 ≥ PWM_P10_MIN_EDGE_GAP_TICKS(=34)
 *     个 38K tick（≈1.1kHz 截止），更密的过近边沿判为毛刺丢弃。结果经
 *     PWM_HighLevel_GetP10Freq()/PWM_HighLevel_GetP10FreqInstant() 读取。
 *     相比原“100ms 窗口数边沿 + 8 窗口÷8 平均(800ms 滞后、整数边沿量化)”，本方法延迟
 *     降至数十 ms、分辨率 ~0.25Hz@100Hz，为播料电机 PI 稳速提供平滑低延迟反馈。
 *     与 TIMER0/1 三路捕获完全解耦。
 *   定时器分频：TIMER0/TIMER1 均 96MHz/8 = 12MHz（满足“TIMER0 八分频”要求）。
 *   量程：高电平测量需求 ≤ 3ms（36000 tick @12MHz，留余量），远小于 16 位溢出周期(5.46ms)，
 *         故一次“上升沿->下降沿”期间计数器不会回绕，直接对 16 位捕获值做无符号减法即得
 *         高电平宽度，无需 64 位时间戳扩展与 ZERO 溢出中断，M0 上效率更高。
 *
 * 修改日期      版本号          修改人            修改内容
 * -----------------------------------------------------------------------------
 * 2026/7/20      V1.0           AutoGen           创建（TIMER0 计时基准 + 轮询方案）
 * 2026/7/20      V1.1           AutoGen           改为 P2.3/2.4/2.5 硬件捕获 + P1.0 轮询
 * 2026/7/20      V1.2           AutoGen           TIMER0 改为满 16 位自由计数，P1.0 仅在
 *                                                TIMER0 溢出(~5.46ms)顺带轮询，彻底不干扰三路捕获
 * 2026/7/20      V1.3           AutoGen           P1.0 轮询改为由 TIMER3 38K 过零中断驱动
 *                                                （38K 任务函数 PWM_HighLevel_38K_Exec），TIMER0 专用于 P2.3 捕获
 * 2026/7/20      V1.4           AutoGen           P1.0 由“高电平测量”改为“频率测量”：
 *                                                相邻上升沿周期换算频率，每 10 次求平均，
 *                                                新增 PWM_HighLevel_GetP10Freq() 接口
 * 2026/7/21      V1.6           AutoGen           同步 .c V1.6：撤销 P2.4 软件去抖、滤波 15->2 修复小 PWM 不清 0、
 *                                                上升沿未闭合清 0、删除无用 g_period_valid（本头文件此前停留在 V1.2）
 * 2026/7/28      V1.8           AutoGen           高电平量程收窄至 ≤2ms：去掉 64 位时间戳扩展(pwm_extend)
 *                                                与 ZERO 溢出中断，改用 16 位无符号减法直接算高电平/周期；
 *                                                TIMER0/1 仅使能 CHx 捕获中断，降低 Cortex-M0 上 64 位运算开销。
 * 2026/7/28      V1.9           AutoGen           P1.0 频率测量由 64 位时基降为 32 位：
 *                                                g_p10_last_rise/g_p10_period_sum/g_systick_tick 及局部 abs/period/num
 *                                                均改 u32（96e6*10=9.6e8 < 2^32，相邻上升沿间隔恒 < 300ms 超时 << 44.7s 回绕），
 *                                                消除 M0 上 64 位加/除库调用开销，频率量程不变（~10Hz~奈奎斯特 19kHz）。
 *******************************************************************************/
#ifndef __PWM_HIGHLEVEL_CAPTURE_H
#define __PWM_HIGHLEVEL_CAPTURE_H

#include "lks32mc05x_tim.h"
#include "lks32mc05x_gpio.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ============================ 配置宏 ============================ */
/* TIMER0 / TIMER1 均采用 96MHz/8 = 12MHz（八分频）计时基准 */
#define PWM_CAPTURE_TIMER_DIV       TIM_Clk_Div8
#define PWM_CAPTURE_TIMER_FREQ_HZ   (96000000uL / 8uL)                /* 12 MHz（三路捕获 TIMER0/1 时基） */
#define PWM_TICKS_PER_US            (PWM_CAPTURE_TIMER_FREQ_HZ / 1000000uL) /* 12 ticks/us */

/* P1.0 频率测量：相邻上升沿周期法 + EMA 平滑（高分辨率、低延迟，优于原“频率计数法”）
   - 时基 = 38K 任务节拍 g_t38k_cnt，每 tick ≈ 26.3us（96M/2526 ≈ 38005Hz）。
   - 每检测到一次“接受”的 P1.0 上升沿(经毛刺滤波)，以 (当前tick - 上次上升沿tick) 作为本周期(38K tick)，
     对 g_p10_period_ema 做 EMA(右移 PWM_P10_PERIOD_EMA_SHIFT 位 ≈ 1/2^SHIFT)，再：
        频率(Hz) = PWM_P10_TICKS_PER_SEC / period_ema
     （仅在出现新边沿时做一次除法，约每 10~25ms 一次，M0 开销可忽略）。
   - 延迟约数十 ms（≈ 2^SHIFT 个边沿），分辨率约 0.25Hz@100Hz；
     相比原“100ms 窗口数边沿 + 8 窗口平均(800ms 滞后、整数边沿量化到 82/115Hz)”稳定可控。 */
#define PWM_P10_TICKS_PER_SEC        ((u32)38005u)   /* 38K 节拍频率 ≈96M/2526（P1.0 测频时基） */
#define PWM_P10_MIN_EDGE_GAP_TICKS  ((u32)34u)      /* 边沿最小间隔(38K tick)：相邻接受边沿间隔须 ≥ 此值，
                                                      小于此值的上升沿判为过近毛刺丢弃（34≈1.1kHz 截止）。 */
#define PWM_P10_PERIOD_EMA_SHIFT     ((u8)3u)        /* 周期 EMA 右移位数：时间常数 ≈ 2^3=8 个边沿 ≈ 80ms@100Hz */
#define PWM_P10_PERIOD_MAX_TICKS     ((u32)100000u)  /* 周期上限(38K tick)：>此值判为超低速/无效（≈2.6s → <0.38Hz） */

/* TIMER0 计数模值：与 TIMER1 一致，采用满 16 位自由计数(0xFFFF)，溢出周期 ≈ 5.46ms。
   因高电平测量 ≤ 3ms < 5.46ms，测量窗口内计数器不会回绕，故本方案不使能 ZERO 溢出中断、
   也不做 64 位时间戳扩展，TIMER0 中断仅服务于 P2.3 的 CH1 捕获即可。 */
#define PWM_T0_TH                   ((u32)0xFFFFu)
/* TIMER1 用满 16 位自由计数（0xFFFF）；因高电平 ≤ 3ms < 溢出周期，不做溢出扩展，
   仅使能 CH0/CH1 双沿捕获中断，ZERO 溢出中断关闭。 */
#define PWM_T1_TH                   ((u32)0xFFFFu)

/* 最大可测量高电平：3ms -> 36000 ticks @12MHz（在 2ms 需求上留 1ms 余量，仍远小于
   16 位溢出周期 5.46ms，故测量窗口内计数器不会回绕，可直接用 16 位无符号减法算高电平，
   无需 64 位扩展）。若实际高电平可能更长，请相应增大此处（但超过 5.46ms 需恢复溢出计数方案）。 */
#define PWM_CAPTURE_MAX_HIGH_MS     ((u32)3u)
#define PWM_CAPTURE_MAX_HIGH_TICKS  ((u32)(PWM_CAPTURE_TIMER_FREQ_HZ / 1000uL) * \
                                     (u32)PWM_CAPTURE_MAX_HIGH_MS)   /* 36000 */

/* 周期测量（相邻两上升沿）量程：仅当间隔 < 一个 16 位溢出周期时 16 位减法才准确，
   故限制为 ~5ms(60000 tick)；更低的频率周期会跨回绕，本简化方案判为无效（读数清 0）。
   如需低频周期，请恢复 64 位时间戳扩展方案。 */
#define PWM_CAPTURE_PERIOD_MAX_TICKS ((u32)60000u)

/* 三路捕获输入数字滤波值(0~15)：滤波宽度 = 值×8 个系统时钟(96MHz) = 值×83.3ns。
   取 2 => 2×8/96MHz ≈ 0.17us：仅抑制亚微秒级毛刺，允许很短的高电平脉宽通过。
   之前取 15(≈1.25us) 会把“小占空比/短高电平”的 PWM 整段吞掉，导致该路读数
   一直保留上一次的大值、清不到 0（即“输入 PWM 小时输出不清 0”的 BUG）。
   注：P2.4 当初“恒为 34us”经确认为硬件把该脚拉低所致，并非软件噪声，故滤波
   无需为 P2.4 特别加宽；保持较小值以正确捕获短脉宽。 */
#define PWM_CAPTURE_FILTER          ((u8)2u)

/* 三路捕获“信号丢失”判定：连续多少个 38K 节拍(≈26.3us)未收到新的有效沿
   即认为信号已消失，将该路读数清零（避免无信号时仍显示上一次旧值）。
   约 300ms：300ms / 26.3us ≈ 11400 */
#define PWM_SIGNAL_TIMEOUT_38K      ((u32)11400u)

/* P1.0 频率测量“信号丢失”判定：连续多少个 38K 节拍未收到新的上升沿即认为霍尔已停止输出，
   将频率读数清零。本方法(相邻上升沿周期法+EMA)约每 10~25ms 刷新一次频率；霍尔停转后无新上升沿，
   g_p10_freq_hz 会在约 300ms 超时后被清零（修复“断电后仍显示 47Hz”的旧问题）。
   约 300ms(300ms/26.3us≈11400)，足以容纳最低频(≥10Hz,周期100ms)真实信号相邻上升沿，不误清。 */
#define PWM_P10_TIMEOUT_38K         ((u32)11400u)

/* 通道索引（与引脚一一对应） */
#define PWM_CH_P10   0   /* P1.0  - 轮询实现（相邻上升沿周期法+EMA，无 TIMER 复用；38K 节拍采样上升沿） */
#define PWM_CH_P23   1   /* P2.3  - TIMER0 CH1 硬件捕获 */
#define PWM_CH_P24   2   /* P2.4  - TIMER1 CH0 硬件捕获 */
#define PWM_CH_P25   3   /* P2.5  - TIMER1 CH1 硬件捕获 */
#define PWM_CH_NUM   4

/* ============================ 对外接口 ============================ */
/* 初始化 TIMER0/TIMER1 与 4 路引脚；NVIC 使能在 Hardware_init() 中统一开启 */
void PWM_HighLevel_Init(void);
/* 由 UTIMER0_IRQHandler 调用：处理 CH1(P2.3 捕获)；ZERO 溢出中断已关闭，不做 64 位扩展 */
void PWM_HighLevel_Timer0IRQ(void);
/* 由 UTIMER1_IRQHandler 调用：处理 CH0(P2.4)/CH1(P2.5) 捕获；ZERO 溢出中断已关闭 */
void PWM_HighLevel_Timer1IRQ(void);
/* 38K 周期任务由主循环 polling TIMER3 计数驱动（见 hardware_init.c 的 DebugPWM_OutputFunction），不再依赖 UTIMER3 中断。UTIMER3_IRQHandler 已移除。 */
void PWM_HighLevel_38K_Exec(void);
/* 读取 38K 任务自启动以来的累计执行次数（每 38K 周期 +1），供后续扩展任务计时 */
u32  PWM_HighLevel_Get38KTick(void);

/* 读取最近一次测得的高电平宽度（单位：微秒）；无有效测量时返回 0
   注意：P1.0(PWM_CH_P10) 已改为频率测量，请改用 PWM_HighLevel_GetP10Freq() */
u32  PWM_HighLevel_GetUs(u8 ch);
/* 读取最近一次测得的周期（微秒）= 相邻两上升沿间隔；无有效测量时返回 0
   注意：简化方案下周期仅在 < ~5ms（一个溢出周期）时准确，更低频判为无效 */
u32  PWM_HighLevel_GetPeriodUs(u8 ch);
/* 读取指定通道是否有新的有效测量（调用后自动清除标志） */
u8   PWM_HighLevel_IsUpdated(u8 ch);

/* 读取 P1.0 最近一次的频率（相邻上升沿周期法 + EMA 平滑，约每 10~25ms 刷新一次）。
   频率通过参数 p_freq_hz 带出（单位：Hz）；
   返回值：1=自上次调用以来有新的频率（并已写入 *p_freq_hz），0=暂无新值
           （*p_freq_hz 仍会写入当前保存的最近一次频率，无有效值时为 0）。 */
u8   PWM_HighLevel_GetP10Freq(u32 *p_freq_hz);
/* 读取 P1.0 当前平滑频率（Hz）的即时值（不清除“新值”标志，供 PI 闭环轮询使用）；
   无有效测量时返回 0。 */
u32  PWM_HighLevel_GetP10FreqInstant(void);

/* ===================== 各通道空白回调（留待以后实现） ===================== */
/* P2.3/2.4/2.5：每捕获到一个完整“上升沿->下降沿”组合后调用，参数为该次高电平微秒数。
   P1.0：每算出一次平均频率后调用，参数为平均频率(Hz)（非微秒）。
   请在此处填充具体业务逻辑；如需在其它文件实现，可删除本文件中的空函数体。 */
void PWM_HighLevel_P10_Callback(u32 freq_hz);  /* P1.0（频率测量，参数=Hz） */
void PWM_HighLevel_P23_Callback(u32 high_us);  /* P2.3（TIMER0_CH1，参数=us） */
void PWM_HighLevel_P24_Callback(u32 high_us);  /* P2.4（TIMER1_CH0，参数=us） */
void PWM_HighLevel_P25_Callback(u32 high_us);  /* P2.5（TIMER1_CH1，参数=us） */

#ifdef __cplusplus
}
#endif

#endif /* __PWM_HIGHLEVEL_CAPTURE_H */

/************************ (C) COPYRIGHT LINKO SEMICONDUCTOR *****END OF FILE****/
