/*******************************************************************************
 * 版权所有 (C)2021, LINKO SEMICONDUCTOR Co.ltd
 *
 * 文件名称： adc_sample.c
 * 文件标识：
 * 内容摘要： 两路 ADC 采样模块（OPA0 差分放大 + P0.3/ADC_CH7，38K 交替采样/硬件过采样）
 * 其它说明： 无
 * 当前版本： V 1.0
 * 作    者： AutoGen
 * 完成日期： 2026年7月20日
 *
 * 修改日期      版本号          修改人            修改内容
 -----------------------------------------------------------------------------
 2026/7/20     V1.0           AutoGen           创建
 *******************************************************************************/
#include "adc_sample.h"

/* ============================ 内部状态 ============================ */
static s32 g_adc_code[2] = {0, 0};   /* 两路最新平均 code（已减软件零偏）：0=差分(OPA0), 1=CH7(P0.3) */
static u8  g_adc_new[2]  = {0, 0};   /* 两路“有新值”标志（读 getter 后清零） */
static u8  g_adc_trig_ch = 0;        /* 上一 tick 触发的是哪一路（0/1） */
static u8  g_adc_started = 0;        /* 是否已触发过第一次（用于首 tick 跳过读回） */
static s32 g_adc_diff_offset = 0;    /* OPA0 差分通道软件零点偏移（短路 IP/IN 校准得到） */
static s32 g_adc_ch7_offset  = 0;    /* CH7 单端通道软件零点偏移（零电流时校准得到） */
static u32 g_adc_ch7_last_raw = 0;   /* 调试：CH7 最近一次原始平均 code(减偏前)，供遥测打印定位读数偏差 */
static u32 g_adc_diff_last_raw = 0;  /* 调试：无刷(OPA0 差分)最近一次原始平均 code，供遥测打印 RAW 值 */

/* 高速中断采样状态 */
static volatile u8  g_adc_hs_mode  = 0;   /* 1=高速中断自触发采样模式 */
static volatile u32 g_bldc_peak_code = 0; /* 无刷电流峰值 code（已减零偏、钳 0） */
static volatile u32 g_step_peak_code = 0; /* 步进电流峰值 code（已减零偏、钳 0） */

/* 原始采样数据双缓冲：每次 38kHz 触发产生 14 个 code，ISR 写入，主程序读取。
   buf[0][] 给 ISR 写，buf[1][] 给主程序读；每次完成后交换。 */
static volatile u32 g_adc_bldc_samples[2][PWM_ADC_HS_SAMPLES_PER_CH];
static volatile u32 g_adc_step_samples[2][PWM_ADC_HS_SAMPLES_PER_CH];
static volatile u8  g_adc_sample_buf_wr = 0;  /* ISR 当前写入的缓冲区索引 */
static volatile u16 g_adc_sample_cnt    = 0;  /* 每完成一次 EOS0 中断 +1，供主程序判断新数据 */

/*******************************************************************************
 函数名称：    static void ADC_ConfigSeg(u16 adc_ch)
 功能描述：    配置本次触发的单段连续采样：所有采样槽都填为 adc_ch，
               CHNT.FirSeg_Ch = PWM_ADC_OVERSAMPLE（其余段=0）。
 *******************************************************************************/
static void ADC_ConfigSeg(u16 adc_ch)
{
    /* CHN0..CHN3 共 16 个采样槽全部填为同一通道，确保 FirSeg_Ch<=16 时均采样该通道 */
    ADC_ChannelConfig(ADC0, CHN0, adc_ch, adc_ch, adc_ch, adc_ch);
    ADC_ChannelConfig(ADC0, CHN1, adc_ch, adc_ch, adc_ch, adc_ch);
    ADC_ChannelConfig(ADC0, CHN2, adc_ch, adc_ch, adc_ch, adc_ch);
    ADC_ChannelConfig(ADC0, CHN3, adc_ch, adc_ch, adc_ch, adc_ch);
    ADC0->CHNT = (u32)PWM_ADC_OVERSAMPLE;   /* 单段采样次数 = 过采样数 */
}



/*******************************************************************************
 函数名称：    void PWM_ADC_Init(void)
 功能描述：    OPA0 差分放大 + ADC 初始化。零点由芯片内部 DC/AMC 工厂校准 + 软件零点校准共同处理。
 说明：        须在中断关闭的硬件初始化期调用；本函数不自行开关总中断。
               ADC 的工厂偏移(DC)/增益(AMC)校准在 ADC_Init 内按量程自动从 NVR trim 载入（同例程）；
               软件零点校准由 PWM_ADC_OffsetCalibration() 在初始化阶段完成。
 *******************************************************************************/
void PWM_ADC_Init(void)
{
    ADC_InitTypeDef   ADC_InitStructure;
    OPA_InitTypeDef   OPA_InitStruct;

    /* ---- 1. OPA0 差分放大：P1.14=IP、P1.15=IN 为片内专用模拟脚，无需 GPIO 配置；
               OPA0 输出经内部连到 ADC_CH0（用户手册表5-11：ADC_CHNx=0000 -> OPA0 Output，
               用户已确认本板 OPA0 输出即接 ADC_CH0），无需外部走线、也无需 OPA_OUT() 引到 P2.7。 ---- */
    OPA_StructInit(&OPA_InitStruct);
    OPA_InitStruct.OPA_CLEna = ENABLE;       /* 使能 OPA0 闭环 */
    OPA_InitStruct.OPA_Gain  = PWM_ADC_OPA_GAIN;
    OPA_InitStruct.OPA_SHT   = DISABLE;      /* 正常运行不短路输入 */
    OPA_Init(OPA0, &OPA_InitStruct);

    /* ---- 2. ADC 初始化：软件触发、单段、左对齐、3.6V 量程、48M 时钟、采样20周期；
               不使用 ADC 中断（38K 轮询读取）。 ---- */
    ADC_StructInit(&ADC_InitStructure);
    ADC_InitStructure.Align        = ADC_LEFT_ALIGN;     /* 左对齐（同例程） */
    ADC_InitStructure.Trigger_Mode = ADC_1SEG_TRG;       /* 单段 */
    ADC_InitStructure.FirSeg_Ch    = PWM_ADC_OVERSAMPLE; /* 运行时单段采样次数=过采样数 */
    ADC_InitStructure.Trigger_Cnt  = 0;                  /* 一次触发执行一段 */
    ADC_InitStructure.IE           = 0;                  /* 关闭 ADC 中断，纯轮询 */
    ADC_InitStructure.Gain         = ADC_RANGE_3V6;      /* 3.6V 量程（=0；同例程默认），内部据此载入 DC/AMC */
    ADC_InitStructure.ADC_CLK_SEL  = ADC_CLK_48M;        /* 48M 时钟（同例程，转换更快） */
    ADC_InitStructure.ADC_SAMP_CLK = 20;                 /* 20 个 ADC 时钟采样 */
    ADC_Init(ADC0, &ADC_InitStructure);                   /* 内部自动载入 DC/AMC 工厂校准 */
    ADC_ClearIRQFlag(ADC0, ADC_ALL_IRQ_IF);

    /* ---- 3. 运行时状态复位 ---- */
    g_adc_trig_ch = 0;
    g_adc_started = 0;
    g_adc_code[0] = 0; g_adc_code[1] = 0;
    g_adc_new[0]  = 0; g_adc_new[1]  = 0;
    g_adc_diff_offset = 0;
    g_adc_ch7_offset  = 0;
}

/*******************************************************************************
 函数名称：    u8 PWM_ADC_OffsetCalibration(void)
 功能描述：    软件零点校准。须在 PWM_ADC_Init 之后、开中断之前调用。
               - OPA0 差分通道：内部短路 IP/IN，采样 PWM_ADC_CALIB_CNT 次求平均作为零点。
               - CH7 单端通道：调用时须确保步进电流为 0A，采样求平均作为零点。
               若某次软件触发后 EOS0 超时未置位，返回 1，防止系统卡死在校准循环。
 注意事项：    关闭总中断后调用；本函数内部会临时改变 ADC 通道，退出前会复位到第 0 路。
 *******************************************************************************/
u8 PWM_ADC_OffsetCalibration(void)
{
    s32 diff_acc = 0;
    s32 ch7_acc  = 0;
    u16 i;
    volatile u32 timeout;

    /* 1) OPA0 差分通道：短路 IP/IN，测量 OPA0 自身失调 */
    OPA_Intput_SHT(OPA0, ENABLE);
    SoftDelay(100);                      /* 延时约 100us，等待 OPA0 短路输入建立稳定 */
    ADC_ConfigSeg(PWM_ADC_CH_DIFF);
    for (i = 0; i < PWM_ADC_CALIB_CNT; i++)
    {
        ADC_SoftTrgEN(ADC0, ENABLE);
        timeout = 100000u;               /* @96MHz 约 1ms，远大于一次 8 次采样所需时间 */
        while (!ADC_GetIRQFlag(ADC0, ADC_EOS0_IRQ_IF))
        {
            if (--timeout == 0u)
            {
                OPA_Intput_SHT(OPA0, DISABLE);
                return 1;                /* OPA0 校准超时 */
            }
        }
        ADC_ClearIRQFlag(ADC0, ADC_EOS0_IRQ_IF);
        diff_acc += (s32)ADC_GetConversionValue(DAT0);
    }
    OPA_Intput_SHT(OPA0, DISABLE);
    g_adc_diff_offset = diff_acc / (s32)PWM_ADC_CALIB_CNT;

    /* 2) CH7 单端通道：校准期间步进电机必须未使能、无电流 */
    ADC_ConfigSeg(PWM_ADC_CH_CH7);
    for (i = 0; i < PWM_ADC_CALIB_CNT; i++)
    {
        ADC_SoftTrgEN(ADC0, ENABLE);
        timeout = 100000u;
        while (!ADC_GetIRQFlag(ADC0, ADC_EOS0_IRQ_IF))
        {
            if (--timeout == 0u)
            {
                return 2;                /* CH7 校准超时 */
            }
        }
        ADC_ClearIRQFlag(ADC0, ADC_EOS0_IRQ_IF);
        ch7_acc += (s32)ADC_GetConversionValue(DAT0);
    }
    g_adc_ch7_offset = ch7_acc / (s32)PWM_ADC_CALIB_CNT;

    /* 3) 复位到第 0 路，让 38KStep 的第一次触发走正常流程 */
    g_adc_started = 0;
    g_adc_trig_ch = 0;

    return 0;                            /* 校准成功 */
}

/*******************************************************************************
 函数名称：    void PWM_ADC_38KStep(void)
 功能描述：    每个 38K tick 调用：
               1) 若已触发过，先读回“上一 tick 触发那一路”的 N 次过采样结果并求平均
                  （差分通道再减零点偏移），存入对应 g_adc_code 并置新值标志；
               2) 触发“另一路”（首 tick 触发第 0 路），不等待转换，下次 tick 再读回。
               由此每路每 2 个 tick 采样一次 -> 有效采样率 = 38K/2 = 19K。
 *******************************************************************************/
void PWM_ADC_38KStep(void)
{
    u8 read_ch;

    /* 高速中断采样模式下，ADC 由 ISR 全速自触发，主循环轮询不再参与触发/读回。 */
    if (g_adc_hs_mode)
    {
        return;
    }

    /* ---- 1. 读回上一 tick 触发那一路的结果（若有） ---- */
    if (g_adc_started)
    {
        read_ch = g_adc_trig_ch;
        {
            u8  i;
            s32 acc = 0;
            for (i = 0; i < PWM_ADC_OVERSAMPLE_N; i++)
            {
                /* LKS32MC05x 的差分 ADC/PGA 输出为左对齐有符号值，官方例程用 s16 读取。
                   若用 u16 读，负值(如反向电流、接近零点的噪声)会被解释成巨大正数。 */
                s16 raw = ADC_GetConversionValue((DATx)i);   /* DAT0..DAT(N-1) */
                acc += (s32)raw;
            }
            {
                s32 avg = (s32)(acc / (s32)PWM_ADC_OVERSAMPLE_N);
                if (read_ch == 0)
                {
                    /* 差分通道：先记原始 RAW，再减软件零偏；实际电流无反向，噪声负值钳 0 */
                    g_adc_diff_last_raw = (u32)avg;   /* 调试：记下无刷 RAW 平均 code（减偏前） */
                    avg -= g_adc_diff_offset;
                    if (avg < 0) avg = 0;
                    g_adc_code[read_ch] = avg;
                }
                else
                {
                    /* CH7 单端：先记原始 RAW，再减软件零偏；步进电流单极性，噪声负值钳 0 */
                    g_adc_ch7_last_raw = (u32)avg;   /* 调试：记下 CH7 RAW 平均 code（减偏前） */
                    avg -= g_adc_ch7_offset;
                    if (avg < 0) avg = 0;
                    g_adc_code[read_ch] = avg;
                }
                g_adc_new[read_ch]  = 1;
            }
        }
        ADC_ClearIRQFlag(ADC0, ADC_EOS0_IRQ_IF);    /* 清扫描结束标志，便于下次触发 */
    }

    /* ---- 2. 触发“另一路”（首次触发第 0 路）---- */
    {
        u8  next    = g_adc_started ? (u8)(1u - g_adc_trig_ch) : 0u;
        u16 adc_ch  = (next == 0) ? PWM_ADC_CH_DIFF : PWM_ADC_CH_CH7;

        ADC_ConfigSeg(adc_ch);          /* 配置单段连续采样 N 次该通道 */
        ADC_SoftTrgEN(ADC0, ENABLE);    /* 软件触发；不等待，下次 38K tick 再读回 */

        g_adc_trig_ch = next;
        g_adc_started = 1;
    }
}

/*******************************************************************************
 函数名称：    void PWM_ADC_StartHighSpeedSampling(void)
 功能描述：    启动 ADC 高速轮询采样（无中断）。
               配置14次过采样（DIFF/CH7 交错），由主循环38K节拍软件触发+轮询EOS0。
               每次触发后 ADC 硬件自动完成14次转换（≈4.4μs@48MHz），主循环读结果。
               不使用 ADC 中断，零抢占延迟。
 *******************************************************************************/
void PWM_ADC_StartHighSpeedSampling(void)
{
    u8 wr;

    g_adc_hs_mode = 1;
    g_bldc_peak_code = 0;
    g_step_peak_code = 0;
    g_adc_sample_cnt = 0;
    g_adc_sample_buf_wr = 0;
    for (wr = 0; wr < 2; wr++)
    {
        u8 i;
        for (i = 0; i < PWM_ADC_HS_SAMPLES_PER_CH; i++)
        {
            g_adc_bldc_samples[wr][i] = 0;
            g_adc_step_samples[wr][i] = 0;
        }
    }

    /* 软复位 ADC 状态机，配置为软件触发（不使用硬件触发） */
    ADC0->CFG = (1u << 11);   /* FSM_RESET = 1 */
    ADC0->CFG = (ADC_LEFT_ALIGN << 10) |      /* 左对齐 */
                (ADC_1SEG_TRG << 8);          /* 单段，软件触发 */
    ADC0->CHNT = (u32)PWM_ADC_HS_OVERSAMPLE_N; /* 单段 14 次采样 */

    /* 14 个采样槽交错放置 DIFF 和 CH7：
       DAT0/DAT2/.../DAT12 = DIFF；DAT1/DAT3/.../DAT13 = CH7 */
    ADC_ChannelConfig(ADC0, CHN0, PWM_ADC_CH_DIFF, PWM_ADC_CH_CH7, PWM_ADC_CH_DIFF, PWM_ADC_CH_CH7);
    ADC_ChannelConfig(ADC0, CHN1, PWM_ADC_CH_DIFF, PWM_ADC_CH_CH7, PWM_ADC_CH_DIFF, PWM_ADC_CH_CH7);
    ADC_ChannelConfig(ADC0, CHN2, PWM_ADC_CH_DIFF, PWM_ADC_CH_CH7, PWM_ADC_CH_DIFF, PWM_ADC_CH_CH7);
    ADC_ChannelConfig(ADC0, CHN3, PWM_ADC_CH_DIFF, PWM_ADC_CH_CH7, PWM_ADC_CH_DIFF, PWM_ADC_CH_CH7);

    /* 清标志，不使能中断 */
    ADC_ClearIRQFlag(ADC0, ADC_EOS0_IRQ_IF);
    ADC0->IE = 0;   /* 不开 ADC 中断 */
}

/*******************************************************************************
 函数名称：    void PWM_ADC_StopHighSpeedSampling(void)
 功能描述：    停止 ADC 高速中断采样，关闭 EOS0 中断。
 *******************************************************************************/
void PWM_ADC_StopHighSpeedSampling(void)
{
    /* 软复位 ADC 状态机 */
    ADC_ClearIRQFlag(ADC0, ADC_EOS0_IRQ_IF);
    ADC0->CFG = (1u << 11);   /* FSM_RESET = 1 */
    ADC0->CFG = (ADC_LEFT_ALIGN << 10) | (ADC_1SEG_TRG << 8); /* 软件触发，单段模式 */
    ADC0->IE = 0;   /* 确保中断关闭 */

    g_adc_hs_mode = 0;
    g_adc_sample_cnt = 0;

    /* 复位轮询模式状态，以便切回 PWM_ADC_38KStep() 时从第 0 路重新开始 */
    g_adc_started = 0;
    g_adc_trig_ch = 0;
}

/*******************************************************************************
 函数名称：    void PWM_ADC_IRQHandler(void)
 功能描述：    已废弃：ADC 改为软件触发+轮询，不再使用中断。
               保留空函数避免链接警告。
 *******************************************************************************/
void PWM_ADC_IRQHandler(void)
{
    /* 废弃：改由 PWM_ADC_PollExec() 轮询处理 */
}

/*******************************************************************************
 函数名称：    void PWM_ADC_PollExec(void)
 功能描述：    38K 主循环节拍调用：软件触发 ADC 14次过采样 + 轮询 EOS0 + 读结果。
               替代原 ADC0 中断方案，消除 ADC ISR 对 HALL 换相的抢占延迟。
               阻塞时间：14次转换 ≈ 4.4μs@48MHz（含20周期采样+12周期转换/次）。
               轮询 EOS0 超时 1000 次（≈10μs）后放弃，避免卡死主循环。
 *******************************************************************************/
void PWM_ADC_PollExec(void)
{
    u8   i;
    u8   wr;
    s32  diff_off = g_adc_diff_offset;
    s32  ch7_off  = g_adc_ch7_offset;
    u32  bldc_peak = 0;
    u32  step_peak = 0;
    volatile u32 *dat = (volatile u32 *)&ADC0->DAT0;
    u32  code;
    s32  sv;
    volatile u32 timeout;

    if (g_adc_hs_mode == 0u) return;

    /* 先清 EOS0 标志（上次超时可能残留），再触发 */
    ADC0->IF |= ADC_EOS0_IRQ_IF;
    ADC_SoftTrgEN(ADC0, ENABLE);

    /* 轮询等待 EOS0（ADC 完成14次转换）*/
    timeout = 1000u;
    while (!(ADC0->IF & ADC_EOS0_IRQ_IF))
    {
        if (--timeout == 0u) return;   /* 超时放弃，避免卡死 */
    }
    ADC0->IF |= ADC_EOS0_IRQ_IF;      /* 清标志 */

    /* 读14个 DATx 结果，减偏移、钳0、记录峰值 */
    wr = g_adc_sample_buf_wr;
    for (i = 0; i < PWM_ADC_HS_SAMPLES_PER_CH; i++)
    {
        /* DIFF: DAT0/2/4/6/8/10/12 */
        sv = (s32)(s16)(dat[i * 2u] & 0xFFFFu) - diff_off;
        if (sv < 0) sv = 0;
        code = (u32)sv;
        g_adc_bldc_samples[wr][i] = code;
        if (code > bldc_peak) bldc_peak = code;

        /* CH7: DAT1/3/5/7/9/11/13 */
        sv = (s32)(s16)(dat[i * 2u + 1u] & 0xFFFFu) - ch7_off;
        if (sv < 0) sv = 0;
        code = (u32)sv;
        g_adc_step_samples[wr][i] = code;
        if (code > step_peak) step_peak = code;
    }

    if (bldc_peak > g_bldc_peak_code) g_bldc_peak_code = bldc_peak;
    if (step_peak > g_step_peak_code) g_step_peak_code = step_peak;

    g_adc_sample_buf_wr = (u8)(1u - wr);
    g_adc_sample_cnt++;
}

/*******************************************************************************
 函数名称：    u8 PWM_ADC_GetDiff(u32 *p_code)
 功能描述：    读取 OPA0 差分通道最新平均 code（已减零点偏移）；返回是否有新值。
               高速模式下从双缓冲懒计算 7 点平均，不在 ISR 内求平均。
 *******************************************************************************/
u8 PWM_ADC_GetDiff(u32 *p_code)
{
    static u16 last_cnt = 0;
    u16 cnt;
    u8  rd;
    u8  i;
    u8  is_new;
    s32 acc = 0;

    /* 低速轮询模式：沿用旧的 g_adc_code/g_adc_new 机制 */
    if (g_adc_hs_mode == 0)
    {
        is_new = g_adc_new[0];
        if (p_code != 0)
        {
            *p_code = (u32)g_adc_code[0];
        }
        g_adc_new[0] = 0;
        return is_new;
    }

    /* 高速中断模式：从双缓冲读取 7 点原始数据并求平均 */
    cnt = g_adc_sample_cnt;
    if (cnt == last_cnt)
    {
        return 0;
    }

    rd = 1u - g_adc_sample_buf_wr;          /* 最新完成的一帧存在非 ISR 写缓冲 */
    for (i = 0; i < PWM_ADC_HS_SAMPLES_PER_CH; i++)
    {
        acc += (s32)g_adc_bldc_samples[rd][i];
    }

    if (p_code != 0)
    {
        *p_code = (u32)(acc / (s32)PWM_ADC_HS_SAMPLES_PER_CH);
    }
    last_cnt = cnt;
    return 1;
}

/*******************************************************************************
 函数名称：    u8 PWM_ADC_GetCh7(u32 *p_code)
 功能描述：    读取 P0.3/CH7 最新平均 code；返回是否有新值。
               高速模式下从双缓冲懒计算 7 点平均，不在 ISR 内求平均。
 *******************************************************************************/
u8 PWM_ADC_GetCh7(u32 *p_code)
{
    static u16 last_cnt = 0;
    u16 cnt;
    u8  rd;
    u8  i;
    u8  is_new;
    s32 acc = 0;

    /* 低速轮询模式：沿用旧的 g_adc_code/g_adc_new 机制 */
    if (g_adc_hs_mode == 0)
    {
        is_new = g_adc_new[1];
        if (p_code != 0)
        {
            *p_code = (u32)g_adc_code[1];
        }
        g_adc_new[1] = 0;
        return is_new;
    }

    /* 高速中断模式：从双缓冲读取 7 点原始数据并求平均 */
    cnt = g_adc_sample_cnt;
    if (cnt == last_cnt)
    {
        return 0;
    }

    rd = 1u - g_adc_sample_buf_wr;
    for (i = 0; i < PWM_ADC_HS_SAMPLES_PER_CH; i++)
    {
        acc += (s32)g_adc_step_samples[rd][i];
    }

    if (p_code != 0)
    {
        *p_code = (u32)(acc / (s32)PWM_ADC_HS_SAMPLES_PER_CH);
    }
    last_cnt = cnt;
    return 1;
}

/*******************************************************************************
 函数名称：    u8 PWM_ADC_GetBldcSamples(u32 *buf, u8 buf_len)
 功能描述：    读取最近一次 38kHz 触发得到的 7 个无刷电流原始 code（已减零偏、钳 0）。
               返回实际有效点数；buf 长度须 >= PWM_ADC_HS_SAMPLES_PER_CH。
               若当前无新数据则返回 0。
 *******************************************************************************/
u8 PWM_ADC_GetBldcSamples(u32 *buf, u8 buf_len)
{
    static u16 last_cnt = 0;
    u16 cnt;
    u8  rd;
    u8  i;

    if (buf == 0 || buf_len < PWM_ADC_HS_SAMPLES_PER_CH)
    {
        return 0;
    }

    cnt = g_adc_sample_cnt;
    if (cnt == last_cnt)
    {
        return 0;
    }

    rd = 1u - g_adc_sample_buf_wr;
    for (i = 0; i < PWM_ADC_HS_SAMPLES_PER_CH; i++)
    {
        buf[i] = g_adc_bldc_samples[rd][i];
    }
    last_cnt = cnt;
    return PWM_ADC_HS_SAMPLES_PER_CH;
}

/*******************************************************************************
 函数名称：    u8 PWM_ADC_GetStepSamples(u32 *buf, u8 buf_len)
 功能描述：    读取最近一次 38kHz 触发得到的 7 个步进电流原始 code（已减零偏、钳 0）。
               返回实际有效点数；buf 长度须 >= PWM_ADC_HS_SAMPLES_PER_CH。
               若当前无新数据则返回 0。
 *******************************************************************************/
u8 PWM_ADC_GetStepSamples(u32 *buf, u8 buf_len)
{
    static u16 last_cnt = 0;
    u16 cnt;
    u8  rd;
    u8  i;

    if (buf == 0 || buf_len < PWM_ADC_HS_SAMPLES_PER_CH)
    {
        return 0;
    }

    cnt = g_adc_sample_cnt;
    if (cnt == last_cnt)
    {
        return 0;
    }

    rd = 1u - g_adc_sample_buf_wr;
    for (i = 0; i < PWM_ADC_HS_SAMPLES_PER_CH; i++)
    {
        buf[i] = g_adc_step_samples[rd][i];
    }
    last_cnt = cnt;
    return PWM_ADC_HS_SAMPLES_PER_CH;
}

/*******************************************************************************
 * 函数名称：    void PWM_ADC_Ch7Debug(u32 *p_raw_avg, u32 *p_offset)
 * 功能描述：    【临时调试】返回 CH7 最近一次“减偏前”的原始平均 code 与零偏，
 *             供遥测打印，用于定位 I_STEP 读数偏小：若原始电压≈750mV 说明信号链路正常，
 *             若明显偏低则说明 P0.3 实际进来的电压不足 0.75V（模拟前端问题）。
 *             定位完成后应删除本函数及其在遥测中的调用。
 *******************************************************************************/
void PWM_ADC_Ch7Debug(u32 *p_raw_avg, u32 *p_offset)
{
    if (p_raw_avg != 0) *p_raw_avg = g_adc_ch7_last_raw;
    if (p_offset  != 0) *p_offset  = (u32)g_adc_ch7_offset;
}

/*******************************************************************************
 * 函数名称：    void PWM_ADC_DiffDebug(u32 *p_raw_avg)
 * 功能描述：    调试辅助：返回无刷(OPA0 差分)通道最近一次原始平均 code(RAW)。
 *             仅用于遥测日志打印定位无刷风机电流读数，定位完成后可删除。
 *******************************************************************************/
void PWM_ADC_DiffDebug(u32 *p_raw_avg)
{
    if (p_raw_avg != 0) *p_raw_avg = g_adc_diff_last_raw;
}

/*******************************************************************************
 函数名称：    s32 PWM_ADC_CodeToVolt_mV(s32 code)
 功能描述：    把平均 code 换算为电压(mV)，量程 3.6V：mV = code * 3600 / 0x7FF0
 *******************************************************************************/
s32 PWM_ADC_CodeToVolt_mV(s32 code)
{
    /* 左对齐 ADC 输出为 signed，负 code 对应低于 0V；按有符号线性换算：
       code = 0x7FF0 -> 3600mV；code = 0 -> 0mV；code < 0 -> 负电压。 */
    return (code * (s32)PWM_ADC_RANGE_MV) / (s32)PWM_ADC_FULL_SCALE_CODE;
}

/*******************************************************************************
 函数名称：    s32 PWM_ADC_DiffInput_mV(s32 diff_code)
 功能描述：    把 OPA0 差分 code 换算为“差分输入电压”(mV) = OPA输出V / 增益
 *******************************************************************************/
s32 PWM_ADC_DiffInput_mV(s32 diff_code)
{
    /* Vin(mV) = Vout(mV) / 17.24；中间量 <=3600*100 不超 32 位 */
    s32 vout_mV = PWM_ADC_CodeToVolt_mV(diff_code);
    return (vout_mV * PWM_ADC_OPA_GAIN_DEN + (PWM_ADC_OPA_GAIN_NUM >> 1)) / PWM_ADC_OPA_GAIN_NUM;
}

/*******************************************************************************
 * 函数名称：    s32 PWM_ADC_DiffToCurrent_mA(s32 diff_code)
 * 功能描述：    把 OPA0 差分 code（已减零点偏移、有符号）换算为无刷相电流(mA)。
 *            分步整型(先乘后除+四舍五入)，规避负数 code 处理缺陷并避免中间量溢出：
 *              Vin(mV) = code * RANGE_MV * GAIN_DEN / (FULL_SCALE * GAIN_NUM)，Vin = OPAout / 增益
 *              I(A)    = Vin(mV) / Rs(mΩ)            （mV/mΩ 单位即为 A）
 *              I(mA)   = I(A) * 1000 = Vin(mV) * 1000 / Rs(mΩ)
 *******************************************************************************/
s32 PWM_ADC_DiffToCurrent_mA(s32 diff_code)
{
    /* 优化：把 3 次除法降为“1 次移位 + 1 次除法”，误差 < 0.1%（电流阈值判定在 ~20A 级，无影响）。
       原整型分步(3 次除法)：
           u32 v = (u32)diff_code;
           v = (v*3600 + 16376)/32752;   // Vout(mV)  ÷32752
           v = (v*100  + 862 )/1724;    // Vin(mV)   ÷1724
           v = (v*1000 + 12  )/25;      // I(mA)     ÷25
           return (s32)v;
       推导：3600/32752 = 225/2047（2047=2^11-1，故 ÷2047 ≈ >>11 移位近似，误差~0.05%）；
             Vout*100/1724 与 Vin*1000/25 合并为 Vout*1000/431（1724*25=43100，100*1000=100000 → 1000/431，精确）。
       故 I(mA) = ((code*225) >> 11) * 1000 / 431。 */
    /* 实际硬件无反向电流，但按有符号运算更稳妥；分两步整型除法，中间量不溢出：
       Vout(mV) = code * 3600 / 0x7FF0，再 I(mA) = Vout * 1000 / 431 */
    s32 code = diff_code;
    s32 vout_mV = (code * (s32)PWM_ADC_RANGE_MV) / (s32)PWM_ADC_FULL_SCALE_CODE;
    return (vout_mV * 1000) / 431;
}

/*******************************************************************************
 * 函数名称：    s32 PWM_ADC_Ch7ToCurrent_mA(s32 ch7_code)
 * 功能描述：    把 P0.3/CH7 code（单端、非负）换算为步进相电流(mA)。
 *            外部运放已放大 100 倍：Vadc = I * Rs * 100，故
 *              I(A)  = Vadc(mV) / (100 * Rs_mΩ)
 *              I(mA) = Vadc(mV) * 1000 / (100 * Rs_mΩ)
 *******************************************************************************/
s32 PWM_ADC_Ch7ToCurrent_mA(s32 ch7_code)
{
    /* 优化：原 2 次除法降为“1 次移位”(纯移位，0 次除法)，误差 < 0.2%。
       原整型分步(2 次除法)：
           u32 v = (u32)ch7_code;
           v = (v*3600 + 16376)/32752;   // Vadc(mV)  ÷32752
           v = (v*1000 + 1250 )/2500;   // I(mA)     ÷2500  (2500=EXT_GAIN*RSHUNT=100*25)
           return (s32)v;
       推导：3600/32752 × 1000/(100*25) = 225/2047 × 2/5 = 90/2047
             （2047=2^11-1，故 ÷2047 ≈ >>11 移位近似，误差~0.05%）。
       故 I(mA) = (code*90) >> 11。 */
    /* CH7 在 PWM_ADC_IRQHandler 中已钳为非负；此处按有符号处理，即使传入负数也不会出异常大数 */
    s32 code = ch7_code;
    if (code < 0) code = 0;
    s32 vadc_mV = (code * (s32)PWM_ADC_RANGE_MV) / (s32)PWM_ADC_FULL_SCALE_CODE;
    return (vadc_mV * 1000) / 2500;          /* 2500 = EXT_GAIN(100) * RSHUNT_mΩ(25) */
}

/*******************************************************************************
 * 函数名称：    u32 PWM_ADC_GetBldcPeakCode(void)
 * 函数名称：    u32 PWM_ADC_GetAndClearBldcPeakCode(void)
 * 函数名称：    u32 PWM_ADC_GetStepPeakCode(void)
 * 函数名称：    u32 PWM_ADC_GetAndClearStepPeakCode(void)
 * 功能描述：    获取无刷/步进电流的峰值 code。
 *             Get 只读取不清零；GetAndClear 读取并清零，便于保护模块按窗口重新统计。
 *             注意：在 Cortex-M0 单核且无并发除法的情况下，对 32 位变量的读/写天然原子，
 *             故无需额外关中断；保护模块应在读取后立即处理或再次查询。
 *******************************************************************************/
u32 PWM_ADC_GetBldcPeakCode(void)
{
    return g_bldc_peak_code;
}

u32 PWM_ADC_GetAndClearBldcPeakCode(void)
{
    u32 peak = g_bldc_peak_code;
    g_bldc_peak_code = 0;
    return peak;
}

u32 PWM_ADC_GetStepPeakCode(void)
{
    return g_step_peak_code;
}

u32 PWM_ADC_GetAndClearStepPeakCode(void)
{
    u32 peak = g_step_peak_code;
    g_step_peak_code = 0;
    return peak;
}

/************************ (C) COPYRIGHT LINKO SEMICONDUCTOR *****END OF FILE****/
