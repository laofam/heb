/*******************************************************************************
 * 版权所有 (C)2021, LINKO SEMICONDUCTOR Co.ltd
 *
 * 文件名称： adc_sample.h
 * 文件标识：
 * 内容摘要： 两路 ADC 采样模块头文件（OPA0 差分放大 + P0.3/ADC_CH7，38K 交替采样）
 * 其它说明： 无
 * 当前版本： V 1.0
 * 作    者： AutoGen
 * 完成日期： 2026年7月20日
 *
 * 设计要点（详见 程序说明.md “三、两路 ADC 采样”）：
 *   - 通道 A(PWM_ADC_CH_DIFF = ADC_CH0)：P1.14(OPA0_IP) 与 P1.15(OPA0_IN) 之间的差分信号，
 *     经片内 OPA0 差分放大（增益 PWM_ADC_OPA_GAIN，表5-11 中 ADC_CH0 = OPA0 Output）后送 ADC。
 *     信号最大 100mV；上电时调用 PWM_ADC_OffsetCalibration() 短路 OPA0 输入做软件零点校准。
 *   - 通道 B(PWM_ADC_CH_CH7 = ADC_CH7)：P0.3，外部已放大(×100)，直接采样，无 OPA。
 *     上电时步进未使能、无电流，调用 PWM_ADC_OffsetCalibration() 采样 CH7 零点做软件校准。
 *   - 运行时用 TIMER3 CH0 比较事件（38kHz）硬件触发 ADC，每次触发单段 14 次采样：
 *     DAT0/2/4/6/8/10/12 为 OPA0 差分，DAT1/3/5/7/9/11/13 为 CH7。
 *     ADC 自己完成全部 14 次转换，完成后产生 EOS0 中断；ISR 只做搬运/最大值比较，
 *     不在 ISR 内求平均，主程序可读取原始采样数据自行处理。
 *   - PWM_ADC_38KStep() 在启用高速中断采样后不再执行实际采样，仅保留接口兼容。
 *   - ISR 中同步维护 g_adc_code[] / g_adc_new[] 和两路电流峰值 code；
 *     同时把最新 14 个原始采样值放入双缓冲，主程序可取走做平均/FFT/故障分析。
 *
 * 修改日期      版本号          修改人            修改内容
 -----------------------------------------------------------------------------
 2026/7/20     V1.0           AutoGen           创建（OPA0差分 + CH7 两路 38K 交替采样）
 *******************************************************************************/
#ifndef __ADC_SAMPLE_H
#define __ADC_SAMPLE_H

#include "hardware_config.h"
#include "lks32mc05x_adc.h"
#include "lks32mc05x_opa.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ============================ 配置宏 ============================ */
/* 硬件过采样次数：每次 38K 触发让 ADC 单段连续采样 N 次同一通道，再软件平均。
   38K tick ≈ 26.3us；ADC 48M 时钟 + 20 采样周期下，单次转换约 0.7us，
   N=8 约 5.6us、N=16 约 11us，均远小于 26.3us，故可在 38K 预算内尽量提高精度。
   CHNT 字段为 4bit，安全上限取 8（如需更激进可改 16，请确认 CHNT 支持）。 */
#define PWM_ADC_OVERSAMPLE_N     ((u8)8)
#define PWM_ADC_OVERSAMPLE       ((u16)PWM_ADC_OVERSAMPLE_N)

/* 高速中断采样模式的单段采样次数：
   用 TIMER3 CH0 比较事件（38kHz）作为 ADC 硬件触发源，每次触发让 ADC
   自己连续采样 14 次（7 次 OPA0 差分 + 7 次 CH7 交错存放）。
   手册规定 ADC_CHNT.S1 为 4bit、取值 1~15 对应 1~15 次；取 14 次既保证两路对称，
   又避免写 16 实际落入 0 次的非法配置。
   ISR 每 26.3us 进入一次，只做数据搬运/比较，不在 ISR 内求平均；
   主程序可读取原始采样数据自行处理。 */
#define PWM_ADC_HS_OVERSAMPLE_N  ((u8)14)
#define PWM_ADC_HS_SAMPLES_PER_CH ((u8)7)   /* 14 次采样中每路各占 7 次 */

/* OPA0 差分增益选择（lks32mc05x_opa.h）：
   PGA_GAIN_20 = 内部反馈电阻 200k:10.6k。实际闭环增益 = Rf/(Rg + R_ext)，
   其中 R_ext 为外部匹配电阻(kΩ)。用户确认本板 OPA0 外部匹配电阻 R_ext = 1k，
   故实际增益 = 200/(10.6+1) = 200/11.6 ≈ 17.241（保留 17.24）。
   增益数值仅用于 PWM_ADC_DiffInput_mV() 电压换算，不影响采样本身。
   若差分信号为“以 0 为中心的双极性 ±100mV”，峰值输出可能越界削顶，
   应改 PGA_GAIN_9P5 以留裕量。 */
#define PWM_ADC_OPA_GAIN         PGA_GAIN_20
#define PWM_ADC_OPA_GAIN_NUM     ((s32)1724)   /* 200/11.6 = 17.24（R_ext=1k） */
#define PWM_ADC_OPA_GAIN_DEN     ((s32)100)

/* ADC 量程（3.6V，对应 ADC_Init Gain=0/ADC_RANGE_3V6，同例程）；左对齐满量程 code 约定 0x7FF0 */
#define PWM_ADC_RANGE_MV         ((s32)3600)
#define PWM_ADC_FULL_SCALE_CODE  ((s32)0x7FF0)

/* 电流换算参数（两路检流电阻均为 25 毫欧）：
   - 无刷（通道 A / OPA0 差分）：检流电阻两端电压 Vin = I * 25mΩ，经片内 OPA0（增益见上）放大后送 ADC；
     电流 = Vin / 25mΩ。
   - 步进（通道 B / P0.3/CH7）：外部运放已放大 100 倍后送单片机，
     即 Vadc = I * 25mΩ * 100；电流 = Vadc / (100 * 25mΩ)。 */
#define PWM_ADC_RSHUNT_MOHM        ((s32)25)    /* 检流电阻 25 mΩ（= 0.025 Ω） */
#define PWM_ADC_STEPPER_EXT_GAIN   ((s32)100)   /* 步进电机外部运放放大倍数（100x） */

/* 两路物理通道（与引脚一一对应）
   通道 A：OPA0 输出。用户手册表 5-11 明确“0000=OPA0 Output”(即 CH0)，
   用户已确认本板 OPA0 输出即接在 ADC_CH0，故选 ADC_CHANNEL_0。
   （注：SDK 自带 OPA 例程用 ADC_CHANNEL_1 采样 OPA0 输出，与其板子相关；
    本板以用户确认 / 手册表5-11 为准用 CH0。） */
#define PWM_ADC_CH_DIFF   ADC_CHANNEL_0   /* OPA0 输出（P1.14/IP 与 P1.15/IN 差分放大后） */
#define PWM_ADC_CH_CH7    ADC_CHANNEL_7   /* P0.3，外部已放大，直接采样 */

/* 偏移校准采样次数：上电初始化时短路/零电流采样 512 次求平均作为软件零偏。 */
#define PWM_ADC_CALIB_CNT  ((u16)512)

/* ============================ 对外接口 ============================ */
/* 初始化 OPA0(差分放大) + ADC(软件触发/单段/过采样)。
   注意：须在中端关闭的硬件初始化期(Hardware_init)调用，本函数内部不自行开关总中断。 */
void PWM_ADC_Init(void);

/* 软件零点校准：须在 PWM_ADC_Init 之后、开中断之前调用。
   - OPA0 差分通道：内部短路 IP/IN，采样 PWM_ADC_CALIB_CNT 次求平均作为零点。
   - CH7 单端通道：调用时须确保步进电流为 0A，采样求平均作为零点。
   返回 0 表示成功；返回 1 表示某次触发后 EOS0 超时未置位（ADC 未响应）。 */
u8 PWM_ADC_OffsetCalibration(void);

/* 启动 ADC 高速中断自触发采样。须在 PWM_ADC_OffsetCalibration 之后、开中断之前调用。
   启动后 ADC 由 EOS0 中断全速交替采样两路，并在 ISR 中维护峰值；主循环无需再调用 PWM_ADC_38KStep()。 */
void PWM_ADC_StartHighSpeedSampling(void);

/* 停止 ADC 高速中断采样（如需切回 38K 轮询模式可调用）。 */
void PWM_ADC_StopHighSpeedSampling(void);

/* ADC 中断服务程序入口（已废弃，改为轮询） */
void PWM_ADC_IRQHandler(void);

/* ADC 轮询执行：软件触发14次过采样+轮询EOS0+读结果。由38K主循环节拍调用。 */
void PWM_ADC_PollExec(void);

/* 每个 38K tick 调用：读回“上一 tick 触发那一路”的过采样平均结果，并触发“另一路”。
   触发后不等待转换（下次 tick 才读回）。
   注意：启动高速中断采样后，本函数不再执行实际采样，仅保留兼容。 */
void PWM_ADC_38KStep(void);

/* 读取 OPA0 差分通道最新平均 code（已减零点偏移、已钳为非负）；返回 1=有新值(并写入 *p_code)，0=无新值。 */
u8  PWM_ADC_GetDiff(u32 *p_code);
/* 读取 P0.3/CH7 最新平均 code；返回 1=有新值，0=无新值。 */
u8  PWM_ADC_GetCh7(u32 *p_code);

/* 【临时调试】返回 CH7 减偏前原始平均 code 与零偏，供遥测定位 I_STEP 偏小。定位后删除。 */
void PWM_ADC_Ch7Debug(u32 *p_raw_avg, u32 *p_offset);
void PWM_ADC_DiffDebug(u32 *p_raw_avg);

/* 把平均 code 换算为电压(mV)，量程 3.6V：mV = code * 3600 / 0x7FF0 */
s32 PWM_ADC_CodeToVolt_mV(s32 code);
/* 把 OPA0 差分 code 换算为“差分输入电压”(mV) = OPA输出V / 增益 */
s32 PWM_ADC_DiffInput_mV(s32 diff_code);

/* 把 OPA0 差分 code 换算为无刷相电流(mA)：I = Vin/Rs，Vin = OPAout/增益，
   diff_code 为已减零点偏移的非负值。 */
s32 PWM_ADC_DiffToCurrent_mA(s32 diff_code);
/* 把 P0.3/CH7 code 换算为步进相电流(mA)：外部已×100，I = (Vadc/100)/Rs = Vadc/(100*25mΩ)。 */
s32 PWM_ADC_Ch7ToCurrent_mA(s32 ch7_code);

/* 峰值电流 code 接口：ISR 高速采样过程中持续更新两路最大值，供过流保护模块使用。
   Get 只读取不清零；GetAndClear 读取并原子清零，便于保护模块按窗口统计。 */
u32 PWM_ADC_GetBldcPeakCode(void);
u32 PWM_ADC_GetAndClearBldcPeakCode(void);
u32 PWM_ADC_GetStepPeakCode(void);
u32 PWM_ADC_GetAndClearStepPeakCode(void);

/* 原始采样数据接口：读取最近一次 38kHz 触发得到的 14 个原始 code（已减零偏、钳 0）。
   返回实际有效点数（=PWM_ADC_HS_SAMPLES_PER_CH），buf 长度须 >= PWM_ADC_HS_SAMPLES_PER_CH。
   若当前无新数据则返回 0。 */
u8 PWM_ADC_GetBldcSamples(u32 *buf, u8 buf_len);
u8 PWM_ADC_GetStepSamples(u32 *buf, u8 buf_len);

#ifdef __cplusplus
}
#endif

#endif /* __ADC_SAMPLE_H */

/************************ (C) COPYRIGHT LINKO SEMICONDUCTOR *****END OF FILE****/
