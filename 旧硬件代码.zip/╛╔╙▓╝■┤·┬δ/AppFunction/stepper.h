/*******************************************************************************
 * 文件名称： stepper.h
 * 文件标识：
 * 内容摘要： 35BYJ46 四相五线单极步进电机 GPIO 驱动（半步八拍）
 * 其它说明： 引脚高电平 = 对应相导通（外部 MOS/三极管驱动）；若硬件逻辑相反，将
 *           宏中的 1/0 互换即可（或调用 Stepper_InvertLogic()）。
 * 当前版本： V 1.0
 * 作    者： AutoGen
 * 完成日期： 2026年7月20日
 *******************************************************************************/
#ifndef __STEPPER_H
#define __STEPPER_H

#include "hardware_config.h"
#include "lks32mc05x_gpio.h"

/* ============================ 相位 -> 引脚映射（用户指定） ============================
   COM(红) 接 12V；橙=A、黄=B、粉=C、蓝=D。
   P2.9=A、P2.10=B、P0.9=C、P0.10=D；GPIO 高电平 -> 外部驱动管导通 -> 该相线圈通电。 */
#define STEPPER_A_GPIO   GPIO2
#define STEPPER_A_PIN    GPIO_Pin_9     /* P2.9  -> A 相(橙) */
#define STEPPER_B_GPIO   GPIO2
#define STEPPER_B_PIN    GPIO_Pin_10    /* P2.10 -> B 相(黄) */
#define STEPPER_C_GPIO   GPIO0
#define STEPPER_C_PIN    GPIO_Pin_9     /* P0.9  -> C 相(粉) */
#define STEPPER_D_GPIO   GPIO0
#define STEPPER_D_PIN    GPIO_Pin_10    /* P0.10 -> D 相(蓝) */

/* ============================ 步进节拍分频 ============================
   主循环每个 38K tick（≈26.3us）调用 Stepper_Tick() 一次；每 g_step_div 个 38K tick 走一步：
   - 单步(单状态)持续时间 = g_step_div / 38000 秒，纯整数运算，无任何浮点。
   - 每步时长由 Stepper_SetStepPeriodTicks() 设置（当前由 P2.3 命令控制）。
   - 速度档位（每相 ms）：慢速 STEPPER_PHASE_MS_SLOW(2ms) / 快速 STEPPER_PHASE_MS_FAST(1ms)，
     均换算为 38K tick（STEPPER_TICKS_PER_MS 基准），编译期算好、运行时零除法；
   - 默认每步 = STEPPER_DIV_SLOW(2ms) 慢速起步。切勿长期用 1（堵转啸叫）。 */
#define STEPPER_PHASE_MS_SLOW   ((u16)2u)    /* 慢速档：每相 2ms（保留作 SetStepPeriodTicks 钳位上限） */
#define STEPPER_PHASE_MS_FAST   ((u16)1u)    /* 快速档：每相 1ms（保留作 SetStepPeriodTicks 钳位下限） */
#define STEPPER_TICKS_PER_MS    ((u16)38u)   /* 38K tick ≈ 1ms（基准，便于修改） */
#define STEPPER_DIV_SLOW        (STEPPER_TICKS_PER_MS * STEPPER_PHASE_MS_SLOW)  /* 76 */
#define STEPPER_DIV_FAST        (STEPPER_TICKS_PER_MS * STEPPER_PHASE_MS_FAST)  /* 38 */
#define STEPPER_DIV_DEFAULT     ((u16)57u)   /* 上电固定速度：1.5ms/步 = 38*1.5 = 57 tick（当前不再由 P2.3 调速） */



/* 运行模式 */
typedef enum {
    STEPPER_DIR_FWD  = 0,   /* 正转（顺时针）：步骤 1->8 循环 */
    STEPPER_DIR_REV  = 1,   /* 反转（逆时针）：步骤 8->1 循环 */
    STEPPER_DIR_STOP = 2    /* 停止：冻结当前相位（保留最后驱动状态），按停止占空比档位斩波/全导 */
} Stepper_Dir_TypeDef;

/* ============================ 步进斩波占空比（运行 / 停止 独立设置） ============================
   斩波 = 软件在每个 38K tick 对“当前导通相”做“导通/关断”交替，降低线圈平均电流 -> 降热。
   占空比 0~100(%)：100=全导(不斩波, 最大力矩/最热)；<100=按比例斩波(降热, 扭矩略降)。
   运行态与停止态必须独立设置：
     - 运行(正转/反转)时为保证不丢步，可保持较高占空比(默认 100=不斩波)；
     - 停止时负载轻，可更激进降热(默认 50%)。
   改下方两个宏即可，无需动逻辑。 */

/* 斩波周期(单位 = 38K tick)：周期越小斩波频率越高、占空比分辨率越粗。
   20 -> 38000/20 = 1.9kHz，分辨率 5%（=100/20）；想更细改大，想更高频改小。 */
#define STEPPER_CHOP_PERIOD   ((u8)20)

#define STEPPER_RUN_DUTY_PCT   ((u8)90)  /* 运行态斩波占空比(%)：默认 100=满导通不斩波(保扭矩)；想降热可调 70~90 */
#define STEPPER_STOP_DUTY_PCT  ((u8)50)   /* 停止态斩波占空比(%)：默认 50(明显降热)；可更低如 33 */

/* ============================ 对外接口 ============================ */
void Stepper_Init(void);                                 /* 配置 4 个 GPIO 为输出并输出第 1 步 */
void Stepper_SetDir(Stepper_Dir_TypeDef dir);           /* 设置 正转/反转/停止（下次 Tick 生效） */
void Stepper_SetStopDuty(u8 duty_pct);                  /* 设置停止态斩波占空比(%)（仅 STOP 时生效） */
void Stepper_SetRunDuty(u8 duty_pct);                   /* 设置运行态斩波占空比(%)（正转/反转时生效） */
void Stepper_SetStepPeriodTicks(u16 ticks);             /* 设置走步周期(38K tick 数)，由 P2.3 命令映射调用 */
void Stepper_Tick(void);                                 /* 每个 38K tick 调用一次：按 g_step_div 运行走步 / 停止斩波 */
void Stepper_AllOff(void);                               /* 四相全部关断（真正断电，释放转子）；用于堵转保护 */

/* ============================ 步进归位状态机接口（由 hardware_init.c 实现） ============================
   上电归位 + 正/反转到位霍尔(P0.14/P0.15 低有效) + 故障锁定；38K tick 驱动；详细状态见 hardware_init.c。 */
void StepperFSM_Init(void);   /* 上电调用：进入 BOOT_REV(反转归位) */
void StepperFSM_Tick(void);   /* 每 38K tick 调用：推进归位 FSM(含去抖/超时/故障)，并置 g_fan_enable 门控风机 */

#endif /* __STEPPER_H */

/************************ (C) COPYRIGHT LINKO SEMICONDUCTOR *****END OF FILE****/
