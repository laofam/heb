# 3MCPWM 程序说明

本文件说明当前工程程序的功能，以及本次新增的 **“基于 TIMER0/TIMER1(八分频) 的 PWM 高电平计时”** 功能。
芯片：LKS32MC054DF6Q8（内置 6N 预驱，主频 96MHz）。开发环境：Keil uVision（`LK_StdPeriph.uvprojx`）。

---

## 一、当前程序（原有功能）

### 1. 主流程 `Kernal_Source/main.c`
- `main()` 调用 `Hardware_init()` 完成硬件初始化，再进入 `DebugPWM_OutputFunction()`。
- `DebugPWM_OutputFunction()`：先让三相下管全部导通（给自举电容充电 2s），随后依据 `MOTOR_DIR` 重建霍尔查找表、以当前霍尔值建立基准并执行一次初始换相，使电机获得启动推力；之后主循环空闲，换相由 `HALL_IRQHandler` 完成。
- 调试信息经 **UART1（P0.7 TXD，115200-8-N-1，阻塞发送不关中断）** 输出，可用串口助手查看（SEGGER RTT 已彻底弃用，因其 Keil+M0 下 PRIMASK 全局关中断会屏蔽 HALL 换相中断导致无刷锁死）。

### 2. 硬件初始化 `AppFunction/hardware_init.c`
| 模块 | 说明 |
|------|------|
| `Clock_Init` / `SystemInit` | 开启 PLL，主频配置为 96MHz |
| `GPIO_init` | MCPWM 引脚(P1.4~P1.9)、HALL 引脚(P0.11~P0.13)、LED(P2.7)、38K 红外/播料驱动(P1.2、P0.4) 等 |
| `MCPWM_init` | 三相中心对齐互补 PWM，30kHz，带死区，支持预驱极性配置（`PRE_DRIVER_POLARITY`） |
| `UTimer_init` | TIMER2 / TIMER3 配置为 38K 比较输出（测料红外、播料电机） |
| `HALL_Perip_Init` | HALL 模块初始化（轮询采样 + 中断换相） |
| 中断使能 | `MCPWM_IRQn`、`HALL_IRQn`、`TIMER0_IRQn`、`TIMER1_IRQn` 已开启 |

### 3. 中断处理 `AppFunction/interrupt.c`
- `MCPWM_IRQHandler`：处理 MCPWM T0 更新 / FAIL1 急停事件。
- `HALL_IRQHandler`：HALL 捕获事件 -> 合法性校验（依据 `MOTOR_DIR` 生成的 `NEXT_MAP`）-> `HALL_ApplyCommutation()` 执行 6 步换相。
- `UTIMER0_IRQHandler`：调用 `PWM_HighLevel_Timer0IRQ()`（P2.3 硬件捕获）。
- `UTIMER1_IRQHandler`：调用 `PWM_HighLevel_Timer1IRQ()`（P2.4 / P2.5 硬件捕获）。
- 其余 `UTIMER2/3_IRQHandler` / `CMP_IRQHandler` / `UART*` / `GPIO_IRQHandler` 等：空壳或简单清标志。

---

## 二、新增功能：TIMER0/TIMER1(八分频) PWM 计时（三路高电平捕获 + P1.0 频率测量）（V1.4）

### 1. 需求
对 **P1.0 / P2.3 / P2.4 / P2.5** 四路引脚上的 PWM 信号，测量其**高电平持续时间**，要求：
- 使用 **TIMER0 八分频**作为计时基准（TIMER1 同样八分频，三路捕获时基一致）；
- 最大可测量 **100ms** 高电平；
- 当某引脚捕获到一个完整的 **“上升沿 -> 下降沿”** 组合后，调用该引脚对应的**空白回调函数**（留待后续实现具体业务逻辑）。

### 2. 硬件约束与方案选择（查阅 datasheet / 用户手册 / demo 后确认）
| 约束 | 出处 | 影响 |
|------|------|------|
| **外部中断 EXTI 仅支持 GPIO0**（P0.0~P0.15 才可作为外部中断源） | 用户手册 7.2.15 | P1.0/P2.x 无法产生 GPIO 中断，P1.0 只能轮询 |
| **TIMER0/TIMER1 为 16 位计数器，TIMER2/3 为 32 位** | 用户手册 10.3.4 | 测 100ms 需“溢出计数 + 16 位 CNT”扩展 64 位时间戳 |
| **引脚捕获复用**：P2.3=TIM0_CH1、P2.4=TIM1_CH0、P2.5=TIM1_CH1（复用 `AF7_TIMER01`） | 数据手册引脚复用表 | P2.3/2.4/2.5 可用 TIMER 硬件双沿捕获 |
| **P1.0 无 TIMER 捕获复用**（仅 WK / MCPWM_CH0N / UART0 / SPI） | 数据手册 | P1.0 无法硬件捕获，只能用 TIMER0 时基轮询 |

**结论（V1.4，P2.3/2.4/2.5 硬件捕获测高电平保持高精度；P1.0 原由 TIMER3 38K 中断轮询做“频率测量”，不干扰三路捕获；后为保证无刷电机与旧版“会转”工程一致，已关闭 TIMER3 过零中断，步进改由主循环轮询 TIMER3 计数驱动，P1.0/ADC 测量暂挂起）**：
- **P2.3** → TIMER0 CH1 双沿捕获；
- **P2.4** → TIMER1 CH0 双沿捕获；
- **P2.5** → TIMER1 CH1 双沿捕获；
- **P1.0** → 频率测量原本在 TIMER3 的 38K 过零中断里轮询电平实现（V1.4），因已关闭该中断，当前测量**暂停**；如需恢复可另起低频定时任务。接口 `PWM_HighLevel_GetP10Freq()` 仍保留。
- **两路 ADC**（V1.5）→ 原本在 TIMER3 的 38K 中断里由 `PWM_ADC_38KStep()` 交替采样（见“三、两路 ADC 采样”）；因已关闭该中断，当前采样**暂停**。通道定义与校准逻辑仍保留，恢复中断即可启用：通道 A = P1.14(OPA0_IP)/P1.15(OPA0_IN) 差分经 OPA0 放大送 ADC_CH0；通道 B = P0.3(ADC_CH7) 直接采样。

TIMER0/TIMER1 均配置为 96MHz/8 = 12MHz（满足“TIMER0 八分频”要求，且三路捕获时基一致）。
由于 TIMER0/1 是 16 位，用一个 64 位的“溢出次数 + 16 位 CNT”拼成绝对时间戳，可无歧义地测到 100ms
（1.2M tick ≪ 2^64），并正确区分“捕获”与“16 位溢出”同时发生的情况。

### 3. 工作原理
- `PWM_HighLevel_Init()`：
  - 将 P2.3/P2.4/P2.5 配置为输入并复用 `AF7_TIMER01`（连接 TIM0_CH1 / TIM1_CH0 / TIM1_CH1）；
  - 将 P1.0 配置为普通输入（无复用）；
  - **TIMER0**：Div8、TH = `PWM_T0_TH`(0xFFFF，满 16 位自由计数，约 5.46ms 溢出)、CH1 双沿捕获(P2.3，高精度)、开启 CH1 与 ZERO 中断；ZERO 仅作 P2.3 时间戳扩展（不再承担 P1.0 轮询）；
  - **TIMER3**：Div1、TH = 2526（96M/38K），仅用于 38K PWM 比较输出(P1.2，红外 LED/播料电机)；**过零中断保持关闭**（`Timer_IRQEna_None`，与旧版“会转”工程一致），不在 ISR 里跑步进/ADC/测频，避免 38K ISR 干扰无刷换相。步进改由主循环轮询 `TIMER3->CNT` 按 38K 周期驱动。P1.0 频率测量与两路 ADC 采样当前随之暂停（如需要可单独恢复为低频任务）；
  - **TIMER1**：Div8、TH = `PWM_T1_TH`(0xFFFF，16 位满程)、CH0/CH1 双沿捕获(P2.4/P2.5)、开启全部中断；
  - 初始化各通道状态。
- `UTIMER0_IRQHandler` -> `PWM_HighLevel_Timer0IRQ()`：
  1. 若 ZERO(溢出) 置位：溢出计数 `g_ovf0++`，清标志；
  2. 若 CH1(P2.3) 捕获置位：读取 `CMPT1` 锁存值，用 `pwm_extend()` 拼成 64 位时间戳（处理 16 位溢出歧义），读取 P2.3 当前电平判定上升/下降，交给 `PWM_ProcessEdge()`，清标志。
- `UTIMER3_IRQHandler` -> `PWM_HighLevel_38K_Exec()`（38K 周期任务）：**当前 TIMER3 过零中断已关闭，本路径暂不执行**；逻辑保留，恢复中断即启用。原流程：清 TIMER3 ZERO 标志 → P1.0 频率测量（上升沿周期→频率，每 10 次平均）→ 两路 ADC 交替采样 `PWM_ADC_38KStep()`。
  3. **两路 ADC 交替采样**：调用 `PWM_ADC_38KStep()`（读回上一 tick 触发那一路的过采样平均结果，并触发另一路；详见“三、两路 ADC 采样”）；
  4. 后续可在此添加其它 38K 周期任务（如其它引脚轮询、软件定时等）。
- `UTIMER1_IRQHandler` -> `PWM_HighLevel_Timer1IRQ()`：
  1. ZERO(溢出) -> `g_ovf1++`；
  2. CH0(P2.4)/CH1(P2.5) 捕获：读 `CMPT0/CMPT1`，`pwm_extend()` 扩展时间戳，按当前引脚电平判定边沿，清各自标志。
- `PWM_ProcessEdge(ch, abs_tick, level_high)`：
  - 上升沿：记录 `g_rise_abs[ch]` 时间戳，置 `g_rise_ok`；
  - 下降沿且此前已有上升沿：计算 `high = fall - rise`；若 `high <= 100ms` 量程，换算 `high_us = high / 12`(12 tick = 1µs)，调用对应通道空白回调。

### 4. 关键参数（见 `pwm_highlevel_capture.h`）
| 宏 | 默认 | 含义 |
|----|------|------|
| `PWM_CAPTURE_TIMER_DIV` | `TIM_Clk_Div8` | TIMER0/TIMER1 八分频(12MHz) |
| `PWM_T0_TH` | `0xFFFF` | TIMER0 计数模值 = 满 16 位自由计数（约 5.46ms 溢出）；专供 P2.3 硬件捕获，并为 P1.0 频率测量提供 64 位时基 |
| `PWM_P10_AVG_COUNT` | `10` | P1.0 频率测量：每累计 10 个上升沿周期求一次平均频率 |
| `PWM_T1_TH` | `0xFFFF` | TIMER1 16 位满程，捕获量程最远 |
| `PWM_CAPTURE_MAX_HIGH_MS` | `100` | 最大可测量高电平 |
| `PWM_CAPTURE_MAX_HIGH_TICKS` | `1,200,000` | 对应 tick 上限 |

> 精度说明：**P2.3/2.4/2.5 走硬件捕获，分辨率为 1 tick ≈ 83ns**（远小于 1ms），TIMER0/1 满 16 位自由计数、不引入高频中断，三路捕获精度与响应均不受 P1.0 影响；**P1.0 走频率测量**：38K 轮询采样上升沿（采样周期 ≈ 26.3µs），可测最高频率约 19kHz（奈奎斯特），周期时间戳用 TIMER0 的 12MHz 时基（tick≈83ns），每 10 次周期取平均以抑制抖动；运行在独立、低优先级的 TIMER3 中断中，彻底与三路捕获解耦。

### 5. 引脚与通道映射
| 通道 | 引脚 | 测量方式 | 复用/说明 |
|------|------|----------|-----------|
| `PWM_CH_P10` (0) | **P1.0** | 38K 轮询频率测量（TIMER0 时基） | 无 TIMER 捕获复用 |
| `PWM_CH_P23` (1) | **P2.3** | TIMER0 CH1 硬件捕获 | 复用 `AF7_TIMER01` |
| `PWM_CH_P24` (2) | **P2.4** | TIMER1 CH0 硬件捕获 | 复用 `AF7_TIMER01` |
| `PWM_CH_P25` (3) | **P2.5** | TIMER1 CH1 硬件捕获 | 复用 `AF7_TIMER01` |

---

## 三、新增功能：两路 ADC 采样（OPA0 差分 + P0.3/CH7，38K 交替采样）（V1.5）

### 1. 需求
在原 38K 周期任务（`PWM_HighLevel_38K_Exec`）里增加读取两路 ADC 信号：
- **通道 A**：P1.14(OPA0_IP) 与 P1.15(OPA0_IN) 之间的差分信号，最大 100mV，经**片内 OPA0 差分放大**后送 ADC；
- **通道 B**：P0.3 的 ADC_CH7，外部已放大，直接采样；
- 采用“一次读这一路、一次读那一路”的交替方式，**每路有效采样率 19K**（= 38K/2）；
- **触发 ADC 后不等待转换**，在下一个 38K tick 才读回结果；读回后立即触发另一路；
- 在 38K 时间预算允许、且不增加软件负担的前提下，**尽量采用硬件过采样**提高精度；
- ADC 的偏移、增益校准按官方例程（`13.LKS32MC_05x_OPA`、`4.LKS32MC_05_ADC`）的方式进行。

### 2. 依据手册/例程确认的要点
| 要点 | 出处 | 影响 |
|------|------|------|
| OPA0 输出 → ADC 通道（用于采样放大后电压） | 用户手册表5-11 + 用户确认 | 表5-11 明确“ADC_CHNx=0000=OPA0 Output”(即 CH0)，用户已确认本板 OPA0 输出即接在 ADC_CH0，故选 `ADC_CHANNEL_0`。无需外部走线、`OPA_OUT()` 引 P2.7 |
| P1.14=OPA0_IP、P1.15=OPA0_IN 为片内专用模拟脚 | 数据手册引脚表 | OPA0 差分输入即这两脚，无需 GPIO 配置 |
| P0.3=ADC_CH7 | 数据手册引脚表 | 通道 B 选 ADC_CH7 |
| OPA 偏移校准：短路 OPA 输入(IP/IN)后多采样平均得零点偏移 | `13.LKS32MC_05x_OPA` 的 `OPAOut_OffsetCalibration()` | `PWM_ADC_Init()` 初始化时短路 OPA0 输入、512 次平均得到 `g_adc_diff_offset` |
| 增益/偏移工厂校准：ADC_Init 内按量程从 NVR trim 自动载入 DC/AMC | `lks32mc05x_adc.c` `ADC_Init()` | 通道 B(CH7) 无 OPA，直接沿用该工厂 DC/AMC 校准，无需额外操作 |
| ADC 左对齐、3.6V 量程、单段连续采样、DAT0..DAT15 各存一次结果 | `lks32mc05x_adc.h` / 用户手册 ADC 章 | 过采样 = 单段连续采样 N 次同一通道，结果在 DAT0..DAT(N-1)，软件求平均 |

### 3. 工作原理
- `PWM_ADC_Init()`（在 `Hardware_init()` 中断关闭期调用）：
  1. `OPA_Init(OPA0, …)`：使能 OPA0 闭环、增益 `PWM_ADC_OPA_GAIN`(默认 `PGA_GAIN_20`，内部反馈电阻 200k:10.6k)；实际闭环增益 = 200/(10.6+R_ext)，R_ext 为外部匹配电阻(kΩ)，用户确认本板 OPA0 外部匹配电阻 R_ext = 1k，故实际增益 = 200/(10.6+1) ≈ **17.24**（详见参数表）；不短路输入；
  2. `ADC_Init(ADC0, …)`：软件触发、单段、左对齐、`ADC_RANGE_3V6`(3.6V)、`ADC_CLK_48M`、采样 20 周期；**关闭 ADC 中断**（纯轮询）；内部自动载入 DC/AMC 工厂校准；
  3. OPA0 输入内部短路，软件触发 512 次单采样、累加 `DAT0`、`>>9` 得到零点偏移 `g_adc_diff_offset`，再解除短路；
  4. 复位运行时状态（首 tick 仅触发、不读回）。
- `UTIMER3_IRQHandler` -> `PWM_HighLevel_38K_Exec()` 内调用 `PWM_ADC_38KStep()`，每个 38K tick 执行（**当前因 TIMER3 中断关闭而暂停，恢复即启用**）：
  1. 若已触发过：读回“上一 tick 触发那一路”的 `PWM_ADC_OVERSAMPLE_N`(=8) 次结果 `DAT0..DAT(N-1)`，求和平均；差分通道再减 `g_adc_diff_offset`，存入 `g_adc_code[]` 并置新值标志；清 `ADC_EOS0` 标志；
  2. 触发“另一路”（首次触发通道 A）：`ADC_ConfigSeg()` 把 CHN0..CHN3 全部填为该路通道、`CHNT.FirSeg_Ch=N`，再 `ADC_SoftTrgEN(ENABLE)`；**不等待转换**，下一次 38K tick 才读回。
  - 由此每路每 2 个 tick 采样一次 → 有效采样率 = 38K/2 = **19K**；交替读/触发使 ADC 转换完全在两次 tick 之间完成（≈5.6µs @ N=8, 48M），不阻塞 38K 任务。
- 主循环/业务通过 `PWM_ADC_GetDiff(&code)` / `PWM_ADC_GetCh7(&code)` 读取最新平均 code（返回 1 表示有新值）；或调用 `PWM_ADC_CodeToVolt_mV()` / `PWM_ADC_DiffInput_mV()` 换算电压。

### 4. 关键参数（见 `adc_sample.h`）
| 宏 | 默认 | 含义 |
|----|------|------|
| `PWM_ADC_OVERSAMPLE_N` | `8` | 每次触发的硬件过采样次数（单段连续采样同一通道次数）；38K 预算内可加大（见下） |
| `PWM_ADC_OPA_GAIN` | `PGA_GAIN_20`(≈17.24) | OPA0 差分增益；实际增益 = 200/(10.6+R_ext_kΩ)，R_ext 为外部匹配电阻(kΩ)；用户确认本板 R_ext=1k → 200/11.6 ≈ 17.24；`PWM_ADC_OPA_GAIN_NUM/DEN`=1724/100 供电压换算 |
| `PWM_ADC_RANGE_MV` | `3600` | ADC 量程 3.6V |
| `PWM_ADC_FULL_SCALE_CODE` | `0x7FF0` | 左对齐满量程 code（同例程换算约定；校准后输出为无符号 0..0x7FF0） |
| `PWM_ADC_CH_DIFF` | `ADC_CHANNEL_0` | 通道 A = OPA0 输出（P1.14/IP、P1.15/IN 差分放大后）。手册表5-11：ADC_CHNx=0000=OPA0 Output，用户已确认本板即接 CH0 |
| `PWM_ADC_CH_CH7` | `ADC_CHANNEL_7` | 通道 B = P0.3 |
| `PWM_ADC_CALIB_CNT` | `512` | OPA0 偏移校准采样次数（同例程） |

> **精度与过采样**：每个 38K tick 仅增加约 N 次读寄存器 + 一次触发（N=8 时转换 ≈5.6µs，远小于 26.3µs），软件负担极小；硬件连续采样 N 次求平均可抑制量化噪声，等效提升约 log2(√N) 位分辨率。N 可在 38K 预算内上调（48M 下 N=16 ≈11µs 仍可放下），但 `CHNT` 字段为 4bit，建议上限取 8~16 并实测确认。

> **OPA 增益选择**：实际闭环增益 = 200/(10.6+R_ext)，R_ext 为外部匹配电阻(kΩ)。用户确认本板 OPA0 外部匹配电阻 R_ext = 1k，故增益 = 200/11.6 ≈ **17.24**（即 `PWM_ADC_OPA_GAIN_NUM/DEN` = 1724/100），最充分利用 3.6V 量程，适配 **0..100mV 单极性**（如电流采样分流）信号；若后续更换外部匹配电阻，按 200/(10.6+R_ext_kΩ) 修正换算系数。若差分信号为**以 0 为中心的双极性 ±100mV**，峰值输出 ≈±1.724V，仍可落在 3.6V 量程内；但若输入范围更大导致越界削顶，应改 `PGA_GAIN_9P5` 留裕量。增益数值仅用于 `PWM_ADC_DiffInput_mV()` 电压换算，不影响采样本身。

### 5. 引脚与通道映射
| 通道 | 引脚 | 信号 | 路径 |
|------|------|------|------|
| 通道 A | P1.14(OPA0_IP) / P1.15(OPA0_IN) | 差分，最大 100mV | OPA0 片内差分放大 → ADC_CH0（`PWM_ADC_CH_DIFF` = `ADC_CHANNEL_0`，手册表5-11：ADC_CHNx=0000=OPA0 Output，用户已确认本板即接 CH0） |
| 通道 B | P0.3 | 外部已放大 | 直接 → ADC_CH7 |

---

## 四、文件清单与改动

| 文件 | 类型 | 说明 |
|------|------|------|
| `AppFunction/pwm_highlevel_capture.h` | **新增** | 模块头文件：配置宏、对外接口、4 个空白回调声明 |
| `AppFunction/pwm_highlevel_capture.c` | **新增** | 模块实现：TIMER0/TIMER1 初始化、捕获/轮询边沿、64 位时间戳扩展、空白回调；38K 任务内调用 `PWM_ADC_38KStep()` |
| `LK_StdPeriph.uvprojx` | 修改 | 在 AppFunction 组中加入 `pwm_highlevel_capture.c`（否则链接报未定义符号） |
| `AppFunction/hardware_init.c` | 修改 | 包含模块头文件；`Hardware_init()` 中调用 `PWM_HighLevel_Init()`；开启 `TIMER0_IRQn` 与 `TIMER1_IRQn` |
| `AppFunction/interrupt.c` | 修改 | `UTIMER0_IRQHandler` 调用 `PWM_HighLevel_Timer0IRQ()`；`UTIMER1_IRQHandler` 调用 `PWM_HighLevel_Timer1IRQ()` |
| `AppFunction/adc_sample.h` | **新增** | 两路 ADC 采样模块头文件：配置宏、初始化/步进/读取/电压换算接口 |
| `AppFunction/adc_sample.c` | **新增** | 两路 ADC 采样实现：OPA0 差分放大 + ADC 软件触发单段过采样、OPA0 输入短路偏移校准、38K 交替读/触发（需加入工程 AppFunction 组） |
| `AppFunction/hardware_init.c` | 修改 | 新增包含 `adc_sample.h`；`Hardware_init()`（中断关闭期）调用 `PWM_ADC_Init()` 完成 OPA0/ADC 初始化与偏移校准 |

对外接口：
```c
void PWM_HighLevel_Init(void);          /* 初始化（在 Hardware_init 中已调用） */
void PWM_HighLevel_Timer0IRQ(void);     /* 由 UTIMER0_IRQHandler 调用 */
void PWM_HighLevel_Timer1IRQ(void);     /* 由 UTIMER1_IRQHandler 调用 */
u32  PWM_HighLevel_GetUs(u8 ch);        /* 读取最近一次高电平宽度(us)，P1.0 不适用 */
u8   PWM_HighLevel_IsUpdated(u8 ch);    /* 查询是否有新测量 */
u8   PWM_HighLevel_GetP10Freq(u32 *p_freq_hz); /* 读取 P1.0 平均频率(Hz)，返回是否有新值 */
```

两路 ADC 采样模块对外接口：
```c
void PWM_ADC_Init(void);              /* OPA0+ADC 初始化与偏移校准（Hardware_init 中断关闭期调用） */
void PWM_ADC_38KStep(void);           /* 每个 38K tick 调用：读回上一触发+触发另一路 */
u8   PWM_ADC_GetDiff(u32 *p_code);    /* OPA0 差分平均 code(已减偏移)，返回是否有新值 */
u8   PWM_ADC_GetCh7(u32 *p_code);     /* P0.3/CH7 平均 code，返回是否有新值 */
s32  PWM_ADC_CodeToVolt_mV(s32 code); /* code -> 电压(mV)，量程 3.6V */
s32  PWM_ADC_DiffInput_mV(s32 diff_code); /* OPA0 差分 code -> 差分输入电压(mV) */
```

---

## 五、如何扩展（后续实现业务逻辑）
当某引脚完成一次“上升沿->下降沿”后，模块会自动调用以下**空白函数**，在其中填写具体功能即可：
```c
void PWM_HighLevel_P10_Callback(u32 freq_hz);  /* P1.0（频率测量，参数=Hz） */
void PWM_HighLevel_P23_Callback(u32 high_us);  /* P2.3（TIMER0_CH1） */
void PWM_HighLevel_P24_Callback(u32 high_us);  /* P2.4（TIMER1_CH0） */
void PWM_HighLevel_P25_Callback(u32 high_us);  /* P2.5（TIMER1_CH1） */
```
P2.3/2.4/2.5 的 `high_us` 为该次高电平持续时间（微秒）；P1.0 的 `PWM_HighLevel_P10_Callback` 参数为最新平均频率（Hz）。若希望在其它文件实现，可删除 `pwm_highlevel_capture.c` 中的空函数体，在本文件外提供定义。

---

## 六、验证建议
1. 用信号源/另一路 MCU 在 P1.0 / P2.3 / P2.4 / P2.5 上输出已知占空比的 PWM：
   - P2.3/2.4/2.5 为硬件捕获，无最低周期限制（建议高电平 ≤ 100ms）；
   - P1.0 做频率测量：原本由 TIMER3 的 38K 中断轮询（约 26.3µs 采样一次，可测最高约 19kHz）；当前该中断已关闭、测量暂停，如需验证请先恢复 TIMER3 过零中断（注意会与无刷换相环境偏离旧版“会转”工程）。
2. P2.3/2.4/2.5：在 `PWM_HighLevel_Pxx_Callback()` 中打印 `high_us` 或用 `PWM_HighLevel_GetUs(ch)` / `PWM_HighLevel_IsUpdated(ch)` 读取高电平宽度。
3. P1.0：在主循环调用 `PWM_HighLevel_GetP10Freq(&freq)`（返回 1 表示有新平均频率），或在 `PWM_HighLevel_P10_Callback(freq_hz)` 中处理，通过 UART1（P0.7 TXD）打印频率与预期比对。
4. 两路 ADC：
   - OPA0 差分通道 A（P1.14/IP、P1.15/IN）：先在 P1.14/1.15 间加已知差分电压（如用两电阻分压给出 0..100mV），主循环调用 `PWM_ADC_GetDiff(&code)`，用 `PWM_ADC_DiffInput_mV(code)` 换算差分输入(mV) 与预期比对；短路输入时应读到≈0（已减 `g_adc_diff_offset`）。
   - P0.3/CH7 通道 B：在 P0.3 加已知电压（外部已放大），用 `PWM_ADC_GetCh7(&code)` 读 code、`PWM_ADC_CodeToVolt_mV(code)` 换算电压比对。
   - 确认 38K 任务中两路交替、各约 19K 采样率（每 2 个 38K tick 更新一次）；可用 UART1（P0.7 TXD）打印两路 code/电压观察稳定性与过采样效果。

### 7. UART1 实时遥测（已内置，彻底弃用 RTT）
`DebugPWM_OutputFunction()` 的主循环里约每 1 秒经 **UART1（P0.7 TXD，115200-8-N-1）** 输出一行遥测（串口助手可见），格式示例：
```
P1.1=1 | P2.3=5023us P2.4=4970us P2.5=5000us | I_BLDC=0.00A I_STEP=0.00A | BLDC_HALL_n=120 BLDC_RPS=20.00 BLDC_RPM=1200
```
- `P1.1`：无料检测脚电平（低=可能无料）。
- `P2.3/2.4/2.5`：三路**去抖后**状态对应的高电平宽度（单位 `us`，整数）；去抖 100ms，由 `CmdDebounce_Update()` 产出（接口读 `g_p23_us_f` 等，不直接读硬件）。
- `I_BLDC`/`I_STEP`：无刷/步进实时电流（A）。
- `BLDC_HALL_n`：本秒 HALL 换相次数；`BLDC_RPS`/`BLDC_RPM`：无刷转速（圈/秒、转/分，6 换相=1 圈）。
- 无有效测量时对应字段为 `0`。

> **RTT 已彻底弃用**：原 SEGGER RTT 在 Keil+M0 下用 `PRIMASK` 全局关中断，打印期间会屏蔽最高优先级的 `HALL` 换相中断导致无刷锁死；现改为 UART1 阻塞发送（发送期间不关中断），对换相零干扰。RTT 库文件虽仍在工程目录但已不被引用。

### 7.9 无刷"锁死"根因与最小无刷模式开关（BLDC_MINIMAL_MODE）
逐行对比"MCPWM旧版会转"工程后确认：**无刷换相逻辑两版逐字相同**（`MOTOR_DIR=0` / `SEQ_FWD` / `BuildHallTables` / `NEXT_MAP` 单向校验 / `HALL_ApplyCommutation` / 三相下管预充2秒后初始换相）。旧版能连续转动的关键在于其**运行环境极其干净**：
- 只使能 `MCPWM`(优先级1) + `HALL`(优先级0) 两个中断；
- 主循环为空 `for(;;){__NOP();}`；
- 无 ADC、无 TIMER0/1 捕获、无 UART 遥测打印。

当前版新增的子系统改变了该环境，是无刷锁死/步进震动的真凶：
1. **捕获中断风暴**：`PWM_HighLevel_Init()` 把 P2.3/P2.4/P2.5 配为**双沿捕获 + 无上下拉(NOPULL)**，并开 `TIMER0`(CH1+ZERO) / `TIMER1`(全部中断)。这些脚悬空/有噪声时会以极高频率触发捕获中断，叠加 ADC 被 MCPWM 触发等交互，CPU 被大量占用、无刷启动/换相环境与旧版完全不同。
2. **主循环 RTT 打印阻塞（历史，已根治）**：原 `Debug_ReportTelemetry()` 的 `SEGGER_RTT_printf` 在无 RTT Viewer 读取时会阻塞主循环约1秒，冻结步进走步，解冻后 catch-up 突发补步 → 步进震动+发热。**该问题已随 RTT 弃用、改 UART1 阻塞发送（不关中断）彻底解决**。

**`hardware_init.c` 顶部开关**：
- `BLDC_MINIMAL_MODE`：
  - `=1`：`Hardware_init()` 跳过 `PWM_HighLevel_Init()` / `PWM_ADC_Init()` 与 `TIMER0/1` NVIC 使能；只保留 `MCPWM`+`HALL` 中断与步进(纯 GPIO)。此时无刷运行环境与旧版**完全一致**，用于确认无刷是否恢复转动。
  - `=0`：恢复全部子系统（三路捕获 / ADC / TIMER0/1 中断）。
- `UART_TELEMETRY_ENABLE`（独立控制主循环遥测打印）：
  - `=1`：约每 1 秒调用 `Debug_ReportTelemetry()` 经 **UART1（P0.7 TXD）** 上报测频/占空比/电流等信息。UART1 采用**阻塞发送但发送期间不关中断**，对最高优先级的 `HALL` 换相中断零干扰，不会卡死无刷。**默认 1 打开**。
  - `=0`：主循环不做 UART 遥测。遥测功能代码仍在（置 1 即生效），仅不调用。

> 当前设置：`BLDC_MINIMAL_MODE=0`（捕获/ADC 中断全开）+ `UART_TELEMETRY_ENABLE=1`（UART1 遥测打开）。此前无刷锁死的真凶（RTT 在 **Keil + Cortex-M0** 下用 `PRIMASK` 全局关中断屏蔽 `HALL` 换相中断）已随 RTT 彻底弃用、改 UART1 阻塞发送（不关中断）而根治。若此后无刷再次锁死，与调试输出无关，应查 P2.3/2.4/P2.5 双沿捕获中断风暴（用软件关 TIMER0/1 NVIC 或改单沿捕获缓解，不动 GPIO 引脚本身）。

> 若最小模式下无刷仍锁死，则根因不在软件环境，应查硬件：霍尔接线/相序、母线供电是否被步进(若接错持续通电)拉低、自举电容预充等。

### 8. 35BYJ46 步进电机驱动（已内置）
四相五线单极步进电机，COM(红) 接 12V，A/B/C/D 四相由 MCU 的 4 个 GPIO 经外部驱动管控制；**GPIO 高电平 = 该相导通**（若硬件逻辑相反，将 `stepper.c` 序列里的 1/0 互换即可）。
- 引脚映射：P2.9=A(橙)、P2.10=B(黄)、P0.9=C(粉)、P0.10=D(蓝)。
- 驱动方式：四相八拍（半步），8 个状态循环，每切换一次转子走半个基本步距角，运行最平稳、扭矩较好。
- 正转序列（步骤 1→8）：`A`、`AB`、`B`、`BC`、`C`、`CD`、`D`、`DA`（即 `1000→1100→0100→0110→0010→0011→0001→1001`，A/B/C/D 位序）。
- 实现位置：`Stepper_Init()` 在 `Hardware_init()` 中初始化 4 个 GPIO 为输出；`Stepper_Tick()` 在 `DebugPWM_OutputFunction()` 的**主循环**里调用，时间基准取自 TIMER3 自由运行的 38K 计数（轮询 `TIMER3->CNT`，每 2526 计数为一个 38K 周期）。**主循环每个 38K tick 只调用一次 `Stepper_Tick()`**，由其内部按 `STEPPER_DIV` 分频走步。
- **重要修复（双重分频 BUG）**：此前主循环先按 `STEPPER_DIV` 预分频再调用 `Stepper_Tick()`，而 `Stepper_Tick()` 内部又分频一次，等于 `STEPPER_DIV²` 分频，实际速率只有 `38000/(38×38)≈26 步/秒`（比预期慢 38 倍，表现为步进过慢/上不去速度）。现已改为“每 tick 调一次”，`STEPPER_DIV=38` 真正得到 `38000/38≈1000 步/秒`（栅极/相频约 125Hz，约为初版 380→100 步/秒的 10 倍）。
- **防突发**：主循环若某次被长阻塞而积压多个 38K 周期，最多只补 1 个 tick，不把积压步一次性倾泻给电机（否则步进会瞬间连跳多步 → 原地震动+发热）。
- 速度调节：`stepper.h` 的 `STEPPER_DIV` 指定“每 N 个 38K tick 走一步”。`STEPPER_DIV=38` 约 1000 步/秒；想更快调小、更慢调大。**注意 35BYJ46 从静止的起动(pull-in)速率有限，约几百步/秒**：若在 1000 步/秒只原地震动不转，说明超出起动能力（并非软件问题），把 `STEPPER_DIV` 调大（如 76→约500步/秒、150→约250步/秒）即可正常转动。
- 注意：TIMER3 的 38K **过零中断已关闭**（与旧版“会转”工程一致），不再在 ISR 里跑步进/ADC/测频；步进改由主循环轮询 TIMER3 计数驱动。
- 转向：`Stepper_SetDir(STEPPER_DIR_FWD / STEPPER_DIR_REV)` 切换正/反转（默认正转）。
