# 修改历史 / 还原记录（CHANGELOG & RESTORE NOTE）

> 说明：本机 git 已可用（`C:\Program Files\Git\cmd` 已加入系统 PATH，版本 2.55.0.windows.3）；
> 工程根目录已 `git init` 并首次提交（见下方"六"），此后本文件与"文本历史 + 文件备份"并存，
> 既保留可读的对话/改动记录，又能用 `git diff/checkout` 随时还原。
> 本文件记录：用户原话、助手回复、本次撤销内容、本次修复内容、以及如何还原。
> 每次修改都先备份被改文件，备份目录：`backup/<日期>_pre_revert/`

---

## 〇、最新结论（2026-07-29，按用户最终决定）

- **引脚分配（最终）**：P0.14 = 步进到位霍尔 HALL_IN2（GPIO 输入，内部上拉）；调试串口 UART 迁回 **P0.7 / UART1**（115200-8-N-1）。
  （此前曾按旧 CHANGELOG 把 UART 配到 P0.14/UART0，与步进霍尔冲突，现已回滚；UART 引脚复用统一在 `hardware_init.c` 的 `GPIO_init` 配置。）
- **PI 闭环**：播料电机 TIMER2/P0.4 速度闭环（`FeedControl_Tick`，目标 `FEED_TARGET_HZ=100`，按 P1.0 读数值计）保留。
- **ADC 零点**：保持不软件校准（`g_adc_ch7_offset=0`），依赖芯片内部 DC/AMC 工厂校准。
- **编译修复**：补 UART 发送函数前向声明（修复 C99 隐式函数声明报错导致 `hardware_init.o` 缺失）；`hardware_config.h` 用 `#ifndef` 守卫 `MCU_MCLK` / `AF0_GPIO` / `AF4_UART`，消除重定义 warning。

## 一、本次会话背景（2026-07-21）

### 用户原话（关键）
1. "纯属放屁，明显不是噪声巧合，程序肯定有问题" —— 质疑之前"P2.4 恒为 34us 是边沿振铃/噪声"的解释。
2. "发现是硬件问题！硬件把P2.4拉低，撤销上次修改！但是，这几个引脚的输入PWM小时候，输出仍然不清0的BUG要修"
3. "别找旧目录，里面根本没有PWM，从现在开始马上应用GIT，没有GIT你就给我生成历史文本，方便还原，我说的你回复的也要写进去，全都要备份。现在是硬件问题！硬件把P2.4拉低，马上撤销上次修改！但是，这几个引脚的输入PWM小时候，输出仍然不清0的BUG要修"

### 助手回复（关键）
- 承认 P2.4 恒为 34us 不是噪声，是确定性逻辑错误；核查了捕获 ISR、定时器驱动、引脚复用表、HALL/MCPWM 占用。
- 确认 P2.4 复用为 TIM1_CH0，HALL/MCPWM 未占用 P2.3/4/5，三路软件逻辑对称。
- 结论：P2.4 被硬件拉低（用户确认），因此之前为"34us"加的软件去抖/加宽滤波属于误判，应撤销。
- 修复"输入 PWM 小、输出不清 0"：根因是捕获输入数字滤波取值 15（≈1.25us），会把短高电平脉宽整段吞掉，导致读数一直保留上一次的大值。

---

## 二、撤销内容（撤销"上次修改" —— P2.4 34us 的软件 workaround）

> 撤销依据：P2.4 是硬件拉低，无上升/下降沿，不会触发捕获，原"34us"根因不在软件。
> 撤销前文件已备份：`backup/2026-07-21_pre_revert/pwm_highlevel_capture.c`、`.h`

1. **删除 `g_edge_level[]` 去重变量及其全部引用**
   - `AppFunction/pwm_highlevel_capture.c` 中静态变量声明、Init 复位、信号丢失复位、`PWM_ProcessEdge` 内的去重 `if (g_edge_level[ch] == level_high) return;` 全部移除。
   - 恢复为原生"上升沿/下降沿直接处理"逻辑（无同向沿去重）。
2. **P2.4 滤波注释回归正常**：去掉"抗边沿振铃（关键）"字样，改为说明 P2.4 由硬件拉低、滤波仅作轻微抗扰。

---

## 三、修复内容（输入 PWM 小 → 输出不清 0 的 BUG）

### 根因
- 捕获输入数字滤波 `PWM_CAPTURE_FILTER = 15` → 滤波窗口 `15×8/96MHz ≈ 1.25us`。
- 当某路输入 PWM 的高电平脉宽 < 1.25us（小占空比/短高电平）时，信号达不到"稳定高"的滤波宽度，
  上升沿与下降沿均不被捕获 → `PWM_ProcessEdge` 不被调用 → `g_last_us[ch]` 一直保留上一次的大值，清不到 0。

### 修复 1：降低输入数字滤波
- `AppFunction/pwm_highlevel_capture.h`：`#define PWM_CAPTURE_FILTER ((u8)2u)`（≈0.17us），
  仅抑制亚微秒级毛刺，允许很短的高电平脉宽通过，使小 PWM 也能被正常测量（输出反映真实小值，而非残留大值）。

### 修复 2：上升沿闭合丢失时主动清 0
- `AppFunction/pwm_highlevel_capture.c` 的 `PWM_ProcessEdge` 上升沿分支：
  若 `g_rise_ok[ch]` 仍为 1（说明上一轮"上升沿→下降沿"没闭合，高电平过短/下降沿被滤波或中断延迟吞掉），
  先把 `g_last_us[ch]` 置 0 并 `g_updated[ch]=1`、回调参数传 0，避免输出滞留旧的大值。
  ```c
  if (g_rise_ok[ch])
  {
      g_last_us[ch]  = 0;
      g_updated[ch]  = 1;
      PWM_HighLevel_InvokeCallback(ch, 0);
  }
  ```

### 修复后行为
- 输入 PWM 变小（短高电平）：滤波放行 → 正常测到小高电平宽度；若高电平短到连上升沿都来不及闭合，
  下一上升沿到来时也会把输出清 0。
- 输入 PWM 完全消失：原有 38K 任务"信号丢失超时（≈300ms）"仍会把读数清 0（逻辑未动）。

---

## 四、如何还原（Restore）

若需回到本次修改前的状态：
```
把 backup/2026-07-21_pre_revert/pwm_highlevel_capture.c
   复制回 AppFunction/pwm_highlevel_capture.c
把 backup/2026-07-21_pre_revert/pwm_highlevel_capture.h
   复制回 AppFunction/pwm_highlevel_capture.h
```
（即：删除本次的"去重撤销 + 滤波降为 2 + 上升沿清 0"三处改动。）

---

## 五、备份清单（本次）
- `backup/2026-07-21_pre_revert/pwm_highlevel_capture.c` （25571 字节，修改前）
- `backup/2026-07-21_pre_revert/pwm_highlevel_capture.h` （8349 字节，修改前）
- `CHANGELOG_历史.md`（本文件）

---

## 六、UART 输出引脚迁移：P0.7 / UART1 → P0.14 / UART0（2026-07-21）

### 用户原话
- "UART输出改为P0.14"

### 助手回复（关键）
- 核查数据手册：P0.7 硬连 **UART1_TXD**；P0.14 硬连 **UART0_TXD**（非 UART1）。
  因此"改到 P0.14"等价于把串口外设从 UART1 换到 UART0，仅挪引脚（仍用 AF4_UART）不够。
- 确认 P0.14 当前空闲（仅出现在 `hardware_init.c` 295-300 行被注释掉的 MCPWM_BKIN1 配置里）。
- 确认 UART0 在本工程未被占用（仅有 `interrupt.c` 中一个空的中断桩 `UART0_IRQHandler`，遥测不使能中断，无冲突）。

### 改动内容
1. **`AppFunction/pwm_highlevel_capture.c`（引脚复用）**
   - 原：`GPIO_Pin_7` + `GPIO_PinAFConfig(GPIO0, GPIO_PinSource_7, AF4_UART)`（P0.7 → UART1_TXD）
   - 改：`GPIO_Pin_14` + `GPIO_PinAFConfig(GPIO0, GPIO_PinSource_14, AF4_UART)`（P0.14 → UART0_TXD）
   - 更新对应注释（说明硬连关系、外设由 UART1 改为 UART0）。
2. **`AppFunction/hardware_init.c`（串口外设 + 全部遥测函数）**
   - `UART1_TelemetryInit` → `UART0_TelemetryInit`，内部 `UART_Init(UART1, …)` → `UART_Init(UART0, …)`。
   - 全部发送函数 `UART1_SendByte/SendStr/SendU32/SendCurrentMA` 重命名为 `UART0_*`，
     内部 `UART1->STT` → `UART0->STT`、`UART_SendData(UART1, …)` → `UART_SendData(UART0, …)`。
   - 调用处（`UART0_TelemetryInit()` 初始化、主循环 `UART0_SendStr(...)` 输出）及所有注释
     中的 "UART1(P0.7 TXD)" 同步改为 "UART0(P0.14 TXD)"。
   - 波特率/格式不变：115200-8-N-1，仅 TX、不使能中断，阻塞发送（对换相零干扰）。

### 如何还原（还原到 P0.7/UART1）
- git 方式：`git checkout <本次提交前> -- AppFunction/pwm_highlevel_capture.c AppFunction/hardware_init.c`
- 手工方式：将上述两文件里 `P0.14`/`GPIO_PinSource_14`/`UART0` 全部换回 `P0.7`/`GPIO_PinSource_7`/`UART1`。
