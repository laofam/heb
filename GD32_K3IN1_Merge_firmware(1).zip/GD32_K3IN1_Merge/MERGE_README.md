# K3IN1 × gd303_HALL_FOC 合并固件（GD32F303CBT6）说明

> 本工程 = **Smart_K3IN1_Firmware -servo-V1.3-20210713** 的外设算法（业务层）
> ＋ **gd303_HALL_FOC v2.2** 已验证的风机驱动（控制律零改动）
> 目标硬件 = gd303_HALL_FOC 新板（GD32F303CBT6，LQFP48，120MHz，无外部晶振）
> 交付状态：代码完成 + 静态一致性自检通过；**尚未上机验证**，请按文末 checklist 逐项确认。

---

## 1. 文件结构

```
User/
├── main.c                 【重写】启动序列 + 业务主循环 + FOC 控制中断（gd303 原样保留）
├── motor_hardware.c/h     【不动】gd303 电机硬件层（TIMER0/ADC 注入组/霍尔/预充）
├── motor_config.h         【不动】gd303 风机参数（30000rpm、FOC/限流/保护全保留）
└── app/                   【新增】K3IN1 业务层（P1/P2/L1 命名）
    ├── app_config.h       配置中枢：引脚映射、协议常数、档位表、过流阈值、调试宏
    ├── app_init.c/h       GPIO/AFIO 重映射、TIMER2 38kHz、TIMER5 心跳、ADC 规则组、EXTI3
    ├── p1p2_capture.c/h   P1(PB10)/P2(PB11) 输入捕获 + 三次捕获法解码 + P2 档位表
    ├── dosing_motor.c/h   拨料电机：100µs 电流环 + 10ms 速度环 + 500µs 位置斜坡（K3IN1 双环原样）
    ├── stepper.c/h        步进四相八拍（非阻塞 100µs 拍）+ PA11/PA12 双霍尔到位 + 压紧补偿
    ├── motor_ctrl.c/h     业务总控：P2 开停机顺序链、风机 4s 检查 + 3 次重试、P1 随速
    ├── material_s4.c/h    物料延时判定（1s/2s）、L1 双向应答（PB2 读 / PC13 拉低）
    └── led_status.c/h     红灯故障码（双闪=内故障/快闪=无料/常亮=待机）+ 绿灯心跳
```

## 2. 对 gd303_HALL_FOC 的改动（仅 2 处，已获放行）

| 文件 | 改动 | 说明 |
|---|---|---|
| `FOC/foc.c` / `foc.h` | 新增 `foc_soft_restart()`（约 15 行） | FAULT/任意态 → IDLE + 清 d/q 积分器 + 清故障码。**控制律零改动**。这是业务层能实现"正常停机→再启动"与"3 次重试"的唯一路径（原 FAULT 锁存需断电复位） |
| `User/main.c` | 重写 | 启动序列保留 gd303 原样；删除"上电自启动"（改由 P2 控制）；`TIMER0_Channel_IRQHandler` 内遥测段由 `APP_DEBUG_UART_EN` 宏控制 |

其余 gd303 文件（BLDC/、motor_hardware、motor_config、BSP）**逐字未动**。

## 3. 硬件资源分配（全部经 GD32F30x 手册表 8-5 核实）

| 外设 | 用途 | 来源 |
|---|---|---|
| TIMER0 | 风机 FOC 三相 PWM（28.5kHz 中点对齐）+ 控制中断 + ADC 注入组触发 | gd303 原样 |
| TIMER1（部分映射1） | **CH2=PB10(P1)、CH3=PB11(P2) 输入捕获**，0.5µs/tick | 新增 |
| TIMER2（部分映射） | **CH0=PB4 38kHz 载波（50% 固定）**、**CH1=PB5 拨料 PWM**、TRGO→ADC 规则组 | 新增 |
| TIMER5（基本） | 100µs 业务心跳（拨料电流环/时标/去抖） | 新增 |
| ADC0 注入组 | FOC 三相电流（PA0/1/2） | gd303 原样 |
| ADC0 规则组 | IN3(CSREF 基准)/IN8(PB0 步进电流)/IN9(PB1 拨料电流) + DMA0_CH0 循环 | 新增 |
| EXTI3 | PB3 拨料霍尔测速脉冲计数 | 新增 |
| USART2 | 调试模式 PB10=TX@921600（DMA0_CH1） | gd303 原样（宏控制） |
| AFIO | SWD-only（释放 JTAG，PA15/PB3/PB4 可用） | 新增 |

## 4. K3IN1 语义保持与差异（以代码为准）

### 完全保持
- **P2（原 S2）**：480~970µs 开机 / <512.5µs 一键排种 / 1025~2240µs 每档 50µs；
  档位表逐档照抄（250/0/250/250/250/115/70/70/110/86/75/60/47/38/30/21/15/20/20 rpm + Y_g）
- **P1（原 S1）**：450~500µs 停排种 / 525~900µs 随速（temp=(脉宽-500µs)/500µs）/ ≥900µs 全速；
  Y_g≥5000 有 30rpm 起转下限，1000~4500 纯比例（下限 10rpm）
- **拨料电机**（原排种轮）：电流环 PI(Kp20/Ki0.02) 100µs + 速度环 PI(Kp30/Ki0.01) 10ms +
  位置斜坡 500µs；两级过流 600mA/5s、1040mA/1.5s（码值按新板 25mΩ×20 倍重算：372/645）
- **步进**：八拍序列/行程步数（1120/1140）/拍速/收起延时 1s/压紧补偿（50 步）全保持；
  到位反馈 PA11(关闭)/PA12(开启) 低有效
- **料位/L1**：无料延时 1s（低用量档）/2s；L1 拉低报警；主机拉低 L1=外部故障（去抖 300ms，一键排种强制解除）
- **LED**：红灯=K3IN1 Status 灯故障码语义，绿灯=心跳
- **风机**：固定 30000rpm、启动 4s 检查、最多 3 次尝试、P1/P2 信号丢失 5s 全停

### 差异（按新板硬件/规格书）
| 项 | K3IN1 | 合并固件 | 原因 |
|---|---|---|---|
| 拨料 PWM 频率 | 16kHz | **38kHz**（TIMER2_CH1） | 规格书要求 |
| 拨料测速 | PA6 磁盘脉冲 | PB3 霍尔（EXTI 计数，常数同构：20 脉冲/圈×114 减速比） | 新板引脚 |
| 轮盘回原点 | HALL_SW 原点霍尔 + 回转逻辑 | **删除**（新板无原点霍尔，停止即滑行停） | 新板无此传感 |
| 挡板全套 | Motor_State.c + 档位字段 | **整体删除** | 规格书明确取消 |
| 电流零点 | 固定码值 6000 | **实时减 CSREF(IN3) + 静止期自标定双保险** | 新板链路 |
| 风机启停接口 | MC_StartMotor1 等 MCSDK | `foc_soft_restart()+start_motor()/stop_motor()+run_flag/target_speed` | 平台不同 |

## 5. UART 调试模式（APP_DEBUG_UART_EN，置于 app_config.h）

- `0`（默认，正式固件）：PB10=P1 捕获；USART/遥测整体编译剔除
- `1`（调试）：PB10=USART2_TX@921600 VOFA+ JustFloat（iq/id/转速）；**P1 功能由 P2 信号兼任**
  （P2 捕获值同时喂给 P1 解码逻辑，同规于你给的调试要求）

## 6. 编译

Keil MDK-ARM 打开 `MDK-ARM/Motor_Control_GD32_HALL.uvprojx`（已加入 app 组全部文件与 IncludePath），
直接编译即可。调试模式：`app_config.h` 中 `APP_DEBUG_UART_EN` 改 1 重编译。

## 7. 上机前 checklist（重要）

1. **拨料电机测速常数**：`DOSE_HALL_PULSE_PER_REV=20`/`DOSE_GEAR_RATIO=114` 取自 K3IN1 磁盘；
   若新板拨料轮霍尔脉冲数不同，实测修正（否则转速标度不准，速度环仍闭环但 rpm 显示/下限偏差）
2. **拨料/步进电流标定**：示波器验证 `mA=(ADC−CSREF)×1.6114`；量程核对（INA181 输出摆幅）
3. **步进方向**：若打开/收起方向反了，交换 `phase_cw/phase_ccw` 即可
4. **风机重试路径**：人为堵转验证 FOC 进 FAULT → 4s 后重试 → 3 次后 Blower_Fail 红灯双闪
5. **P1/P2 捕获**：先用信号发生器 50Hz 验证三档解码（一键/全停/档位）
6. **38kHz 载波常开**（PB4）：确认与 CN2 物料传感器匹配；若需"检测时才开"，在 `app_timer2_pwm_init`
   中关闭 CH0、检测前用 `timer_channel_output_state_config` 使能（预留接口）
7. **规格书勘误**（编码时以手册表 8-5 为准）：PB4=TIMER2_CH0（非 TIMER1_CH1）；
   P1/P2 捕获=TIMER1_CH2/CH3 部分映射1

## 8. 修订记录

### v1.1（按 Keil AC5 首次编译反馈修正，2026-09-30）
| 文件 | 修正 | 根因 |
|---|---|---|
| `app_init.h` | 补 `g_adc_reg_buf[3]` 的 extern 声明 | dosing_motor.c 编译 #20 未定义（打包时漏了声明） |
| `p1p2_capture.c` | 捕获配置改用 `timer_input_capture_config()`（该函数内部已置位 CHxEN）；调试模式改为显式清 `TIMER_CHCTL2_CH2EN` | 本库 V3.0.3 无 `timer_channel_input_capture_para_config`/`timer_channel_enable`，旧调用只是隐式声明侥幸过编译、连接必挂 |
| `led_status.c` | `gpio_bit_toggle` → `LED_TOGGLE` 宏（`gpio_bit_write`+`gpio_output_bit_get` 回读取反） | 库 V3.0.3 无 gpio_bit_toggle，同样属隐式声明陷阱 |
| `motor_ctrl.c`/`dosing_motor.c` | 删除未引用变量 `s_press_dir`/`s_500us_div`；U+2212 数学减号改 ASCII | 消除 #177-D；U+2212 无 GBK 编码 |
| 全部新增源文件（18 个） | 编码 UTF-8 → **GBK** | 与原厂 GBK 文件统一，Keil 中文注释不再乱码 |

> 说明：`bldc_hall.c` 的 3 条告警（#1035-D×2、#177-D interp_apply）与 `foc.c` 的 #188-D
> 为 gd303 原厂代码自带（bldc_hall.c/pid.c 与原厂 zip 逐字一致），本次未改动。
