# 03_HALL 有感 FOC 工程 · GD32F303CBT6 新硬件移植说明

> 移植对象：MC_GD32 仓库 `Software/Application/03_HALL`（有感 HALL FOC 电机驱动）
> 原硬件：GD32F303RC 开发板（LQFP64、外部 25MHz 晶振、LCD/CAN/编码器/按键/DRV8323RS 等）
> 新硬件：GD32F303CBT6（LQFP48、Cortex-M4F、120MHz、128KB Flash / 32KB SRAM、无外部晶振）
> 本工程为**复制后的移植副本**，原始工程未做任何改动。

---

## 1. 新硬件资源（已核实）

| 引脚 | MCU脚位(封装脚号) | 功能 | 外设 |
|------|------|------|------|
| PA0 | 10 | ADC_IN0：U相电流（U20 INA181A1 输出） | ADC012_IN0 |
| PA1 | 11 | ADC_IN1：V相电流（U5 输出） | ADC012_IN1 |
| PA2 | 12 | ADC_IN2：W相电流（U14 输出） | ADC012_IN2 |
| PA3 | 13 | CSREF 1.65V 基准（零点校准，暂不使用） | ADC012_IN3 |
| PB10 | 21 | USART2 调试串口 TX（只发不收） | USART2_TX（默认映射） |
| PB12 | 25 | LED4 绿色（低电平点亮） | GPIO 输出 |
| PB13/14/15 | 26/27/28 | W/V/U 相下桥 | TIMER0_CH0/1/2_ON |
| PA8/9/10 | 29/30/31 | W/V/U 相上桥 | TIMER0_CH0/1/2 |
| PB6 | 42 | HALL_U（7.5k 上拉 5V，5VT） | TIMER3_CH0（默认映射） |
| PB7 | 43 | HALL_V（同上） | TIMER3_CH1（默认映射） |
| PB8 | 45 | HALL_W（同上） | TIMER3_CH2（默认映射） |
| PB9 | 46 | LED3 红色（低电平点亮） | GPIO 输出 |

- 三相半桥：NSG0761 驱动 + ZE017DTG 双 N-MOS，与原硬件**引脚/通道完全一致**（TIMER0 六路输出不变）。
- NSG0761 输入高有效（输入高 → 输出高），与 TIMER0 输出极性配置（高有效）匹配，无需改动。
- 电流换算：`I_x = (V_adc - 1.65V) / (20 × 0.027)`，量程 ±3.06A，约 1.5mA/LSB @12bit。
- 采样电阻在下桥臂低侧，仅下管导通期间有电流——与原硬件一致，ADC 注入组由 TIMER0_CH3 触发的采样时序**不需要改动**。

## 2. 引脚 / 外设变更总表

| 项目 | 旧硬件 | 新硬件 | 修改位置 |
|------|--------|--------|----------|
| 系统时钟 | HXTAL 25MHz → PLL ×4.8 → 120MHz | IRC8M/2 × 30 → 120MHz | `system_gd32f30x.c` |
| IU 电流采样 | PC4 / ADC01_IN14 | PA0 / ADC012_IN0 | `motor_hardware.h` |
| IV 电流采样 | PC5 / ADC01_IN15 | PA1 / ADC012_IN1 | `motor_hardware.h` |
| IW 电流采样 | PB0 / ADC01_IN8 | PA2 / ADC012_IN2 | `motor_hardware.h` |
| 电流换算 | 0.005Ω × 增益10 | 0.027Ω × 增益20（INA181A1） | `motor_config.h` |
| 霍尔接口 | TIMER2 全重映射 PC6/7/8 | TIMER3 默认映射 PB6/7/8 | `motor_hardware.c/h`、`main.c` |
| 霍尔中断 | TIMER2_IRQn | TIMER3_IRQn | `motor_hardware.c`、`main.c` |
| 调试串口 | USART2 部分重映射 PC10(TX)/PC11(RX) | USART2 默认映射 PB10，仅 TX | `uart.c` |
| LED | LED1=PD2 / LED2=PC12 / LED3=PA15 | LED3=PB9(红) / LED4=PB12(绿)，低电平点亮 | `led.c/h`、`task.c` |
| TIMER0 刹车 | PB12 外部 BKIN 输入，break 使能 | 无外部刹车信号（PB12=LED4），break 禁用 | `motor_hardware.c/h` |
| VDC 母线电压 | ADC1 采样 PC3 分压 | 无采样引脚 → 标称 24V 常量 | `motor_config.h`、`motor_app.c` |
| Flash 布局 | 0x08004000（前 16KB 为 Bootloader） | 0x08000000（新板无 Bootloader） | `main.c`、`*.uvprojx`、`*.sct` |
| 目标器件 | GD32F303RC（256K/48K） | GD32F303CB（128K/32K） | `*.uvprojx`、`*.uvoptx` |
| SWD 调试口 | AFIO 仅 SWD | 不变（保留 `GPIO_SWJ_SWDPENABLE_REMAP`） | `led.c`（原有逻辑保留） |

**移除的模块**（新硬件不存在对应器件/引脚，且与在用引脚冲突）：
`LCD`（PC13/14/15+PC1，与保留外设冲突风险）、`CAN`（PA11/12）、`编码器+按键`（占用 TIMER3，与新霍尔冲突）、`NTC 温度`、`VDC/IDC_AVER 采样`（ADC1）、`DRV8323RS SPI 配置`（新驱动 NSG0761 无需配置）、`I2C/EEPROM`（PB8/PB9 与 HALL_W/LED3 冲突）、`DAC/比较器保护`（原工程即未调用的死代码，PA5 空闲）。
对应地从 Keil 工程文件列表中移除了：`adc_simple.c、can.c、dac.c、eeprom.c、i2c.c、ntc.c、spi.c、encoder.c、drv8323rs.c、lcd.c、lcd_init.c`（源文件仍保留在目录中，未删除）。

## 3. 逐文件修改明细

### 3.1 Libraries/CMSIS/GD/GD32F30x/Source/system_gd32f30x.c
- 时钟选择宏由 `__SYSTEM_CLOCK_120M_PLL_HXTAL` 改为 `__SYSTEM_CLOCK_120M_PLL_IRC8M`。
- 库函数 `system_clock_120m_irc8m()` 自动完成：IRC8M 使能等待稳定 → `IRC8M/2 × 30 = 120MHz` →
  AHB=120M、APB2=120M、APB1=60M → 高驱动模式（HDEN/HDS，120MHz 必需）→ PLL 切换为系统时钟。
- `SystemCoreClock = 120000000`，SysTick/定时器分频关系与原设计完全一致（PWM 16kHz、霍尔计数 1MHz 不变）。

### 3.2 User/motor_config.h
- `SHUNT_RES`：0.005 → **0.027**（R19/R18/R72 均为 27mΩ）。
- `SHUNT_OPA_GAIN`：10 → **20**（INA181A1 增益 20）。
- `ADC_TO_CURRENT_COEF` 随之自动更新 ≈ 1.49mA/LSB（3.3V/4096/0.027/20）。
- 删除 VDC 分压换算系数，新增 `VDC_NOMINAL_VOLTAGE = 24.0f`（新板无母线采样引脚）。
- `PHASE_OVER_CURRENT_AMP`：15A → 3.0A（纳入 ±3.06A 采样量程内；该阈值仅被未调用的
  `comp_protect_init()` 使用，为保持一致性仍做了更新）。

### 3.3 User/motor_hardware.h / motor_hardware.c
- 电流采样宏改为 PA0/PA1/PA2 + ADC_CHANNEL_0/1/2；删除 `IDC_ADC`、`IDC_AVER_ADC`、`BEMFx`、`USER_IOx`、`PWM_BKIN` 等新硬件不存在的定义。
- `adc_gpio_init()`：仅配置三相电流输入脚（PA3/CSREF 暂不使用，保持默认模拟输入状态由硬件决定，固件不驱动）。
- `hall_init()`：删除 `GPIO_TIMER2_FULL_REMAP`；HALL 引脚宏改为 GPIOB PIN6/7/8（TIMER3 默认映射，无需任何重映射；外部 7.5k 上拉至 5V，配置为浮空输入，5VT 引脚安全）。
- `hall_timer_config()`：TIMER2 → TIMER3（`RCU_TIMER3`、`timer_deinit/init/input_capture/slave restart/CI0F_ED 触发/TI0S 霍尔模式/CH0 中断`全部指向 TIMER3）。
  > 用户手册 16.2.5 节确认 TIMER1~4 的 CTL1 寄存器均有 TI0S 位（CH0/CH1/CH2 异或作为 CH0 触发输入），TIMER3 完整支持霍尔接口模式；TIMER3 与 TIMER2 同在 APB1×2=120MHz 时钟域，`HALL_TIMER_PRESCALER=119` 维持 1MHz 计数不变。
- `interrupt_init()`：`TIMER2_IRQn` → `TIMER3_IRQn`（抢占/响应优先级不变）。
- `pwm_gpio_init()`：删除 PB12 的 BKIN 引脚配置（新硬件 PB12 为 LED4）。
- `pwm_timer_config()`：`breakstate` 由 `TIMER_BREAK_ENABLE` 改为 `TIMER_BREAK_DISABLE`
  （原硬件刹车信号接 PB12，新硬件无此外部信号；若保留会使 LED4 点亮时误触发刹车封锁 PWM）。死区 0xB8(1.2us)、中心对齐、16kHz 等全部维持原设计。
- ADC0 注入组配置（TIMER0_CH3 触发、1.5 周期采样、EOIC 中断）完全不变——TIMER0 通道与旧硬件一致。

### 3.4 User/main.c
- `SCB->VTOR = FLASH_BASE | 0x4000` → `SCB->VTOR = FLASH_BASE`（新板无 16KB HID Bootloader，固件从 0x08000000 启动；Keil IROM1 同步改为 0x08000000）。
- 初始化序列精简为：`systick → led → usart → task → motor_hardware → pmsm_foc`；删除 `adc1_init/can_bus_init/encoder_init/LCD_Init/LCD_Fill/DRV8323RS_init` 及对应头文件包含。
- `TIMER2_IRQHandler` 重命名为 `TIMER3_IRQHandler`（内部 TIMER2 引用全部改为 TIMER3，霍尔测速/角度插补逻辑不变）。
- `TIMER0_BRK_IRQHandler`、`ADC0_1_IRQHandler` 保留原样（刹车已禁用后前者不会触发，属无害保留）。

### 3.5 User/BSP/uart.c / uart.h
- 删除 `GPIO_USART2_PARTIAL_REMAP`（PC10/PC11 映射），改用 **PB10 默认映射**。
- 仅配置 TX 引脚（PB10 复用推挽）；`usart_receive_config` 设为 DISABLE，删除 RX 引脚配置、RX DMA 通道（DMA0_CH2）及接收 DMA 使能——新硬件此串口**只发不收**。
- 波特率维持 921600、DMA0_CH1 发送、发送完成标志防冲突逻辑均与原设计一致。
  > 注意：系统时钟源为 IRC8M（±2% 精度）。若上位机出现乱码，可将 `usart_baudrate_set` 降到 115200。

### 3.6 User/BSP/led.c / led.h
- LED 数量 3 → 2：`LED3 = PB9（红）`、`LED4 = PB12（绿）`，均为低电平点亮，上电初始化为高（灭）。
- `LED_FAULT = LED3（红）`（刹车/故障指示，逻辑保留）、`LED_SYS = LED4（绿）`（500ms 心跳翻转，见 task.c）。
- **保留** `gpio_pin_remap_config(GPIO_SWJ_SWDPENABLE_REMAP, ENABLE)`——满足"释放 JTAG、仅保留 SWD"的硬约束（原 led_init 已包含此句，继续保留）。
- 删除 LED1(PD2)/LED2(PC12)——GD32F303CBT6 LQFP48 无 GPIOD，PC12 未连接。

### 3.7 User/Task/motor_app.c
- 删除 LCD 界面（`motor_ui_init/motor_ui_updata`）、CAN 报文（`motor_can_transmit`）、编码器调速与按键启停逻辑、NTC/IDC 测量——新硬件均无对应器件。
- `motor1.vdc` 不再采样，直接使用 `VDC_NOMINAL_VOLTAGE`（24V），FOC 电压限幅 `max_phase_voltage = vdc/√3` 逻辑不变。
- 电机运行状态机保持原样：上电 `INIT → ADC_CAL(1024次零点标定) → START_DELAY(2s) → RUN` 自动启动（原工程即此流程，按键仅用于停止后再启动，新板无按键，电机上电自动运行）。
- FOC 中断路径 `motor_app_isr()`（电流采样→Clarke/Park→PI→SVPWM→占空比更新→串口调试帧发送）**逐行保留，未做逻辑改动**。

### 3.8 User/Task/task.c
- 心跳由 `led_toggle(LED1)` 改为 `led_toggle(LED_SYS)`（绿色 LED4 每 500ms 翻转）。

### 3.9 MDK-ARM/Motor_Control_GD32_HALL.uvprojx / .uvoptx / Objects/*.sct
- Device：GD32F303RC → **GD32F303CB**（仍使用 GigaDevice.GD32F30x_DFP.2.2.1 器件包）。
- IROM1：0x08004000/0x40000 → **0x08000000/0x20000**（128KB）；IRAM1：0xC000 → **0x8000**（32KB）；Cpu 字符串与 Flash 算法大小同步更新。
- 文件列表移除 11 个旧板驱动源文件；包含路径移除 `..\LCD`。
- 预定义宏维持 `GD32F30X_HD` + `startup_gd32f30x_hd.s`：V3.0.3 官方库为 GD32F303xB 提供 HD 类启动文件与链接脚本，证实 xB 归属 HD 类；工程用到的 TIMER0/3、ADC0、USART2、DMA0、GPIOA/B 在 CBT6 上全部存在，HD 启动文件多余的中断向量不影响运行。
- 清理了旧构建产物（Objects/Listings/bin 中的 .o/.hex/.bin/.map 等），请打开工程后重新编译。

## 4. 保持不变的部分（按"未说明的按原设计做"）

- TIMER0 六路 PWM：PA8/PA10/PA9 上桥 + PB13/14/15 下桥，通道对应关系（U=CH2、V=CH1、W=CH0）完全一致；死区 1.2us、中心对齐计数、16kHz 载波、CH3 触发 ADC 注入采样均不变。
- NSG0761 输入高有效 ↔ TIMER0 输出极性高有效（`TIMER_OC_POLARITY_HIGH`/`TIMER_OCN_POLARITY_HIGH`）不变。
- 电机参数（`userparms.h`：相电阻 3.485Ω、相电感 2.675mH、反电动势 12.25V/KRPM、极对数 2、速度环/电流环参数）与霍尔角度表 `hall_theta_tab`、`PHASE_SHIFT_ANGLE=45°` 均未改动。
- FOC 算法核心（`foc.c`/`pmsm.c`）零改动。
- 串口调试帧格式（16字节：angle/hall_state/hall_speed + 0x80 0x7f 帧尾）不变。

## 5. 验证情况

- **编译验证**：使用 arm-none-eabi-gcc 13.2（cortex-m4 硬浮点）按工程同等宏定义
  （`GD32F30X_HD / USE_STDPERIPH_DRIVER / ARM_MATH_CM4`）与包含路径编译全部 36 个源文件：**全部通过**。
  仅有的 4 条 `M_PI redefined` 警告为原工程固有（Keil armcc 的 math.h 不定义 M_PI），与本次移植无关。
- **链接验证**：使用官方库 V3.0.3 的 GCC 启动文件（HD）+ `gd32f303xB_flash.ld`（FLASH 128K @0x08000000 / RAM 32K @0x20000000）完成整包链接：**成功**。
  全部符号解析（含 `TIMER3_IRQHandler`、`ADC0_1_IRQHandler`、`TIMER0_BRK_IRQHandler`、`SysTick_Handler`、`SystemInit`），
  text≈37.7KB / data≈0.3KB / bss≈3.7KB，总占用约 42KB，适配 128KB Flash / 32KB RAM 无压力。
  （链接时以 sinf/cosf 桩替代 Keil 专用的 arm_cortexM4lf_math.lib，仅为验证符号完整性，不影响 Keil 工程。）
- **文档核对**：PB6/7/8=TIMER3_CH0/1/2 默认复用、PB10=USART2_TX 默认映射、TIMER1~4 均支持 TI0S 霍尔模式、GD32F303xB=128KB/32KB——均已在 GD32F303xB 数据手册 Rev1.1 与 GD32F30x 用户手册 Rev3.4 中核实。

## 6. 构建 / 烧录

1. 使用 Keil MDK 打开 `MDK-ARM/Motor_Control_GD32_HALL.uvprojx`（需已安装 GigaDevice.GD32F30x_DFP 器件包，仓库 `GD32/` 目录内有 `GigaDevice.GD32F30x_DFP.2.2.1.pack`）。
2. 直接 Rebuild，无其他配置需要修改。
3. 通过 H2 排针 SWD（1=SWDIO/PA13，2=3.3V，3=SWCLK/PA14，4=GND）下载，程序从 0x08000000 运行（无需 Bootloader）。
4. 调试串口：PB10，921600-8-N-1，仅 TX；每拍输出 16 字节调试帧（angle + hall_state + hall_speed + 0x80 0x7f）。

## 7. 移植后行为说明与待确认项

- **上电自动启动**：2s 延时后自动进入闭环运行（原工程逻辑）。若需要外部启停控制，需在 `motor_app_task10ms()` 中补入新硬件的命令源（如串口指令，注意当前串口只发不收）。
- **速度给定**：固定为 `userparms.h` 中的默认值（原编码器旋钮调速已随编码器一并移除）。
- **VDC 使用标称 24V**：用于 FOC 电压限幅。若实际母线偏离较大，修改 `motor_config.h` 中的 `VDC_NOMINAL_VOLTAGE`。
- **过流保护**：原工程的 PB12 硬件刹车通道在新板上不存在，当前仅剩 FOC 环内部的软件限制。若需要硬件级过流保护，可后续利用 PA3(CSREF) 做软件零点校准、或增加比较器方案。
- **电机参数**：`userparms.h` 当前为原调试电机的参数，若新硬件配不同的电机，请先核对相电阻/相电感/极对数/霍尔相序角 `PHASE_SHIFT_ANGLE`（不匹配会堵转抖动，可先置 `HALL_DEBUG=1` 观察霍尔角度）。
- **IRC8M 精度**：±2%。影响串口波特率与测速时基比例（霍尔速度用同一时基，相对值不受影响）。若串口乱码先降波特率。
